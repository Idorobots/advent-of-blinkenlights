/* hello.c -- Simple Hello World for 68HC11 bootstrap mode
   Copyright 2000, 2001, 2002, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page boot_hello Simple Hello World for 68HC11 bootstrap mode

  This 68HC11 bootstrap program acts as a simple server for uploading
  a program in external memory.  It supports only two commands:

  Implementation Notes:

     -# This program must not be linked with a startup file.  It implements
        the startup entry point.
     -# The \c _start function must be at beginning of this file.
        By doing so, it will be mapped at address 0 by the linker and
        we avoid to have some jump to call it (since the boot will
        jump there).
     -# It must be compiled with \b -mshort \b -Os \b -fomit-frame-pointer
        to make sure it fits in less than 240 bytes (keep a few bytes at
        end for the stack).
     -# It must be compiled with \b -msoft-reg-count=0 or =1 to reduce the
        use of soft-registers (since they are mapped in RAM in .page0).
     -# The soft registers must be located at beginning of the .page0.
        This will clobber the beginning of the \c _start function.
        We don't care because this clobbers some initialisation part.

  @htmlonly
  Source file: <a href="examples_2boot__hello_2hello_8c-source.html">hello.c</a>
  @endhtmlonly

*/

#include <sys/ports.h>

static void put_char (unsigned char c);
static void flush (void);
static void serial_print (const char* msg);
void _start (void);

void
_start()
{
  asm ("lds #_stack");
  serial_print ("Hi!\n");
  while (1)
    {
      serial_print ("Hello world!\n");
    }
}

static void
flush ()
{
  while (!(_io_ports[M6811_SCSR] & M6811_TDRE))
    continue;
}

static void
put_char (unsigned char c)
{
  flush ();
  _io_ports[M6811_SCDR] = c;
  _io_ports[M6811_SCCR2] |= M6811_TE;
}

static void
serial_print (const char* msg)
{
  while (*msg)
    put_char (*msg++);
}
