/* Trap example for 68HC11
   Copyright (C) 1999, 2000 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _TRAP_H
#define _TRAP_H

#include <sys/interrupts.h>
#include <sys/sio.h>
#include <stdarg.h>

/* The trap handler must be installed either in the SWI interrupt
   vector or in the ILLEGAL opcode vector.  Arguments can be passed
   as a normal C function call: gcc takes into account the different stack
   frame for the trap handler.  The trap handler can return a value: gcc
   generates code to save the result on the stack so that 'rti' will pop
   the expected return value.

   To invoke a trap handler, just call the function.  Gcc will generate a
   swi instead of a bsr.  It is possible to define several trap handlers.
   However since only one of them can be installed, it's necessary to be
   very careful.  Gcc does not install/switch trap handlers while you are
   invoking them.

   The difference between a trap handler and an interrupt handler is that
   you can pass arguments to a trap handler and the trap handler can return
   a value.  The interrupt handler can be invoked asynchronously, therefore
   some additional registers are saved by gcc.
   
   */

/* Trap handler to show parameter passing and no result.  */
extern void simple_trap_handler (int value) __attribute__((trap));

/* This trap handler returns the sum of all its arguments.  */
extern int add_trap_handler(int a, int b, int c, int d) __attribute__ ((trap));

/* For this trap handler, the operation parameter identifies the operation to
   be executed by the handler.  Further parameters depend on the operation.
   This is an example on how to define some OS system calls.  */
extern int os_trap_handler (int operation, ...) __attribute__ ((trap));

typedef int (* handler)(int, ...);

inline static void
print (const char* msg)
{
  serial_print (msg);
}


#endif
