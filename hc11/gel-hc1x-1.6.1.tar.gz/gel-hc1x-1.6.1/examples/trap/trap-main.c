/* Trap example for 68HC11
   Copyright (C) 1999, 2001, 2002, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page trap Simple trap handler example.

  The trap example illustrates how to define a trap handler (\c swi
  handler) and how to invoke the handler.  The trap handlers are
  defined by using the GNU extension \c __attribute__.

  <dl>
    <dt>trap.h
    <dd>Definition of trap handlers.

    <dt>trap.c
    <dd>Implementation of the trap handlers.

    <dt>trap-main.c
    <dd>Main that installs and invokes the trap handlers.
  </dl>
   
  @htmlonly
  Source file: <a href="trap-main_8c-source.html">trap-main.c</a>
  Source file: <a href="trap_8c-source.html">trap.c</a>
  @endhtmlonly

 */

#include "trap.h"

#ifdef USE_INTERRUPT_TABLE

/* Interrupt table used to connect our timer_interrupt handler.

   Note: the `XXX_handler: foo' notation is a GNU extension which is
   used here to ensure correct association of the handler in the struct.
   This is why the order of handlers declared below does not follow
   the HC11 order.  */
struct interrupt_vectors __attribute__((section(".vectors"))) vectors = 
{
  res0_handler:           fatal_interrupt, /* res0 */
  res1_handler:           fatal_interrupt,
  res2_handler:           fatal_interrupt,
  res3_handler:           fatal_interrupt,
  res4_handler:           fatal_interrupt,
  res5_handler:           fatal_interrupt,
  res6_handler:           fatal_interrupt,
  res7_handler:           fatal_interrupt,
  res8_handler:           fatal_interrupt,
  res9_handler:           fatal_interrupt,
  res10_handler:          fatal_interrupt, /* res 10 */
  sci_handler:            fatal_interrupt, /* sci */
  spi_handler:            fatal_interrupt, /* spi */
  acc_overflow_handler:   fatal_interrupt, /* acc overflow */
  acc_input_handler:      fatal_interrupt,
  timer_overflow_handler: fatal_interrupt,
  output5_handler:        fatal_interrupt, /* out compare 5 */
  output4_handler:        fatal_interrupt, /* out compare 4 */
  output3_handler:        fatal_interrupt, /* out compare 3 */
  output2_handler:        fatal_interrupt, /* out compare 2 */
  output1_handler:        fatal_interrupt, /* out compare 1 */
  capture3_handler:       fatal_interrupt, /* in capt 3 */
  capture2_handler:       fatal_interrupt, /* in capt 2 */
  capture1_handler:       fatal_interrupt, /* in capt 1 */
  rtii_handler:           fatal_interrupt,
  irq_handler:            fatal_interrupt, /* IRQ */
  xirq_handler:           fatal_interrupt, /* XIRQ */
  illegal_handler:        fatal_interrupt, /* illegal */
  cop_fail_handler:       fatal_interrupt,
  cop_clock_handler:      fatal_interrupt,

  /* What we really need.  */
  swi_handler:            os_trap_handler, /* swi */
  reset_handler:          _start
};

#endif

extern int global_result;

int
main()
{
  int result;
  int failed;

  serial_init ();

#ifndef USE_INTERRUPT_TABLE
  /* With interrupt table, we can't change the SWI handler.  */

  /* Test with simple trap handler.  */
  set_interrupt_handler (SWI_VECTOR, (interrupt_t) simple_trap_handler);
  print ("Using simple trap handler: ");
  failed = 0;
  simple_trap_handler (1);
  if (global_result != 1)
    {
      print ("  Simple trap handler failed, didn't returned 1\r\n");
      failed = 1;
    }
  
  simple_trap_handler (2);
  if (global_result != 4)
    {
      print ("  Simple trap handler failed, didn't returned 4\r\n");
      failed = 1;
    }
  if (failed == 0)
    print ("OK\r\n");

  /* Test with add trap handler.  */
  set_interrupt_handler (SWI_VECTOR, (interrupt_t) add_trap_handler);
  failed = 0;
  print ("Using add trap handler: ");
  result = add_trap_handler (1, 2, 3, 4);
  if (result != 10)
    {
      print ("Add trap handler didn't returned 10\r\n");
      failed = 1;
    }
  result = add_trap_handler (5, 6, 7, 8);
  if (result != 26)
    {
      print ("Add trap handler didn't returned 26\r\n");
      failed = 1;
    }
  if (failed == 0)
    print ("OK\r\n");
#endif

  set_interrupt_handler (SWI_VECTOR, (interrupt_t) os_trap_handler);
  failed = 0;
  print ("Using OS trap handler...\r\n");
  result = os_trap_handler (0, "  Hello World from os_trap_handler...\r\n");
  if (result != 0)
    {
      print ("  OS call 0 failed\r\n");
      failed = 1;
    }

  result = os_trap_handler (0, "  Type a character ");
  if (result != 0)
    {
      print ("  OS call 0 failed\r\n");
      failed = 1;
    }
  
  result = os_trap_handler (1);

  result = os_trap_handler (2, 23, 44);
  if (result != 23 + 44)
    {
      print ("  OS add system call failed\r\n");
      failed = 1;
    }
  
  if (failed == 0)
    print ("OS trap call test ok.\r\n");
  
  print ("Trap handler test finished.\r\n");
  return 0;
}
