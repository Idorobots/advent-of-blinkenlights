/* Trap example for 68HC11
   Copyright (C) 1999 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include "trap.h"

int global_result;

/* Trap handler to show parameter passing and no result.  */
void
simple_trap_handler(int value)
{
  global_result = value * value;
}


/* This trap handler returns the sum of all its arguments.  */
int
add_trap_handler(int a, int b, int c, int d)
{
  return a + b + c + d;
}


/* For this trap handler, the operation parameter identifies the operation to
   be executed by the handler.  Further parameters depend on the operation.
   This is an example on how to define some OS system calls.  */
int
os_trap_handler(int operation, ...)
{
  va_list argp;
  int result;
  const char* p;
  
  va_start(argp, operation);
  switch (operation)
    {
      /* A kind of write system call.  */
    case 0:
      p = va_arg (argp, const char*);
      print (p);
      result = 0;
      break;

      /* A kind of read system call.  */
    case 1:
      result = serial_recv ();
      break;

    case 2:
      result = va_arg (argp, int) + va_arg (argp, int);
      break;
      
      /* Invalid call.  */
    default:
      result = -1;
      break;
    }
  va_end(argp);
  return result;
}

