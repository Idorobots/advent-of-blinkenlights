/* persist -- Persistent Storage Management
   Copyright 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page persist Persistent Storage Example
   
  This program is a simple example for persistent storage using the eeprom.
  It uses the \b persistent class to manage persistent objects.

  @htmlonly
  Source file: <a href="persist_8cc-source.html">persist.cc</a>
  @endhtmlonly

*/

#include "persist.h"
#include <sys/sio.h>
#include <stdarg.h>
#include <time.h>
#include <stdio.h>

inline void
print (const char* msg)
{
  serial_print (msg);
}

typedef char country[20];
typedef char name[12];
typedef char address[32];
typedef char buf[64];

typedef union
{
  name u_name;
  address u_address;
  country u_country;
  buf u_buf;
} u_str;

typedef persistent<char> p_char_t;
typedef persistent<short> p_short_t;
typedef persistent<long> p_long_t;
typedef persistent<name> p_name_t;
typedef persistent<country> p_country_t;
typedef persistent<address> p_address_t;

typedef enum
{
  P_NAME,
  P_FIRSTNAME,
  P_ADDRESS,
  P_COUNTRY,
  P_NUM,
  P_AGE,
  P_UPDATE_COUNT
} pids_t;

volatile char __counter;

void*
operator new (size_t len)
{
  printf ("new called");
  return 0;
}

void
operator delete (void *ptr)
{
  ;
}

void
print_array (const char *p, size_t len)
{
  while (*p && len)
    {
      printf ("%c", *p++);
      len--;
    }
}

void
print_id ()
{
  p_name_t p_name (P_NAME);
  p_name_t p_first_name (P_FIRSTNAME);

  printf ("\nHello ");
  print_array (p_first_name, sizeof (name));
  printf (" ");
  print_array (p_name, sizeof (name));
  printf ("!\n");
}

typedef enum
{
  OP_NAME,
  OP_FIRSTNAME,
  OP_ADDRESS,
  OP_COUNTRY,
  OP_NUM,
  OP_AGE,
  OP_QUIT,
  OP_LIST,
  OP_HELP
};

typedef struct command
{
  const char *name;
  int type;
  const char *help;
} command;

/* List of commands with a description string. */
static const command commands[] = {
  {
    "name",
    OP_NAME,
    "Set the name"
  } , {
    "firstname",
    OP_FIRSTNAME,
    "Set the first name"
  } , {
    "address",
    OP_ADDRESS,
    "Set the address"
  } , {    
    "country",
    OP_COUNTRY,
    "Set the country"
  } , {
    "Number",
    OP_NUM,
    "Set the number"
  } , {
    "Age",
    OP_AGE,
    "Set the age"
  } , {
    "quit",
    OP_QUIT,
    "Quit the calculator"
  } , {
    "print",
    OP_LIST,
    "Print the information"
  } , {
    "help",
    OP_HELP,
    "This help"
  } , {
    0,
    0,
    0
  }
};


/* Implementation of some libc methods. */
int
strcmp (const char* s1, const char* s2)
{
  while (*s1 && (*s1 == *s2))
    s1++, s2++;

  return *s1 - *s2;
}

/* Try to translate a string into a number. We look first for hexadecimal
   format, octal and then decimal. If the string could be converted, the
   value is returned in `v' and the function returns 0. Otherwise, it
   returns -1. */
int
get_value(const char* buf, long* v)
{
  long value = 0;
  char c;
  
  if (!(*buf >= '0' && *buf <= '9'))
    return -1;

  /* Translate an hexadecimal value. */
  if (*buf == '0' && (buf[1] == 'x' || buf[1] == 'X'))
    {
      buf += 2;
      while ((c = *buf++))
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else if (c >= 'a' && c <= 'f')
	    c = c - 'a' + 10;
	  else if (c >= 'A' && c <= 'F')
	    c = c - 'A' + 10;
	  else
	    return -1;

	  value = (value << 4) | (long) ((unsigned) c);
	}
      *v = value;
      return 0;
    }
  else
    {
      int sign = 0;

      if (buf[0] == '-')
	{
	  sign = 1;
	  buf++;
	}
      while ((c = *buf++) != 0)
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else
	    return -1;

	  value = (value * 10) + (long) c;
	}
      if (sign)
	value = -value;
      *v = value;
      return 0;
    }
  return -1;
}

/* Busy loop to wait for a command or a valid number. */
void
cmd_get_string (char *buf)
{
  int pos;
  char c;

  while (1)
    {
      pos = 0;
      while (1)
	{
	  c = serial_recv ();
	  if (c == '\r' || c == '\n')
	    break;

	  if (c == '\b')
	    {
	      printf ("\b \b");
	      pos--;
	      if (pos < 0)
		pos = 0;
	    }
	  else
	    {
	      buf[pos] = c;
              buf[pos+1] = 0;
              printf (&buf[pos]);
	      pos++;
	    }
	}

      printf ("\n");
      buf[pos] = 0;
      break;
    }
}

static void
print_help()
{
  int i;
  
  for (i = 0; commands[i].name; i++)
    {
      if (commands[i].help == 0)
	continue;

      printf ("%s\t", commands[i].name);
      printf ("%s\n", commands[i].help);
    }
}

static name def_name = "Joe";
static name def_first_name = "Dalton";
static country def_country = "USA";
static address def_address = "Citizen bank avenue, Red City";

int
cmd_loop()
{
  int i;
  long val;
  u_str buf;

  // Build persistent objects.
  p_name_t p_name (P_NAME, def_name);
  p_name_t p_firstname (P_FIRSTNAME, def_first_name);
  p_address_t p_address (P_ADDRESS, def_address);
  p_country_t p_country (P_COUNTRY, def_country);
  p_long_t p_num (P_NUM, 0);
  p_long_t p_age (P_AGE, 0);
  p_long_t p_update_count (P_UPDATE_COUNT, 0);

  print_help ();
  while (1)
    {
      print_id ();

      cmd_get_string (buf.u_buf);
      for (i = 0; commands[i].name; i++)
	if (strcmp (commands[i].name, buf.u_buf) == 0)
	  break;

      if (commands[i].name == 0)
	continue;

      if (commands[i].type == OP_QUIT)
	return 0;
      else if (commands[i].type == OP_HELP)
	{
	  print_help ();
	  continue;
	}
      else if (commands[i].type == OP_LIST)
	{
	  printf ("Name           : ");
	  print_array (p_name, sizeof (name));
	  printf ("\nFirst name   : ");
	  print_array (p_firstname, sizeof (name));
	  printf ("\nAddress      : %ld, ", (long) p_num);
	  print_array (p_address, sizeof (address));
	  printf ("\nCountry      : ");
	  print_array (p_country, sizeof (country));
	  printf ("\nAge          : %ld", (long) p_age);
	  printf ("\nUpdate count : %ld\n", (long) p_update_count);
	  continue;
	}
      printf ("New value for %s :", (const char*) commands[i].name);
      cmd_get_string (buf.u_buf);

      switch (commands[i].type)
	{
	case OP_NAME:
	  p_name = buf.u_name;
	  break;

	case OP_FIRSTNAME:
	  p_firstname = buf.u_name;
	  break;

	case OP_ADDRESS:
	  p_address = buf.u_address;
	  break;

	case OP_COUNTRY:
	  p_country = buf.u_country;
	  break;

	case OP_NUM:
	  if (get_value (buf.u_buf, &val) == 0)
	    {
	      p_num = val;
	    }
	  break;

	case OP_AGE:
	  if (get_value (buf.u_buf, &val) == 0)
	    {
	      p_age = val;
	    }
	  break;
	}
      p_update_count++;
    }
}

int
main()
{
  serial_init ();
  
  printf ("Simple Persistence Test Program\n");
  cmd_loop ();
  return 0;
}
