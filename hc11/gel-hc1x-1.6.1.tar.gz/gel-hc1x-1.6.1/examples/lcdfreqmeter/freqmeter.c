/* Simple Logical Analyzer
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page analyzer Simple One-bit Logical Analyzer

    This program is a simple one-bit logical analyzer.  It probes
    the bit 7 of port A and keep track of state changes on that input.
    For each change (0 to 1 or 1 to 0 transition), it keeps track of
    the free running counter (TCNT).  After collecting the samples,
    it report them on the serial line.

    I have used this simple logical analyzer to debug my parallel port
    eprom programmer.  I connected the PA7 input to the CE, OE or PGM
    eprom pin.  I was able to measure the 1ms pulse that I applied on
    the PGM pin.

    The accuracy of level change by the analyzer is in the order of
    50us with a 8Mhz 68HC11.  So, don't expect to analyze frequencies
    above 10Khz (due to Shannon).

  @htmlonly
  Source file: <a href="analyzer_c-source.html">analyzer.c</a>
  @endhtmlonly

*/
#include "freqmeter.h"
#include <lcd.h>
#include <ebcs/board.h>

#define TIMER_DIV  (8192L)
#define TIMER_TICK (M6811_CPU_E_CLOCK / TIMER_DIV)

/* Setup for a 8Mhz quartz, and prescaler set to 1
   (500ns period).  */
#define USEC_PER_TICK (1)
#define USEC_DIVISOR  (2)

#if 0
unsigned short prev_time_1;
unsigned short prev_time_2;
unsigned long dt_sum_1;
unsigned long dt_sum_2;
unsigned short dt_count_1;
unsigned short dt_count_2;

unsigned long tick_sum_1;
unsigned long tick_sum_2;
unsigned short m_count_1;
unsigned short m_count_2;

volatile unsigned char new_measure = 0;

void __attribute__((interrupt))
input_capture_1_interrupt (void)
{
  unsigned short t;
  unsigned short dt;
  
  t = get_input_capture_1 ();
  if (t > prev_time_1)
    {
      dt = t - prev_time_1;
      dt_sum_1 += dt;
      dt_count_1++;
    }
  prev_time_1 = t;
  _io_ports[M6811_TFLG1] = M6811_IC1F;
}

void __attribute__((interrupt))
input_capture_2_interrupt (void)
{
  unsigned short t;
  unsigned short dt;
  
  t = get_input_capture_2 ();
  if (t > prev_time_2)
    {
      dt = t - prev_time_2;
      dt_sum_2 += dt;
      dt_count_2++;
    }
  prev_time_2 = t;
  _io_ports[M6811_TFLG1] = M6811_IC2F;
}

#define MFREQ 10

void __attribute__((interrupt))
timer_overflow (void)
{
  static unsigned char nr_overflow = MFREQ;

  nr_overflow--;
  if (nr_overflow == 0)
    {
      tick_sum_1 = dt_sum_1;
      m_count_1 = dt_count_1;
      tick_sum_2 = dt_sum_2;
      m_count_2 = dt_count_2;
      dt_sum_1 = 0;
      dt_sum_2 = 0;
      dt_count_1 = 0;
      dt_count_2 = 0;
      prev_time_2 = prev_time_1 = 0xffff;
      new_measure++;
      nr_overflow = MFREQ;
    }
  _io_ports[M6811_TFLG2] |= M6811_TOF;
}

#else


#define MFREQ ((32*2)/4)
unsigned long tick_sum_1 = MFREQ * 0x10000;
unsigned long tick_sum_2 = MFREQ * 0x10000;
unsigned short input_1_count;
unsigned short input_2_count;
unsigned short m_count_1;
unsigned short m_count_2;

volatile unsigned char new_measure = 0;

void input_capture_1_interrupt (void);
void input_capture_2_interrupt (void);

void __attribute__((interrupt))
_input_capture_1_interrupt (void)
{
  asm volatile (".globl input_capture_1_interrupt\n"
                "input_capture_1_interrupt:");
  input_1_count++;
  _io_ports[M6811_TFLG1] = M6811_IC1F;
  asm volatile ("rti");
}

void __attribute__((interrupt))
_input_capture_2_interrupt (void)
{
  asm volatile (".globl input_capture_1_interrupt\n"
                "input_capture_2_interrupt:");
  input_2_count++;
  _io_ports[M6811_TFLG1] = M6811_IC2F;
  asm volatile ("rti");
}

void __attribute__((interrupt))
timer_overflow (void)
{
  static unsigned char nr_overflow = MFREQ;

  nr_overflow--;
  _io_ports[M6811_TFLG2] = M6811_TOF;
  if (nr_overflow == 0)
    {
      m_count_1 = input_1_count;
      m_count_2 = input_2_count;
      input_1_count = 0;
      input_2_count = 0;
      unlock ();
      new_measure++;
      nr_overflow = MFREQ;
    }
}
#endif

long measure;

void
report_frequency (lcd_col_t col, lcd_line_t line,
                  unsigned long dt, unsigned short cnt)
{
  char buf[32];
  unsigned long h;
  
  if (cnt)
    dt = dt / cnt;
  dt = (dt * USEC_PER_TICK) / USEC_DIVISOR;
  dt = 1000000000L / dt;
  dt = dt / 1000;
  h = 10560000 / (dt * 16);
  h -= 1000;
  h *= 100;
  h /= 80;
  
  if (line == 0 || 1)
    sprintf (buf, "%ld.%ld%%     ", h / 10L, h % 10L);
  else
    sprintf (buf, "%ld HZ    %ld  ", dt / 1000, (unsigned long) cnt);

  lcd_print_at (col, line, buf);
}

void
report_idle (unsigned long idle)
{
  char buf[32];

  sprintf (buf, "%ld   ", idle);
  lcd_print_at (10, 0, buf);
}

void
report_analog (lcd_col_t col, lcd_line_t line,
               unsigned char value)
{
  char buf[32];
  unsigned long v;

  v = (unsigned long) (value) * 5L * 1000L * 1000L;
  v = v / (1167L * 256L);
  v += 4;
  v /= 10L;
  sprintf (buf, "%ld.%ld   ", (long) (v / 10L), (long) (v % 10L));
  lcd_print_at (col, line, buf);
}

void
report_counter (lcd_col_t col, lcd_line_t line, unsigned short counter)
{
  char buf[32];

  sprintf (buf, "%ld   ", (long) counter);
  lcd_print_at (col, line, buf);
  _io_ports[M6811_TFLG2] &= ~M6811_PAOVF;
}

int
main ()
{
  unsigned long idle;
  unsigned short counter;
  
  lock ();
  serial_init ();

  set_interrupt_handler (TIMER_INPUT1_VECTOR, input_capture_1_interrupt);
  set_interrupt_handler (TIMER_INPUT2_VECTOR, input_capture_2_interrupt);
  set_interrupt_handler (TIMER_OVERFLOW_VECTOR, timer_overflow);

  _io_ports[M6811_TMSK2] = M6811_TOI;
  _io_ports[M6811_TCTL2] = M6811_EDG1B | M6811_EDG2B | M6811_EDG3B;
  _io_ports[M6811_TMSK1] = M6811_IC1I | M6811_IC2I;
  _io_ports[M6811_OPTION] |= M6811_ADPU;
  _io_ports[M6811_ADCTL] = M6811_MULT | M6811_SCAN;
  _io_ports[M6811_PACNT] = 0;
  _io_ports[M6811_PACTL] |= M6811_PAEN;
  _io_ports[M6811_PACTL] &= ~(M6811_DDRA7 | M6811_PAMOD);
  _io_ports[M6811_TMSK2] &= ~(M6811_PAOVI | M6811_PAII);
  new_measure = 0;
#if 0
  prev_time_1 = 0xffff;
  prev_time_2 = 0xffff;
#endif

  unlock ();
  
  /* Reset the LCD controller.  */
  lcd_reset ();
  while (1)
    {
      idle = 0;
      while (new_measure == 0)
        {
          idle += 3;
        }

      new_measure = 0;
      measure++;

      counter = _io_ports[M6811_PACNT];
      if (_io_ports[M6811_TFLG2] & M6811_PAOVF)
        counter += 256;

      report_frequency (0, 0, tick_sum_1, m_count_1);
      report_frequency (0, 1, tick_sum_2, m_count_2);
      /*report_idle (idle);*/
      report_analog (10, 0, _io_ports[M6811_ADR4]);
      report_counter (10, 1, counter);

      /* Configure the buttons.  */
      remote_putc (~(0x80 | LCD_BIT_4 | LCD_BIT_5 | LCD_BIT_6 | LCD_BIT_7));
      _io_ports[M6811_PACNT] = 0;
    }
}
