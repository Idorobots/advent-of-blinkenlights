/* Simple Frequency meter.
   Copyright (C) 2001, 2002, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page freqmeter Simple Frequency meter.

    This program is a simple one-bit logical analyzer.  It probes
    the bit 7 of port A and keep track of state changes on that input.
    For each change (0 to 1 or 1 to 0 transition), it keeps track of
    the free running counter (TCNT).  After collecting the samples,
    it report them on the serial line.

    I have used this simple logical analyzer to debug my parallel port
    eprom programmer.  I connected the PA7 input to the CE, OE or PGM
    eprom pin.  I was able to measure the 1ms pulse that I applied on
    the PGM pin.

    The accuracy of level change by the analyzer is in the order of
    50us with a 8Mhz 68HC11.  So, don't expect to analyze frequencies
    above 10Khz (due to Shannon).

  @htmlonly
  Source file: <a href="freqmeter_8c-source.html">freqmeter.c</a>
  @endhtmlonly

*/
#include <stdio.h>
#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>
#include <sys/sio.h>
#include <sys/locks.h>

#define TIMER_DIV  (8192L)
#define TIMER_TICK (M6811_CPU_E_CLOCK / TIMER_DIV)

/* Setup for a 8Mhz quartz, and prescaler set to 1
   (500ns period).  */
#define USEC_PER_TICK (1)
#define USEC_DIVISOR  (2)

unsigned short prev_time;
unsigned long dt_sum;
unsigned short dt_count;

unsigned long tick_sum;
unsigned short m_count;

volatile unsigned char new_measure = 0;

void input_capture_interrupt (void) __attribute__((interrupt));
void timer_overflow_interrupt (void) __attribute__((interrupt));

#ifdef USE_INTERRUPT_TABLE

/* Interrupt table used to connect our timer_interrupt handler.

   Note: the `XXX_handler: foo' notation is a GNU extension which is
   used here to ensure correct association of the handler in the struct.
   This is why the order of handlers declared below does not follow
   the HC11 order.  */
struct interrupt_vectors __attribute__((section(".vectors"))) vectors = 
{
  res0_handler:           fatal_interrupt, /* res0 */
  res1_handler:           fatal_interrupt,
  res2_handler:           fatal_interrupt,
  res3_handler:           fatal_interrupt,
  res4_handler:           fatal_interrupt,
  res5_handler:           fatal_interrupt,
  res6_handler:           fatal_interrupt,
  res7_handler:           fatal_interrupt,
  res8_handler:           fatal_interrupt,
  res9_handler:           fatal_interrupt,
  res10_handler:          fatal_interrupt, /* res 10 */
  sci_handler:            fatal_interrupt, /* sci */
  spi_handler:            fatal_interrupt, /* spi */
  acc_overflow_handler:   fatal_interrupt, /* acc overflow */
  acc_input_handler:      fatal_interrupt,
  output5_handler:        fatal_interrupt, /* out compare 5 */
  output4_handler:        fatal_interrupt, /* out compare 4 */
  output3_handler:        fatal_interrupt, /* out compare 3 */
  output2_handler:        fatal_interrupt, /* out compare 2 */
  output1_handler:        fatal_interrupt, /* out compare 1 */
  capture3_handler:       fatal_interrupt, /* in capt 3 */
  capture2_handler:       fatal_interrupt, /* in capt 2 */
  rtii_handler:           fatal_interrupt,
  irq_handler:            fatal_interrupt, /* IRQ */
  xirq_handler:           fatal_interrupt, /* XIRQ */
  swi_handler:            fatal_interrupt, /* swi */
  illegal_handler:        fatal_interrupt, /* illegal */
  cop_fail_handler:       fatal_interrupt,
  cop_clock_handler:      fatal_interrupt,

  /* What we really need.  */
  capture1_handler:       input_capture_interrupt, /* in capt 1 */
  timer_overflow_handler: timer_overflow_interrupt,
  reset_handler:          _start
};

#endif

void __attribute__((interrupt))
input_capture_interrupt (void)
{
  unsigned short t;
  unsigned short dt;
  
  t = get_input_capture_1 ();
  if (t > prev_time)
    {
      dt = t - prev_time;
      dt_sum += dt;
      dt_count++;
    }
  prev_time = t;
  _io_ports[M6811_TFLG1] |= M6811_IC1F;
}

void __attribute__((interrupt))
timer_overflow_interrupt (void)
{
  static unsigned char nr_overflow = 100;

  nr_overflow--;
  if (nr_overflow == 0)
    {
      tick_sum = dt_sum;
      m_count = dt_count;
      dt_sum = 0;
      dt_count = 0;
      prev_time = 0xffff;
      new_measure++;
      nr_overflow = 100;
    }
  _io_ports[M6811_TFLG2] |= M6811_TOF;
}

static void
report_frequency (unsigned long dt, unsigned short cnt)
{
  if (cnt)
    dt = dt / cnt;
  dt = (dt * USEC_PER_TICK) / USEC_DIVISOR;
  dt = 1000000000L / dt;
  printf ("\rP: %ld HZ   ", dt / 1000);
}

int
main ()
{
  lock ();
  serial_init ();

  set_interrupt_handler (TIMER_INPUT1_VECTOR, input_capture_interrupt);
  set_interrupt_handler (TIMER_OVERFLOW_VECTOR, timer_overflow_interrupt);

  _io_ports[M6811_TMSK2] = M6811_TOI;
  _io_ports[M6811_TCTL2] = M6811_EDG1B | M6811_EDG2B | M6811_EDG3B;
  _io_ports[M6811_TMSK1] = M6811_IC1I;
  new_measure = 0;
  prev_time = 0xffff;
  unlock ();
  
  while (1)
    {
      while (new_measure == 0)
        continue;

      new_measure = 0;
      report_frequency (tick_sum, m_count);
    }
}
