/* expr.h -- Expression Tree
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_INTERPRETOR_EXPR_H
#define _GEL_INTERPRETOR_EXPR_H

#include "config.h"

#undef far
#undef bank

// Expression Tree implementation is put in memory bank1.
// - The 'bank' attribute is used on all methods
// - The 'far' attribute is only used on public entry points.
#define bank SECT_ATTR(".text.bank1")
#define far FAR_ATTR(".text.bank1")

class Variable;
typedef long Value;

/*! Root of expression tree.

*/
class Expression {
protected:
  enum token
    {
      T_NAME,
      T_DIGIT,
      T_MINUS,
      T_PLUS,
      T_AND,
      T_OR,
      T_XOR,
      T_MUL,
      T_DIV,
      T_NOT,
      T_PARENT_OPEN,
      T_PARENT_CLOSE,
      T_UNKNOWN,
      T_EOF
    };
  enum token type_;

  static bank enum token get_token (const char*& line);
  static bank void rewind (enum token t, const char*& line);

  static bank Expression* parse_unary (const char*& line);
  static bank Expression* parse_binary (const char*& line, unsigned char prio);
  static bank Expression* parse_term (const char*& line);
  static bank int get_value(const char*& line, Value& value);
  static bank unsigned char get_priority(enum token t);
  
  virtual far Value eval();

public:
   Expression(enum token t) {
     type_ = t;
   }
   virtual ~Expression();

   far Value evaluate();

   static far Expression* parse(const char*& line);
};

/// Binary expression
class BinaryExpression : public Expression {
protected:
   Expression* left_;
   Expression* right_;

   virtual far Value eval();

   virtual ~BinaryExpression()
     {
       delete left_;
       delete right_;
     }

public:
   BinaryExpression(enum token t, Expression* l, Expression* r)
     : Expression(t), left_(l), right_(r)
     {
     }
};

/// Unary expression
class UnaryExpression : public Expression {
protected:
  Expression* expr_;
  
  virtual far Value eval();
  
  virtual ~UnaryExpression()
    {
      delete expr_;
    }

public:
  UnaryExpression(enum token t, Expression* l)
    : Expression(t), expr_(l)
    {
    }
};

/// Leaf/value expression
class ValueExpression : public Expression {
  long value_;

  virtual far Value eval();
public:
  ValueExpression(long value) : Expression(T_DIGIT) 
    {
      value_ = value;
    }
};

#endif
