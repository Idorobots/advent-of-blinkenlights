/* interpretor -- Simple Command Interpretor
   Copyright 2002, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page interpretor Simple Command Interpretor
   
  @htmlonly
  Source files: 
    <ul>
      <li><a href="interpretor_8h-source.html">interpretor.h</a>
      <li><a href="interpretor_8cc-source.html">interpretor.cc</a>
      <li><a href="expr_8h-source.html">expr.h</a>
      <li><a href="expr_8cc-source.html">expr.cc</a>
    </ul>
  @endhtmlonly
*/

#include "interpretor.h"
#include <sys/sio.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "expr.h"

// Simple Memory Allocator
class Allocator {

  // A memory slot can contain any object created by this example.
  union MemSlot {
    char buffer;
    char _b_Expression[sizeof (Expression)];
    char _b_BinaryExpression[sizeof (BinaryExpression)];
    char _b_UnaryExpression[sizeof (UnaryExpression)];
    char _b_ValueExpression[sizeof (ValueExpression)];
  };

  // Allow up to 100 instances
  MemSlot exprMemoryPool[100];
  unsigned last;
public:
  Allocator()
    {
      last = 0;
    }

  void reset()
    {
      last = 0;
    }

  void* allocate(size_t size)
    {
      assert(size <= sizeof (MemSlot));
      assert(last < 100);

      char* slot = &exprMemoryPool[last].buffer;
      last++;
      return slot;
    }
};

Allocator allocator;

void* near
operator new (size_t len)
{
  return allocator.allocate(len);
}

void near
operator delete (void *ptr)
{
}

void print (const char* p)
{
   serial_print (p);
}

/* Implementation of some libc methods. */
int
strcmp (const char* s1, const char* s2)
{
  while (*s1 && (*s1 == *s2))
    s1++, s2++;

  return *s1 - *s2;
}

int interpretor::execute(const char* line)
{
  if (line == 0)
    return 0;

  Expression* e = Expression::parse(line);
  if (e)
    {
      Value v = e->evaluate();
      printf(" Result = %ld\n", (long) v);
      delete e;
    }
  else
    {
      printf("Invalid expression\n");
    }
  return 0;
}

/* Busy loop to wait for a command or a valid number. */
void
interpretor::get_command (char *buf)
{
  int pos;
  char c;

  while (1)
    {
      pos = 0;
      while (1)
	{
	  c = serial_recv ();
	  if (c == '\r' || c == '\n')
	    break;

	  if (c == '\b')
	    {
	      printf ("\b \b");
	      pos--;
	      if (pos < 0)
		pos = 0;
	    }
	  else
	    {
	      buf[pos] = c;
              buf[pos+1] = 0;
              printf (&buf[pos]);
	      pos++;
	    }
	}

      printf ("\n");
      buf[pos] = 0;
      break;
    }
}

void
interpretor::main_loop()
{
  static char buf[100];

  while (1)
    {
      // Reset the allocator before each computation.
      allocator.reset();

      // Get expression to evaluate.
      printf ("> ");
      get_command (buf);
      if (strcmp (buf, "quit") == 0)
        break;

      execute (buf);
    }
}

int
main()
{
  interpretor interp;

  serial_init ();

  printf ("Simple Interpretor Program\n");
  interp.main_loop ();
  return 0;
}
