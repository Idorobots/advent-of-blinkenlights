/* expr.cc -- Expression Tree
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include "expr.h"

Expression::~Expression()
{
}

Value Expression::evaluate ()
{
  return eval ();
}

// Evaluate an unary expression
Value UnaryExpression::eval ()
{
  Value v = expr_->evaluate ();

  if (type_ == T_MINUS)
    return -v;
  else if (type_ == T_NOT)
    return ~v;
  else
    return v;
}

// Evaluate a binary expression.
Value BinaryExpression::eval ()
{
  Value l = left_->evaluate ();
  Value r = right_->evaluate ();

  switch (type_)
    {
    case T_PLUS:
      return l + r;
    case T_MINUS:
      return l - r;
    case T_MUL:
      return l * r;
    case T_DIV:
      return l / r;
    case T_AND:
       return l & r;
    case T_OR:
       return l | r;
    case T_XOR:
       return l ^ r;
    default:
      return l;
    }
}

// Evaluate a final value
Value ValueExpression::eval ()
{
  return value_;
}

Value Expression::eval()
{
  return 0;
}

void Expression::rewind (enum token t, const char*& line)
{
  if (t == T_EOF)
    return;
  line--;
}

enum Expression::token Expression::get_token(const char*& line)
{
  char c;

  do {
    c = *line++;
  } while (c == ' ' || c == '\t');

  switch (c)
    {
    case 0:
      line--;
      return T_EOF;
    case '-':
      return T_MINUS;
    case '+':
      return T_PLUS;
    case '*':
      return T_MUL;
    case '/':
      return T_DIV;
    case '|':
      return T_OR;
    case '&':
      return T_AND;
    case '^':
      return T_XOR;
    case '~':
      return T_NOT;
    case '(':
      return T_PARENT_OPEN;
    case ')':
      return T_PARENT_CLOSE;
    default:
      if (c >= '0' && c <= '9')
        return T_DIGIT;
      if (c >= 'a' && c <= 'z')
        return T_NAME;
      if (c >= 'A' && c <= 'Z')
        return T_NAME;
      return T_UNKNOWN;
    }
}

// Get the priority of the operator
unsigned char Expression::get_priority(enum token t)
{
  switch (t)
    {
    case T_MINUS:
    case T_PLUS:
      return 2;
      
    case T_AND:
    case T_OR:
    case T_XOR:
      return 1;
      
    case T_MUL:
    case T_DIV:
      return 3;

    case T_NOT:
      return 4;

    default:
      return 5;
    }
}
   
// Parse a unary expression and return it
Expression* Expression::parse_unary(const char*& line)
{
  enum token t = get_token (line);
  if (t == T_MINUS || t == T_NOT)
    {
      Expression* e = parse_binary (line, 0);
      if (e)
        e = new UnaryExpression (t, e);
      return e;
    }
  else
    {
      rewind (t, line);
      return parse_binary (line, 0);
    }
}

// Parse a binary expression and return it
Expression* Expression::parse_binary(const char*& line, unsigned char prio)
{
  Expression* current = parse_term (line);
  if (current == 0)
    return 0;

  while (1)
    {
      enum token t = get_token (line);
      if (t != T_MINUS && t != T_PLUS
          && t != T_MUL && t != T_DIV
          && t != T_AND && t != T_OR && t != T_XOR)
        {
          rewind (t, line);
          return current;
        }

      unsigned char p = Expression::get_priority (t);
      if (p < prio)
        {
          rewind (t, line);
          return current;
        }
      Expression* r;
      if (p > prio)
        r = parse_binary (line, p + 1);
      else
        r = parse_term (line);

      if (r == 0)
        {
          delete current;
          return 0;
        }
      current = new BinaryExpression (t, current, r);
    }
}

/* Try to translate a string into a number. We look first for hexadecimal
   format, octal and then decimal. If the string could be converted, the
   value is returned in `v' and the function returns 0. Otherwise, it
   returns -1. */
// Parse a final integer value
int
Expression::get_value(const char*& buf, Value& v)
{
  long value = 0;
  char c;
  
  if (!(*buf >= '0' && *buf <= '9'))
    return -1;

  /* Translate an hexadecimal value. */
  if (*buf == '0' && (buf[1] == 'x' || buf[1] == 'X'))
    {
      buf += 2;
      while ((c = *buf++))
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else if (c >= 'a' && c <= 'f')
	    c = c - 'a' + 10;
	  else if (c >= 'A' && c <= 'F')
	    c = c - 'A' + 10;
	  else if (c >= 'a' && c <= 'z')
	    return -1;
          else if (c >= 'A' && c <= 'Z')
            return -1;
          else
            {
              buf--;
              break;
            }

	  value = (value << 4) | (long) ((unsigned) c);
	}
      v = value;
      return 0;
    }
  else
    {
      int sign = 0;

      if (buf[0] == '-')
	{
	  sign = 1;
	  buf++;
	}
      while ((c = *buf++) != 0)
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else if (c >= 'a' && c <= 'Z')
	    return -1;
          else if (c >= 'A' && c <= 'Z')
            return -1;
          else
            {
              buf--;
              break;
            }
	  value = (value * 10) + (long) c;
	}
      if (sign)
	value = -value;
      v = value;
      return 0;
    }
  return -1;
}

// Parse a terminal expression
Expression* Expression::parse_term(const char*& line)
{
  enum token t = get_token (line);
  if (t == T_PARENT_OPEN)
    {
      Expression* e = parse_unary (line);
      if (e == 0)
        return 0;

      t = get_token (line);
      if (t == T_PARENT_CLOSE)
        return e;

      rewind (t, line);
      delete e;
      return 0;
    }
  if (t == T_DIGIT)
    {
      rewind (t, line);
      Value val;
      if (get_value (line, val) != 0)
        return 0;

      Expression* e = new ValueExpression (val);
      return e;
    }
  return 0;
}

Expression* Expression::parse(const char*& line)
{
  return parse_unary (line);
}

