/* Small Calculator example program
   Copyright (C) 1999, 2000, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page calculator Simple integer calculator.
   
  This program is a simple calculator which has a stack of integer
  values. It defines commands to:
  <ul>
   <li>Push integer values on the stack.
       These values are either in decimal or hexadecimal (0x prefix)
   <li>Do simple operations on top most values on the stack.
       Operands are popped from the stack and the result is pushed back.
   <li>Select the format of the output result and list the content of the
       stack.
  </ul>

  @htmlonly
  Source file: <a href="calc_8c-source.html">calc.c</a>
  @endhtmlonly

*/

#include "calc.h"
#include <stdarg.h>
#include <stdio.h>

/* List of commands with a description string. */
static const command commands[] = {
  {
    "add",
    OP_ADD,
    "Pop two values and push their sum"
  } , {
    "sub",
    OP_SUB,
    "Pop two values and push their subtraction"
  } , {
    "mul",
    OP_MUL,
    "Pop two values and push their mul"
  } , {    
    "div",
    OP_DIV,
    "Divide the two values"
  } , {
    "mod",
    OP_MOD
  } , {
    "and",
    OP_AND,
    "Logical and between the two values"
  } , {
    "or",
    OP_OR,
    "Logical or between the two values"
  } , {
    "xor",
    OP_XOR
  } , {
    "not",
    OP_NOT
  } , {
    "neg",
    OP_NEG
  } , {
    "sqrt",
    OP_SQRT,
    "Square root of the value"
  } , {
    "quit",
    OP_QUIT,
    "Quit the calculator"
  } , {
    "list",
    OP_LIST,
    "List the stack"
  } , {
    "help",
    OP_HELP,
    "This help"
  } , {
    "dec",
    OP_DEC,
    "Switch in decimal mode"
  } , {
    "hex",
    OP_HEX,
    "Switch in hexadecimal mode"
  } , {
    0,
    0,
    0
  }
};


/* Implementation of some libc methods. */
int
strcmp (const char* s1, const char* s2)
{
  while (*s1 && (*s1 == *s2))
    s1++, s2++;

  return *s1 - *s2;
}

static char*
hex_convert(char* buf, value_t value)
{
  char num[32];
  int pos;
  
  *buf++ = '0';
  *buf++ = 'x';

  pos = 0;
  while (value != 0)
    {
      char c = value & 0x0F;
      num[pos++] = "0123456789ABCDEF"[(unsigned) c];
      value = (value >> 4) & HEX_CVT_MASK;
    }
  if (pos == 0)
    num[pos++] = '0';

  while (--pos >= 0)
    *buf++ = num[pos];
  
  *buf = 0;
  return buf;
}

static char*
dec_convert(char* buf, value_t value)
{
  char num[20];
  int pos;

  pos = 0;
  if (value < 0)
    {
      *buf++ = '-';
      value = -value;
    }
  while (value != 0)
    {
      char c = value % 10;
      value = value / 10;
      num[pos++] = c + '0';
    }
  if (pos == 0)
    num[pos++] = '0';

  while (--pos >= 0)
    {
      *buf = num[pos];
      buf++;
    }
  *buf = 0;
  return buf;
}

/* A very simple sprintf. It only recognizes %d and %x.
   The parameter MUST be of type 'value_t'. Otherwise, you will not get
   the expected result! */
int
sprintf (char* buf, const char* pattern, ...)
{
  va_list argp;
  char* p = buf;
  char c;
  
  va_start (argp, pattern);
  while ((c = *pattern++) != 0)
    {
      if (c != '%')
	{
	  *p++ = c;
	}
      else
	{
	  value_t v;

	  c = *pattern++;
          if (c == 'l')
            c = *pattern++;
          
	  switch (c)
	    {
	    case 'b':
	    case 'o':
	    case 'x':
	      v = va_arg (argp, vavalue_t);
	      p = hex_convert (p, v);
	      break;

	    case 'd':
	      v = va_arg (argp, vavalue_t);
	      p = dec_convert (p, v);
	      break;

	    default:
	      *p++ = '%';
	      *p++ = c;
	      break;
	    }
	}
    }
  va_end (argp);
  *p++ = 0;
  return (int) (p - buf);
}

/* Push a new value on the stack. Returns 0 if this succeeded and -1 if
   the stack is full. */
int
push_value(value_stack_t* stack, value_t v)
{
  if (stack->top >= stack->max)
    return -1;

  stack->values[stack->top++] = v;
  return 0;
}

/* Pop a value from the stack. If the stack is empty, returns 0. */
value_t
pop_value(value_stack_t* stack)
{
  if (stack->top == 0)
    return 0;

  return stack->values[--stack->top];
}

/* Do some logical or arithmetic operation with top-most values of the
   stack. */
int
operation(value_stack_t* stack, enum op_type op)
{
  int result;
  
  switch (op)
    {
    case OP_ADD:
      result = push_value (stack, pop_value (stack) + pop_value (stack));
      break;
      
    case OP_SUB:
      result = push_value (stack, pop_value (stack) - pop_value (stack));
      break;

    case OP_MUL:
      result = push_value (stack, pop_value (stack) * pop_value (stack));
      break;

    case OP_DIV:
      result = push_value (stack, pop_value (stack) / pop_value (stack));
      break;

    case OP_MOD:
      result = push_value (stack, pop_value (stack) % pop_value (stack));
      break;

    case OP_AND:
      result = push_value (stack, pop_value (stack) & pop_value (stack));
      break;

    case OP_OR:
      result = push_value (stack, pop_value (stack) | pop_value (stack));
      break;

    case OP_XOR:
      result = push_value (stack, pop_value (stack) ^ pop_value (stack));
      break;

    case OP_NOT:
      result = push_value (stack, ~pop_value (stack));
      break;

    case OP_NEG:
      result = push_value (stack, -pop_value (stack));
      break;

    case OP_SQRT:
      result = push_value (stack, calc_sqrt (pop_value (stack)));
      break;
      
    default:
      result = 0;
      break;
    }
  return result;
}

void
print_value(value_stack_t* stack, print_mode mode, int which)
{
  char buf[40];
  value_t value;

  static const char* const print_formats[] = {
    " %d\r\n",
    " %x\r\n",
    " %o\r\n",
    " %b\r\n"
  };

  /* Print the top of the stack if no index is specified. */
  if (which < 0)
    {
      which = stack->top - 1;
      if (which < 0)
	{
	  print ("Stack is empty\n");
	  return;
	}
      /* Note: we have to cast the value to 'vavalue_t' because the
	 basic sprintf implementation is hard coded with it. If we
	 are compiled with -mshort and using a long or long long,
	 we won't get the expected result... */
      sprintf (buf, "Top (%ld) = ", (vavalue_t) stack->top);
      print (buf);
    }
  else
    {
      sprintf (buf, "[%ld] = ", (vavalue_t) which);
      print (buf);
    }
  
  if (which >= 0 && which < stack->top)
    value = stack->values[which];
  else
    value = 0;

  sprintf (buf, print_formats[mode], value);
  print (buf);
}

/* Try to translate a string into a number. We look first for hexadecimal
   format, octal and then decimal. If the string could be converted, the
   value is returned in `v' and the function returns 0. Otherwise, it
   returns -1. */
static int
get_value(const char* buf, value_t* v)
{
  value_t value = 0;
  char c;
  
  if (!(*buf >= '0' && *buf <= '9'))
    return -1;

  /* Translate an hexadecimal value. */
  if (*buf == '0' && (buf[1] == 'x' || buf[1] == 'X'))
    {
      buf += 2;
      while ((c = *buf++))
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else if (c >= 'a' && c <= 'f')
	    c = c - 'a' + 10;
	  else if (c >= 'A' && c <= 'F')
	    c = c - 'A' + 10;
	  else
	    return -1;

	  value = (value << 4) | (value_t) ((unsigned) c);
	}
      *v = value;
      return 0;
    }
  else
    {
      int sign = 0;

      if (buf[0] == '-')
	{
	  sign = 1;
	  buf++;
	}
      while ((c = *buf++) != 0)
	{
	  if (c >= '0' && c <= '9')
	    c = c - '0';
	  else
	    return -1;

	  value = (value * 10) + (value_t) c;
	}
      if (sign)
	value = -value;
      *v = value;
      return 0;
    }
  return -1;
}

/* Busy loop to wait for a command or a valid number. */
static op_type
calc_wait_command(value_t* v)
{
  char buf[64];
  int pos;
  char c;

  while (1)
    {
      int i;
      
      pos = 0;
      while (1)
	{
	  c = serial_recv ();
	  if (c == '\r' || c == '\n')
	    break;

	  if (c == '\b')
	    {
	      print ("\b \b");
	      pos--;
	      if (pos < 0)
		pos = 0;
	    }
	  else
	    {
	      buf[pos] = c;
              buf[pos+1] = 0;
              print (&buf[pos]);
	      pos++;
	    }
	}

      print ("\n");
      buf[pos] = 0;

      if (get_value (buf, v) == 0)
	return OP_NUMBER;
      
      for (i = 0; commands[i].name; i++)
	{
	  if (strcmp (commands[i].name, buf) == 0)
	    return commands[i].type;
	}
      print ("\nOperation not recognized.\r\n");
    }
}

static void
print_help()
{
  int i;
  
#ifdef VALUE_16
  print ("16-bit Integer Calculator\n");
#elif defined(VALUE_32)
  print ("32-bit Integer Calculator\n");
#else
  print ("64-bit Integer Calculator\n");
#endif

  for (i = 0; commands[i].name; i++)
    {
      if (commands[i].help == 0)
	continue;

      print (commands[i].name);
      print (" \t");
      print (commands[i].help);
      print ("\n");
    }
}

int
calc_loop(value_stack_t* stack)
{
  op_type op;
  int result;
  value_t value;
  int i;

  print_help ();
  while (1)
    {
      print_value (stack, stack->mode, -1);
      
      op = calc_wait_command (&value);
      switch (op)
	{
	case OP_QUIT:
	  return 0;

	case OP_NUMBER:
	  result = push_value (stack, value);
          if (result != 0)
            {
              print ("The stack is full.\n");
            }
	  break;

	case OP_DEC:
	  stack->mode = PRINT_DEC;
	  break;

	case OP_HEX:
	  stack->mode = PRINT_HEX;
	  break;

	case OP_LIST:
	  for (i = 0; i < stack->top; i++)
	    print_value (stack, stack->mode, i);
	  break;
	  
	case OP_HELP:
	  print_help ();
	  break;
	  
	default:
	  result = operation (stack, op);
	  break;
	}
    }
}

int main()
{
  value_t val_table[10];
  value_stack_t values;

  serial_init ();
  
  values.top    = 0;
  values.values = val_table;
  values.max    = 10;
  values.mode   = PRINT_DEC;

  print ("Simple Calculator Test Program\n");
  calc_loop (&values);
  return 0;
}
