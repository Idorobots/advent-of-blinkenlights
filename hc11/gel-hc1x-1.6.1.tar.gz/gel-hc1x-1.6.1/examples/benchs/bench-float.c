/* Benchmark for some float and double operations
   Copyright (C) 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page bench-float Benchmark for some floating point operations.

   This program benchmarks the following operations:

   <ul>
     <li>32-bit float mul, add, sub, div, neg.
     <li>64-bit float mul, add, sub, div, neg.
   </ul>

  @htmlonly
  <BENCH_RESULTS>

  Source file: <a href="bench-float_8c-source.html">bench-float.c</a>
  @endhtmlonly

 */
/*@{*/

#include <benchs.h>

/* Forward declaration.  */
void bench_double (bench_t *b);
void bench_float (bench_t *b);


/* Use global variables to forbid Gcc from doing some optimization.  */
double a = 3.141592;
float f = 3.141592;

/* Benchmark some floating point operations (mul, add, neg, div, ...).  */
void
bench_float (bench_t *b)
{
  long n;
  
  bench_start (b);
  f = f * f;
  bench_stop (b);
  bench_report (b, "Float mul (%d)", (long) f);

  bench_start (b);
  f = f + f;
  bench_stop (b);
  bench_report (b, "Float add (%d)", (long) f);

  bench_start (b);
  f = -f;
  bench_stop (b);
  bench_report (b, "Float neg (%d)", (long) f);

  bench_start (b);
  f = f / 0.1;
  bench_stop (b);
  bench_report (b, "Float div (%d)", (long) f);

  f = f + 2.0;
  bench_start (b);
  n = f;
  bench_stop (b);
  bench_report (b, "Float to long (%d)", n);

  n += 2;
  bench_start (b);
  f = n;
  bench_stop (b);
  bench_report (b, "Long to float (%d)", n);
}

/* Same as bench_float but using 64-bit double.  */
void
bench_double (bench_t *b)
{
  long n;
  
  bench_start (b);
  a = a * a;
  bench_stop (b);
  bench_report (b, "Double mul (%d)", (long) a);

  bench_start (b);
  a = a + a;
  bench_stop (b);
  bench_report (b, "Double add (%d)", (long) a);

  bench_start (b);
  a = -a;
  bench_stop (b);
  bench_report (b, "Double neg (%d)", (long) a);

  bench_start (b);
  a = a / 0.1;
  bench_stop (b);
  bench_report (b, "Double div (%d)", (long) a);

  a = a + 3.1;
  bench_start (b);
  n = a;
  bench_stop (b);
  bench_report (b, "Double to long (%d)", n);

  n += 2;
  bench_start (b);
  a = n;
  bench_stop (b);
  bench_report (b, "Long to double (%d)", (long) a);
}

/* Main, run the benchmarks.  */
int
main ()
{
  bench_t b;
  
  bench_init (&b);
  bench_float (&b);
  bench_double (&b);

  return 0;
}
/*@}*/
