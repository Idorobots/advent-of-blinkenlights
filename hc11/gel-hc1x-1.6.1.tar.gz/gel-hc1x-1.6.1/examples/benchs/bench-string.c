/* Benchmark for some string functions
   Copyright (C) 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page bench-string Benchmark for some string operations.

   This program benchmarks the following operations:

   <ul>
     <li>strcpy,
     <li>strlen,
     <li>strcat,
     <li>strcmp,
     <li>strrchr,
     <li>memcpy,
     <li>memcmp,
     <li>strstr.
   </ul>

  @htmlonly
  Source file: <a href="bench-string_8c-source.html">bench-string.c</a>
  <BENCH_RESULTS>

  @endhtmlonly

 */
/*@{*/

#include <benchs.h>
#include <stddef.h>
#include <string.h>

/* Forward declaration.  */
int strcmp_for_bench (const char *s1, const char *s2);
void bench_string (bench_t *b);


/* The goal of this benchmark is to measure the generated code
   for some frequently used str* functions.  That's why we don't
   use any C-library here (such as newlib).  */

char *
strcpy (char * dest, const char *src)
{
  char *tmp = dest;

  while ((*dest++ = *src++) != '\0')
    /* nothing */;
  return tmp;
}

char *
strcat (char *dest, const char *src)
{
  char *tmp = dest;

  while (*dest)
    dest++;
  while ((*dest++ = *src++) != '\0')
    ;

  return tmp;
}

int
strcmp_for_bench (const char *cs, const char *ct)
{
  register signed char __res;

  while (1) {
    if ((__res = *cs - *ct++) != 0 || !*cs++)
      break;
  }

  return __res;
}

char *
strrchr (const char *s, int c)
{
  const char *p = s + strlen(s);
  do {
    if (*p == (char)c)
      return (char *)p;
  } while (--p >= s);
  return NULL;
}

void *
memcpy (void *dest, const void *src, size_t count)
{
  char *tmp = (char *) dest, *s = (char *) src;

  while (count--)
    *tmp++ = *s++;

  return dest;
}

int
memcmp (const void *cs, const void * ct, size_t count)
{
  const unsigned char *su1, *su2;
  signed char res = 0;

  for( su1 = cs, su2 = ct; 0 < count; ++su1, ++su2, count--)
    if ((res = *su1 - *su2) != 0)
      break;
  return res;
}

char *
strstr (const char * s1, const char * s2)
{
  int l1, l2;

  l2 = strlen(s2);
  if (!l2)
    return (char *) s1;
  l1 = strlen(s1);
  while (l1 >= l2) {
    l1--;
    if (!memcmp(s1,s2,l2))
      return (char *) s1;
    s1++;
  }
  return NULL;
}
#define MAX_LENGTH 64

/* Benchmark the walk of a single linked list having 100 elements.  */
void
bench_string (bench_t *b)
{
  char buf[MAX_LENGTH];
  int res;
  char *p;
  
  /* strcpy with a constant string.  */
  bench_start (b);
  strcpy (buf, "0");
  bench_stop (b);
  bench_report (b, "strcpy length %d", (long) strlen (buf));

  bench_start (b);
  strcpy (buf, "0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strcpy length %d", (long) strlen (buf));

  bench_start (b);
  strcpy (buf, "0123456789abcdef0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strcpy length %d", (long) strlen (buf));

  buf[0] = 0;
  bench_start (b);
  strcat (buf, "0");
  bench_stop (b);
  bench_report (b, "strcat length %d", (long) strlen (buf));

  bench_start (b);
  strcat (buf, "0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strcat length %d", (long) strlen (buf));
  
  bench_start (b);
  strcat (buf, "0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strcat length %d", (long) strlen (buf));
  
  strcpy (buf, "0");
  bench_start (b);
  res = strlen (buf);
  bench_stop (b);
  bench_report (b, "strlen length %d", (long) res);

  strcat (buf, "0123456789abcdef");
  bench_start (b);
  res = strlen (buf);
  bench_stop (b);
  bench_report (b, "strlen length %d", (long) res);

  strcat (buf, "0123456789abcdef");
  bench_start (b);
  res = strlen (buf);
  bench_stop (b);
  bench_report (b, "strlen length %d", (long) res);

  bench_start (b);
  res = strcmp_for_bench (buf, "0123456789abcdef0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strcmp length %d, %d", (long) strlen (buf),
                (long) res);

  bench_start (b);
  p = strrchr (buf, '0');
  bench_stop (b);
  bench_report (b, "strrchr at %d", (long) (size_t) (p - buf));

  bench_start (b);
  p = strstr (buf, "f0123456789abcdef");
  bench_stop (b);
  bench_report (b, "strstr at %d", (long) (size_t) (p - buf));
  
}

/* Main, run the benchmarks.  */
int
main ()
{
  bench_t b;

  bench_init (&b);
  bench_string (&b);
  return 0;
}

/*@}*/
