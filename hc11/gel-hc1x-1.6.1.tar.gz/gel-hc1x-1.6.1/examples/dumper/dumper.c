/* dumper.c -- Dump content of memory.
   Copyright 2000, 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GTAM.

GTAM is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GTAM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GTAM; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page dumper Dump the content of memory.

  This 68HC11 bootstrap program dumps the target memory.  It supports
  the following commands:

  <dl>
    <dt>R{ADDR-HIGH}{ADDR-LOW}{SIZE}
    <dd>Read the memory and dump it.

    <dt>Z
    <dd>Reboots.
  </dl>

  This bootstrap program is uploaded by GTAM to dump the content of
  memory and I/O registers.  It is also used to guess the CPU configuration
  by reading the bootrom mask ID.

  Implementation Notes:

     -# This program must not be linked with a startup file.  It implements
        the startup entry point.
     -# The \c _start function must be at beginning of this file.
        By doing so, it will be mapped at address 0 by the linker and
        we avoid to have some jump to call it (since the boot will
        jump there).
     -# It must be compiled with \b -mshort \b -Os \b -fomit-frame-pointer
        to make sure it fits in less than 240 bytes (keep a few bytes at
        end for the stack).
     -# It must be compiled with \b -msoft-reg-count=0 or =1 to reduce the
        use of soft-registers (since they are mapped in RAM in .page0).
     -# Before dumping the memory, we switch the bus in the expanded mode.
        We switch back to single chip before rebooting.
     -# The soft registers must be located at beginning of the .page0.
        This will clobber the beginning of the \c _start function.
        We don't care because this clobbers some initialisation part.
     -# Compile with \b -DNO_REBOOT to avoid the reboot.  In that case,
        the program loops indefinately checking the memory regions.
     -# Compile with \b -DNO_BREAK to avoid detection of break sent by
        the host.  With current implementation of GCC, the code is
        too big (some bytes) and it should not be compiled.
  
  Caveats:
  <ul>
    <li>Memory is dumped in binary.
  </ul>

  @htmlonly
  Source file: <a href="dumper_c-source.html">dumper.c</a>
  @endhtmlonly

*/

#include <sys/ports.h>

int __attribute__((noreturn)) main (void);
static unsigned short get_char (void);
void _start (void);

void
_start ()
{
  set_bus_expanded ();

  main ();
}

/* Write a character on the serial line.  */
static void
put_char (unsigned char c)
{
  while (!(_io_ports[M6811_SCSR] & M6811_TDRE))
    continue;

  _io_ports[M6811_SCDR] = c;
  _io_ports[M6811_SCCR2] |= M6811_TE;
}

/* Write an escaped byte on the serial line.  */
static void
put_byte (unsigned char c)
{
  /* Don't send \n and escape directly as they may confuse some
     synchronisation.  */
  if (c == '\n' || c == '\033')
    {
      put_char ('\033');
      c ^= 0x20;
    }
  put_char (c);
}

static inline void
reboot()
{
#ifndef NO_REBOOT
  /* The 'func' type is marked as 'noreturn' to optimize the
     generated code.  */
  typedef void __attribute__ ((noreturn)) (* func)();

  func handler;

  set_bus_single_chip ();

  /* To reboot, get the reset vector and go to the start of the ROM.  */
  handler = *((func*) 0xbffe);
  handler ();
#endif
}

int
main ()
{
  unsigned char* addr;
  unsigned char c;
  
  while (1)
    {
      /* Print banner for synchronization.  */
      put_char ('\n');
      put_char ('>');

      /* Wait for command.  */
      c = get_char ();

      /* Read memory command.  Command format is:

         R<ADDR-HIGH><ADDR-LOW><SIZE>

         Address and size are passed in binary form.
         A size of 0 corresponds to 256 bytes.

         We reply with:

         <SIZE><DATA><CRC>

         where size, data and crc are returned in binary form.  */
      if (c == 'R')
        {
          unsigned char size;
          unsigned char crc;
          
          c = get_char ();
          addr = (unsigned char*) ((c << 8) | get_char ());
          size = get_char ();

          /* Give a feedback about what we are going to send.  */
          put_byte (size);

          crc = 0;
          do
            {
              c = *addr++;
              crc ^= c;
              put_byte (c);
            }
          while (--size != 0);
          put_byte (crc);
        }

      /* Reboot command.  Command format is:

         Z

         We reply with a Z.  The final \n is not seen because it is
         clobbered during the reboot.  */
      else if (c == 'Z')
        {
          put_char (c);
          put_char ('\n');

          reboot ();
        }

      /* For others, emit something to tell we are alive.  */
      else
        {
          put_char ('?');
        }
    }
}

#ifndef NO_BREAK
static inline void
restart ()
{
  unsigned short i;
  volatile unsigned char* ports = &_io_ports[0];

  /* Wait for the transmitter to be ready.  */
  while (!(ports[M6811_SCSR] & M6811_TDRE))
    continue;
  
  /* Send a break.  */
  ports[M6811_SCCR2] |= M6811_SBK;

  /* Wait some time (??? is it necessary ???).  */
  for (i = 1000; --i != 0;)
    (void) ports[M6811_TCNT];

  ports[M6811_SCCR2] &= ~M6811_SBK;

  /* Go back to the main with some longjump.  We can't go to _start()
     because it was clobbered by the ZTMP and ZREG registers.  */
  __asm__ __volatile__ ("lds #0x0ff");
  __asm__ __volatile__ ("bra main");
}
#endif

static unsigned short
get_char ()
{
  unsigned char c;
  volatile unsigned char* ports = &_io_ports[0];
  
  while (1)
    {
      c = ports[M6811_SCSR];

#ifndef NO_BREAK
      /* If there is a read error or a break, abort everything and
         restart.  When restarting we send a break so that the host
         knows we are restarting.  */
      if (c & M6811_FE)
        restart ();
#endif

      if (c & M6811_RDRF)
        break;
    }
  return ports[M6811_SCDR];
}
