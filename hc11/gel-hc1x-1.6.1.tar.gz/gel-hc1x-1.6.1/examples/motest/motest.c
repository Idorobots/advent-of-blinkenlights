/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*
 * motest.c assists the construction of a mtr_tab file.  When run
 * it should first turn on both motors (without pwm control) which
 * will cause them to run at top speed.  The output will show the
 * number of encoder ticks which represents top speed.  When you 
 * press a key, the pwm control comes on at a very low setting. The
 * display now shows both the current pwm setting and the resulting
 * encoder count.  Continue to press keys to cause the pwm period to
 * increase.  Note values that seem to result in stable encoder counts
 * and use them to build a new mtr_tab.h file. 
 */

#include <sys/locks.h>
#include <sys/ports.h>
#include <bot/bot.h>

#define INCR 1

char signon[] = "\nspace key to resample; any other to continue\n";
char buf[80];
char token;

int
main()
{
  static int avg;

  /* disable interrupts to initialize system */
  lock();
  /* run 68hc11 in expanded bus mode */
  set_bus_expanded();
  /* initialize buffered serial I/O */
  init_buffered_io();
  /* initialize system clock */
  init_sysclock();
  /* initialize encoder services */
  init_encoders();
  /* initialize pwm service */
  init_pwm();
  /* initialize sensor sampling */
  init_poll_sensors();
  /* enable interrupts */
  unlock();

  /* print signon message to serial port */
  serial_print(signon);
  /* turn on motors to get top speed in encoder ticks */
  pwm_off();
  digital_shadowbits |= LEFT_MTR | RIGHT_MTR;
  DIGITAL_PORT = digital_shadowbits;
  while ((token = sci_getc()) == ' ') {
    /* print data for top possible speed */
    sprintf(buf,"Top speed: %d  --  %d\n", le_sample, re_sample);
    serial_print(buf);
  }
  /* now step pwm period up to top speed showing encoder counts */
  Lmtr = Rmtr = 1000; pwm_on();
  sprintf(buf,"\n+ to incr; - to decr; other to resample\n");
  serial_print(buf);
  while (1) {  /* no exit */
    /* block waiting for serial input */
    token = sci_getc();
    /* possibly in/decrement duty cycle values */
    if (token == '-') { Lmtr -= INCR; Rmtr = Lmtr; }
    if (token == '+') { Lmtr += INCR; Rmtr = Lmtr; }
    /* print current duty cycle and left/right speed */
    avg = (le_sample + re_sample) /2;
    sprintf(buf,"%d  %d:%d  %d\n", Lmtr, le_sample, re_sample, avg);
    serial_print(buf);
  }
}
