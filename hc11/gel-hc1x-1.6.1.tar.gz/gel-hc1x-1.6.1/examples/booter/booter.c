/* booter.c -- External RAM booter
   Copyright 2000, 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GTAM.

GTAM is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GTAM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GTAM; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page booter External RAM booter.

  This 68HC11 bootstrap program acts as a simple server for uploading
  a program in external memory.  It supports only two commands:

  M{ADDR-HIGH}{ADDR-LOW}{SIZE}[{DATA}]

     Write the memory at given address.


  G{ADDR-HIGH}{ADDR-LOW}

     Jump to program at given address.


  This bootstrap program is uploaded by GTAM to be able to upload
  larger program in external RAM.

  Implementation Notes:

     -# This program must not be linked with a startup file.  It implements
        the startup entry point.
     -# The \c _start function must be at beginning of this file.
        By doing so, it will be mapped at address 0 by the linker and
        we avoid to have some jump to call it (since the boot will
        jump there).
     -# It must be compiled with \b -mshort \b -Os \b -fomit-frame-pointer
        to make sure it fits in less than 240 bytes (keep a few bytes at
        end for the stack).
     -# It must be compiled with \b -msoft-reg-count=0 or =1 to reduce the
        use of soft-registers (since they are mapped in RAM in .page0).
     -# The pointer used to write the memory is marked \b volatile to prevent
        GCC from optimizing memory accesses.  We rely on this for the good
        computation of the CRC.
     -# Before scanning the memory, we switch the bus in the expanded mode.
        We do not switch back to single chip when jumping to the program.
     -# The soft registers must be located at beginning of the .page0.
        This will clobber the beginning of the \c _start function.
        We don't care because this clobbers some initialisation part.

  Caveats:
  <ul>
     <li>Another booter program is necessary to upload in EEPROM.

     <li>It is not possible to write in the 68HC11 RAM.  We don't check
         for this and this will probably crash.
  </ul>

  @htmlonly
  Source file: <a href="booter_8c-source.html">booter.c</a>
  @endhtmlonly

*/

#include <sys/ports.h>

typedef void __attribute__ ((noreturn)) (* func)();

static unsigned short get_char (void);
static unsigned char* get_addr (void);
static void restart (void);
volatile int __attribute__((noreturn)) main (void);
static void flush (void);
void _start (void);

void
_start()
{
  /* Switch to 9600 baud.  */
  flush ();
#if 0
  _io_ports[M6811_BAUD] = 0x30;
#endif
  set_bus_expanded ();

  __asm__ __volatile__ ("bra main");
  /* main (); */
}

static void
flush ()
{
  while (!(_io_ports[M6811_SCSR] & M6811_TDRE))
    continue;
}

static void
put_char (unsigned char c)
{
  flush ();
  _io_ports[M6811_SCDR] = c;
  _io_ports[M6811_SCCR2] |= M6811_TE;
}

volatile int
main ()
{
  volatile unsigned char* addr;
  unsigned char c;
  
  while (1)
    {
      /* Print banner for synchronization.  */
      put_char ('\n');
      put_char ('>');

      /* Wait for command.  */
      c = get_char ();

      /* Write memory command.  Command format is:

         M<ADDR-HIGH><ADDR-LOW><SIZE>[<DATA>]

         Address, size and data are passed in binary form.
         A size of 0 corresponds to 256 bytes.
         
         After writing the memory, we read it back and compute
         a crc that is then returned.  */
      if (c == 'M')
        {
          unsigned char crc;
          unsigned char size;
          
          addr = get_addr ();
          size = get_char ();
          crc = 0;
          do
            {
              *addr = get_char ();
              crc ^= *addr++;
            }
          while (--size != 0);

          /* Report the crc in pseudo hexa.  GTAM checks the crc to verify
             that what was written is correct.  */
          put_char (((crc >> 4) & 0x0F) + '0');
          put_char ((crc & 0x0F) + '0');
        }

      /* Go command.  Command format is:

         G<ADDR-HIGH><ADDR-LOW>

         We reply with a G.  Depending on the program, the final \n
         may not be received since we don't wait for it to be sent.  */
      else if (c == 'G')
        {
          func handler;
            
          addr = get_addr ();
          put_char ('G');
          put_char ('\n');
          flush ();

          handler = (func) addr;
          handler ();
        }

      /* For others, emit something to tell we are alive.  */
      else
        {
          put_char ('?');
        }
    }
}

static unsigned char*
get_addr ()
{
  unsigned short c1, c2;

  c1 = get_char ();
  c2 = get_char ();
  return (unsigned char*) (((unsigned short) c1 << 8) | ((unsigned short) c2));
}

static inline void
restart ()
{
  volatile unsigned char* ports = &_io_ports[0];

  /* Wait for the transmitter to be ready.  */
  while (!(ports[M6811_SCSR] & M6811_TDRE))
    continue;
  
  /* Send a break.  */
  ports[M6811_SCCR2] |= M6811_SBK;

  /* Wait some time (??? is it necessary ???).  */
#if 0
  for (i = 1000; --i != 0;)
    (void) ports[M6811_TCNT];
#endif
  ports[M6811_SCCR2] &= ~M6811_SBK;

  /* Go back to the main with some longjump.  We can't go to _start()
     because it was clobbered by the ZTMP and ZREG registers.  */
  __asm__ __volatile__ ("lds #0x0ff");
  __asm__ __volatile__ ("bra main");
}

static unsigned short
get_char ()
{
  unsigned char c;
  volatile unsigned char* ports = &_io_ports[0];
  
  while (1)
    {
      c = ports[M6811_SCSR];

      /* If there is a read error or a break, abort everything and
         restart.  When restarting we send a break so that the host
         knows we are restarting.  */
      if (c & M6811_FE)
        restart ();

      if (c & M6811_RDRF)
        break;
    }
  return ports[M6811_SCDR];
}
