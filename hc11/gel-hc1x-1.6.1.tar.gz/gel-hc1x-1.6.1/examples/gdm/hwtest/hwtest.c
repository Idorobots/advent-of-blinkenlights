/* Graphics Display Board Specific Operations Tests
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page gdm_hwtest Simple Graphics Hardware Test

    The \b hwtest is a small test to verify the correct behavior
    of the board specific operations that control the graphic dot matrix.
    It only uses the \b _gdm_hw_xxx operations (see \ref gdm_hw).

    If the GDM12864 is connected and has proper board specific operations,
    the test shows crossing lines on the complete display.  These crossing
    lines are progressively erased by a 8x8 square that moves from left to
    right and top to bottom.  Once the display is erased, the crossing lines
    are drawn again.

  @htmlonly
  Source file: <a href="hwtest_8c-source.html">hwtest.c</a>
  @endhtmlonly

 */

#include <gdm/display.h>
#include <gdm/display-hw.h>
#include <time.h>

gdm_display display;

/* Draw a small filled 8x8 square at the LCD X, Y location.  */
static void
draw (unsigned short x, unsigned short y, unsigned char data)
{
  unsigned short y1;

  for (y1 = y; y1 < y + 8 && y1 < 128; y1++)
    {
      unsigned char line = y1 < 64;

      _gdm_hw_set_side (&display, line);
      _gdm_hw_set_x (&display, x);
      _gdm_hw_set_y (&display, y1 >= 64 ? y1 - 64 : y1);
      _gdm_hw_set_data (&display, data);
    }
}

/* Draw on the complete LCD display several crossing lines.  */
static void
draw_crossing (unsigned short cnt)
{
  unsigned short x1, y1;

  /* Set the full display to crossing lines.  */
  for (x1 = 0; x1 <= 7; x1++)
    {
      unsigned short line;

      for (line = 0; line < 2; line++)
        {
          _gdm_hw_set_side (&display, line);
          _gdm_hw_set_x (&display, x1);
          _gdm_hw_set_y (&display, 0);
          for (y1 = 0; y1 < 64; y1++)
            {
              unsigned char val;

              val = 1 << ((cnt + y1) & 7);
              val |= 1 << ((cnt - y1) & 7);
              _gdm_hw_set_data (&display, val);
            }
        }
    }
}

int
main ()
{
  unsigned short x = 0;
  unsigned short y = 0;
  unsigned cnt = 0;
  unsigned short oldx = 0;
  unsigned short oldy = 0;
  unsigned short test = 0;

  gdm_initialize (&display);

  while (1)
    {
      switch (test % 2)
        {
        case 0:
          /* Draw the crossing lines on the display.  */
          draw_crossing (cnt++);
          udelay (10000);
          test++;
          break;

        case 1:
          /* Erase previous square and redraw it at its
             new location.  */
          draw (oldx, oldy, 0x00);
          oldx = x;
          oldy = y;
          draw (x, y++, 0xFF);
          udelay (100000);

          if (y >= 128)
            {
              y = 0;
              x++;
              if (x >= 8)
                {
                  test++;
                  x = 0;
                }
            }
          break;
        }
    }
}
