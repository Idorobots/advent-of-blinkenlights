/* Fractal Example on 128x64 display
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page gdm_fractals Fractal Example

   The \c fractals example draws fractals on the 128x64 graphical display.

  @htmlonly
  Source file: <a href="simple_8c-source.html">simple.c</a>
  @endhtmlonly

 */

#include <gdm/display.h>
#include <stdlib.h>

gdm_display display;

static void
fractal_line (short x1, short y1, short x2, short y2, short recurse)
{
  if (x1 == x2 && y1 == y2)
    {
      gdm_draw_point (&display, x1, y1);
    }
  else if (recurse <= 0)
    {
      gdm_draw_line (&display, x1, y1, x2, y2);
    }
  else
    {
      short x, y, x3, y3, x4, y4;
      short dx = (x2 - x1) / 3;
      short dy = (y2 - y1) / 3;

      recurse--;
      x = x1 + dx;
      y = y1 + dy;
      fractal_line (x1, y1, x, y, recurse);

      x3 = x - dy;
      y3 = y + dx;
      fractal_line (x, y, x3, y3, recurse);

      x = x2 - dx;
      y = y2 - dy;
      fractal_line (x, y, x2, y2, recurse);

      x4 = x - dy;
      y4 = y + dx;
      fractal_line (x3, y3, x4, y4, recurse);

      fractal_line (x4, y4, x, y, recurse);
    }
}

#define MAXIT 14
#define BASE (8192)
#define F(VAL) ((long) ((VAL) * (double) BASE))
#define PHYSX(VAL) ((short) ((128 * ((VAL) - F(-5.0))) / ((F(5.0) - F(-5.0)))))
#define PHYSY(VAL) ((short) ((64 * ((VAL) - F(0.0))) / ((F(10.0) - F(0.0)))))

void
fern ()
{
  int j;

  for (j = 0; j < 1000; j++)
    {
      int i;
      
      // Temporary x and y values during iterations.
      long  newx;
      long  newy;

      // Get initial x and y values, both between 0 and 1.
      long x = (long) (((unsigned short) rand ()) % (unsigned short) BASE);
      long y = (long) (((unsigned short) rand ()) % (unsigned short) BASE);

      gdm_refresh (&display);
      for (i = 0; i < MAXIT; i++)
        {
          unsigned long  rand_num = ((unsigned short) rand()) % BASE;

          if (rand_num < F(0.01))
            {
              newx = F(0.0);
              newy = (F(0.16) * y) / BASE;
              x = newx;
              y = newy;
            }  // rand_num < 0.01
          else
            if (rand_num < F(0.86))
              {
                newx = ((F(0.85) * x) + (F(0.04) * y)) / BASE;
                newy = ((-F(0.04) * x) + (F(0.85) * y)) / BASE + F(1.6);
                x = newx;
                y = newy;
              }  // (rand_num < 0.86)
            else
              if (rand_num < F(0.93))
                {
                  newx = ((F(0.2) * x) - (F(0.26) * y)) / BASE;
                  newy = ((F(0.23) * x) + (F(0.22) * y)) / BASE + F(1.6);
                  x = newx;
                  y = newy;
                }  // (rand_num < 0.93)
              else
                {
                  newx = ((F(-0.15) * x) + (F(0.28) * y)) / BASE;
                  newy = ((F(0.26) * x) + (F(0.24) * y)) / BASE + F(0.44);
                  x = newx;
                  y = newy;
                }  // (rand_num >= 0.93)
        }  // for (int i = 0; i < MAXIT; i++)

      gdm_draw_point (&display, PHYSX(x), PHYSY(y));
    }
}

static const gdm_point pts[] = {
  { 128, 62 }, { 0, 62},
  { 64, 0}, { 64, 64 },
  { 64, 64}, { 64, 0 },
  { 0, 0}, { 64, 64 },
  { 64, 64}, { 0, 0 },
  { 128, 64}, { 0, 0 },
  { 0, 0}, { 128, 64 }
};

int
main ()
{
  short dt = 1;
  short recurse = 0;
  short orecurse = 0;
  int i = 0;

  gdm_initialize (&display);

  while (1)
    {
      /* First erase the previous fractal.  */
      gdm_set_gc (&display, GDM_PLOT_AND);
      gdm_fill_rectangle (&display, 0, 0, GDM_WIDTH, GDM_HEIGHT);

      /* Draw the new fractal in OR mode because we can touch the
         same pixel several times (due to rounding).  */
      gdm_set_gc (&display, GDM_PLOT_OR);
      fractal_line (pts[i].x, pts[i].y, pts[i+1].x, pts[i+1].y, recurse);

      /* Change fractal recursion.  */
      orecurse = recurse;
      recurse += dt;
      if (recurse > 4)
        {
          dt = -1;
        }
      else if (recurse < 0)
        {
          dt = 1;
          i += 2;
          if (i >= sizeof(pts) / sizeof(pts[0]))
            i = 0;

          gdm_set_gc (&display, GDM_PLOT_AND);
          gdm_fill_rectangle (&display, 0, 0, GDM_WIDTH, GDM_HEIGHT);

          gdm_set_gc (&display, GDM_PLOT_OR);
          fern ();
        }

      gdm_refresh (&display);
    }
}
