/* Line Drawing Example
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page gdm_lines Draw Lines on the LCD

   The \c lines example shows how to use \b gdm_draw_line, \b gdm_draw_circle
   and \b gdm_fill_rectangle.  It draws a line, circle and small rectangle
   that move on the screen.

   @htmlonly
   Source file: <a href="lines_8c-source.html">lines.c</a>
   @endhtmlonly

 */

#include <gdm/display.h>
#include <gdm/display-hw.h>

/* The display control structure (hardware control and image).  */
gdm_display display;

int
main ()
{
  unsigned short x = 0;
  unsigned short y = 0;
  unsigned short w = 31;
  unsigned short h = 31;
  unsigned short ox = 0;
  unsigned short oy = 0;
  unsigned short ow = 0;
  unsigned short oh = 0;
  short lx = 0;
  short ly = 0;
  unsigned short olx = 0;
  unsigned short oly = 0;
  short dx = 1;
  short dy = 0;

  /* Initialize display control.  The display control should be a static
     variable (because it's big).  */
  gdm_initialize (&display);

  /* Setup to use the exclusive OR drawing mode.  */
  gdm_set_gc (&display, GDM_PLOT_XOR);
  while (1)
    {
      if (ow)
        {
          gdm_fill_rectangle (&display, ox, oy, ow, oh);
          gdm_draw_circle (&display, ox, oy, 30);
          gdm_draw_line (&display, 64, 32, olx, oly);
        }
      gdm_fill_rectangle (&display, x, y, w, h);
      gdm_draw_circle (&display, x, y, 30);
      gdm_draw_line (&display, 64, 32, lx, ly);
      ox = x;
      oy = y;
      ow = w;
      oh = h;
      olx = lx;
      oly = ly;
      x++;
      if (x >= 128) {
        x = 0;
        y++;
        if (y > 64)
          y = 0;
      }

      lx += dx;
      if (lx >= 128)
        {
          lx = 127;
          dx = 0;
          dy = 1;
        }
      else if (lx < 0)
        {
          lx = 0;
          dx = 0;
          dy = -1;
        }
      ly += dy;
      if (ly >= 64)
        {
          ly = 63;
          dy = 0;
          dx = -1;
        }
      else if (ly < 0)
        {
          ly = 0;
          dy = 0;
          dx = 1;
        }

      /* gdm_touch (&display, 0, 0, 128, 64);*/
      gdm_refresh (&display);
    }
}
