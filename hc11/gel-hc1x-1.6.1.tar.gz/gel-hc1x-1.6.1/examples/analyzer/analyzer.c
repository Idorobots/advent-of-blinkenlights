/* Simple Logical Analyzer
   Copyright (C) 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*! @page analyzer Simple One-bit Logical Analyzer

    This program is a simple one-bit logical analyzer.  It probes
    the bit 7 of port A and keep track of state changes on that input.
    For each change (0 to 1 or 1 to 0 transition), it keeps track of
    the free running counter (TCNT).  After collecting the samples,
    it report them on the serial line.

    I have used this simple logical analyzer to debug my parallel port
    eprom programmer.  I connected the PA7 input to the CE, OE or PGM
    eprom pin.  I was able to measure the 1ms pulse that I applied on
    the PGM pin.

    The accuracy of level change by the analyzer is in the order of
    50us with a 8Mhz 68HC11.  So, don't expect to analyze frequencies
    above 10Khz (due to Shannon).

  @htmlonly
  Source file: <a href="analyzer_8c-source.html">analyzer.c</a>
  @endhtmlonly

*/
#include "analyzer.h"

#define TIMER_DIV  (8192L)
#define TIMER_TICK (M6811_CPU_E_CLOCK / TIMER_DIV)

/* Setup for a 8Mhz quartz, and prescaler set to 1
   (500ns period).  */
#define USEC_PER_TICK (1)
#define USEC_DIVISOR  (2)

void
collect_samples (sample_list_t *samples)
{
  unsigned i;
  unsigned char current_port;
  sample_t *sample;

  sample = samples->first;
  current_port = _io_ports[M6811_PORTA];
  for (i = samples->length; i != 0; i--, sample++) {
    unsigned char c;

#ifdef TEST
    unsigned k = 0;
#endif
    do {
#ifdef TEST
      if (k == 0) {
        _io_ports[M6811_PORTA] ^= 0x80;
      } else {
        k++;
      }
#endif
      c = current_port ^ _io_ports[M6811_PORTA];
    } while (c == 0);
    sample->tick = get_timer_counter ();
    c = c ^ current_port;
    sample->port = c;
    current_port = c;
  }
}

void
report_samples (sample_list_t *samples)
{
  sample_t *sample;
  unsigned i;
  sample_t *prev;
  
  prev = samples->first;
  sample =  &prev[1];
  for (i = samples->length - 1; i != 0; i--, sample++) {
    unsigned dt;
    unsigned char c;
    unsigned long usec;

    c = sample->port;
    dt = sample->tick - prev->tick;
    usec = (((unsigned long) dt) * USEC_PER_TICK) / USEC_DIVISOR;
    printf ("%lu %lu %c %c %c\n",
            (long) dt, usec,
            (int) (c & 1 ? '1' : '0'),
            (int) (c & 2 ? '1' : '0'),
            (int) (c & 4 ? '1' : '0'));
    prev = sample;
  }
}

#define MAX_SAMPLES (256)

sample_t sample_buffer[MAX_SAMPLES];

int
main ()
{
  sample_list_t list;

  serial_init ();

#ifdef TEST
  _io_ports[M6811_PACTL] |= M6811_DDRA7;
#endif
  list.length = MAX_SAMPLES;
  list.first = sample_buffer;
  lock ();
  while (1)
    {
      collect_samples (&list);
      report_samples (&list);
    }
}
