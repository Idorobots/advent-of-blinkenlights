#!/usr/bin/perl

eval 'exec /usr/bin/perl -S $0 ${1+"$@"}'
	if $running_under_some_shell;

#
# Role :	Print an error message
#
sub error {
    print STDERR "@_\n";
    $ERRORS=1;
}

#
# Role :	Read the result file and format it into HTML table.
#
sub readBenchs {
    local($file) = @_;
    local($doPrint) = 1;

    die "Cannot open $file"
	if (!open (FILE, "<$file"));

    print "<TABLE BORDER='0'>\n";
    print "<TR><TD WIDTH='70%'><B>Name</B></TD><TD><B>Time</B></TD>";
    print "<TD><B>Ticks</B></TD></TR>\n";
    while (<FILE>) {
	local($i);

	chop;

	local(@items) = split("[ \t]+", $_);

	print "<TR><TD WIDTH='70%'>";
	for ($i = 0; $i < $#items - 2; $i++) {
	    if ($i != 0) {
		print " ";
	    }
	    $n=$items[$i];
	    print "$n";
	}
	print "</TD><TD>";
	for (;$i < $#items; $i++) {
	    $n=$items[$i];
	    print " $n";
	}
	print "</TD><TD>";
	print $items[$i];
	print "</TD></TR>\n";
    }
    close(FILE);
    print "</TABLE>\n";
}

#
# Role : Read the html documentation and incorporate the benchmark results
#
sub readDocumentation {
    local($doPrint) = 1;

    while (<STDIN>) {
	chop;
	if (/\<BENCH_RESULTS\>/) {
	    &readBenchs($resultFile);
	} else {
	    print "$_\n";
	}
    }
}

$resultFile = "benchs.log";
$fileName = "benchs.html";
while (@ARGV) {
    $_ = shift(@ARGV);
    if (/^-b$/) {
	$resultFile = shift;
    } else {
	die "Usage: incorporate-bench.pl  [-b file]";
    }
}
&readDocumentation;

