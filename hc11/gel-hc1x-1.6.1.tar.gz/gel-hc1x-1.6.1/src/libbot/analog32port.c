/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)    

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* analog32port.c uses the 6.270 expansion board for analog input. It 
 * configures three lines of PORTD as address selectors to 4051 analog
 * multiplexors.  This allows each of four analog ports to be presented
 * one of eight available analog inputs.  There are only three 4051's on
 * the expander board, so only 24 of the 32 of the supported elements in
 * the global analog array are implemented in hardware.  In addition, four
 * of the 24 available values are hardwired to dip switches, and a further
 * one to a potentiometer (hereafter referred to by the more technically
 * accurate term frob knob).
 */

#include <sys/interrupts.h>
#include <sys/ports.h>
#include <bot.h>

/* global analog sample array */
volatile unsigned char analog[32];

/* use TOC5 to generate 80hz analog sampler */
void analog_update(void)  __attribute__((interrupt));
void
analog_update()
{
  /* analog multiplex selector */
  static unsigned char channel;

  /* The 68hc11 provdes four samples continuously in this mode. The 6270
   * card attaches each of the four A/D lines (PORTE 4-7) to a CMOS 4051
   * 8-to-1 analog multiplexor (at least conceptually; one of the four A/D
   * pins is not implemented, so the top eight array elements are always
   * the same).  The selection of which of the eight inputs is connected
   * to the A/D converter is controlled by three bits from PORTD.
   */

  /* each multiplexor is offset eight from the previous one */
  /* the half of the expdbd analog block next to the DIP switches */
  analog[channel] = _io_ports[M6811_ADR1];
  /* the other half of the analog block */
  analog[channel + 8] = _io_ports[M6811_ADR2];
  /* the first four map to DIP switches; the next to a frob knob */
  analog[channel + 16] = _io_ports[M6811_ADR3];
  /* this A/D input is not multiplexed, but does have a solder pad */
  analog[channel + 24] = _io_ports[M6811_ADR4];
  /* increment channel selector */
  channel = (channel + 1) & 0x07;
  /* set new analog mux address */
  _io_ports[M6811_PORTD] = (channel <<3) | (_io_ports[M6811_PORTD] & 0xC7);
  /* increment TOC5 to get 80hz interrupt rate on 8mhz 68hc11 */
  set_output_compare_5((unsigned short)25000 + get_timer_counter());
  /* reset OC5F */
  _io_ports[M6811_TFLG1] = 0x08;
}

/* analog subsystem initialization */
void
init_analog()
{
  /* enable analog charge pump */
  _io_ports[M6811_OPTION] |= 0x80;
  /* initiate continuous conversions on PE4-7 */
  _io_ports[M6811_ADCTL] |= 0x34;
  /* setup port D output ports */
  _io_ports[M6811_SPCR] = 0x0;
  _io_ports[M6811_DDRD] |= 0x38;
  /* setup TOC5 interrupt handler */
  set_interrupt_handler(TIMER_OUTPUT5_VECTOR, analog_update);
  /* output pin not controlled by TOC5 */
  _io_ports[M6811_TCTL1] &= 0xFC;
  /* clear flag and enable interrupts for TOC5 */
  _io_ports[M6811_TFLG1] = 0x08;
  _io_ports[M6811_TMSK1] |= 0x08;
}
