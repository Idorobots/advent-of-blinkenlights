/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* bot.c is a program to control a robot using services provided by libbot.
 * The first section initializes the set of services desired, then an endless
 * loop is entered.  Each pass through the loop sets the State variable based
 * on the contents of the Detect variable, then invokes a behavior based
 * on that information.
 */

#include <sys/locks.h>
#include <sys/ports.h>
#include <bot.h>

void status_report(void);
void bumper(void);
void frob_speed(void);
void spinner(int);
void photo(char);
void ir_detect(void);
int randmask(int);

/* global indicating the current state of the bot */
volatile int State;
/* event counters for Detect and non-Detect */
int Dcount, Ncount;
/* buffer for constructing output string */
static char buf[80];

int
main()
{
  static char signon[] = "\nhi guys:\n";

  /* disable interrupts to initialize system */
  lock();
  /* run 68hc11 in expanded bus mode */
  set_bus_expanded();
  /* initialize buffered serial I/O */
  init_buffered_io();
  /* initialize system clock */
  init_sysclock();
  /* initialize analog conversions */
  init_analog();
  /* initialize encoder services */
  init_encoders();
  /* initialize MIT 6.270 ir detect subsystem */
  init_ir();
  /* initialize sensor sampling */
  init_poll_sensors();
  /* initialize pwm service */
  init_pwm();
  /* enable interrupts */
  unlock();

  /* print signon message to serial port */
  serial_print(signon);
  /* initial bot state */
  State = ACTIVE; start_speed_ctl();
  /* wait for analog to come online */
  while (Lspeed < 3) { Lspeed = run_speed; Rspeed = Lspeed; }
  /* enter bot state machine */
  while (1) {  /* no exit */
    /* set State based on Detect */
    if (Detect) {
      /* keep history of both detect and non-detect */
      if (Dcount > 0) Dcount += 1; else Dcount = 1;
      if (Ncount > 0) Ncount = 0;
      /* bumper event */
      if (Detect & 0xF000) { State |= BUMPER; }
      else { State &= ~BUMPER; }
      /* IR event */
      if (Detect & 0xC0) { State |= IR; }
      else { State &= ~IR; }
    } else {
      /* keep history of both detect and non-detect */
      if (Ncount > 0) Ncount += 1; else Ncount = 1;
      if (Dcount > 0) Dcount -= 1; else Dcount = 0;
      /* clear sensor subsumption modes */
      State &= (~BUMPER & ~IR);
    }
    /* invoke behavior for State */
    /* print status info to the serial port */
    if (State & STATUS) { status_report(); }
    /* bumper detect! wriggle free, then spin a bit */
    if (State & BUMPER) { bumper(); continue; }
    /* ir obstacle detectors */
    if (State & IR) { ir_detect(); continue; }
    /* photo vore/phobe behavior */
    if (DIP1) {
      State |= PHOTO;
      if (av_velo > ((run_speed /2) + (run_speed /8))) {
	photo(-1); continue;
      } 
    } else {
      State &= ~PHOTO;
    }
    /* default behavior is full speed ahead */
    if (State & ACTIVE) { 
      if (Lspeed < run_speed) { Lspeed += 1; }
      if (Rspeed < run_speed) { Rspeed += 1; }
    } else {
      if (Lspeed) { Lspeed >>1; }
      if (Rspeed) { Rspeed >>1; }
    }
  }
}

/* print status info to serial out */
void
status_report()
{
  /* add usful report variables here */
  sprintf(buf,"\n%x: S-%x D-%x", (unsigned short) sysclock, State, Detect);
  /* this function will drop chars if the output buffer is full */
  serial_print(buf);
}

/* return timer counter with top bits masked off */
inline int
randmask(int mask)
{
  return((int) get_timer_counter() & mask);
}

/* bumper behavior */
void
bumper()
{
  static int last, jutz, spin;

  /* turn speed controller off and disable pwm interrupt */
  stop_speed_ctl(); pwm_off();
  /* use encoder counter as failsafe */
  Lticks = Rticks = 512 + randmask(0xFF); jutz = -1;
  /* while bumper sensors are active */
  while (Detect & 0xC000) {
    last = Detect & 0xC000;
    /* if both front bumper switches are active */
    if ((Detect & 0XC000) == 0xC000) {
      /* backup */
      if (jutz) { digital_shadowbits |=
	       (LEFT_MTR | RIGHT_MTR | LEFT_REVERSE | RIGHT_REVERSE); }
      else { /* go forward */
	digital_shadowbits |= (LEFT_MTR | RIGHT_MTR);
	digital_shadowbits &= (~LEFT_REVERSE & ~RIGHT_REVERSE);
      }
    } else {
      /* front left bumper */
      if (last & 0x8000) {
	/* jutz between one or both motors reacting */
	if (jutz) { digital_shadowbits |= (LEFT_MTR | LEFT_REVERSE); }
	else { digital_shadowbits |=
		 (LEFT_MTR | RIGHT_MTR | LEFT_REVERSE | RIGHT_REVERSE); }
      } else { digital_shadowbits &= ~LEFT_MTR; }
      /* front right bumper */
      if (last & 0x4000) {
	if (jutz) { digital_shadowbits |= (RIGHT_MTR | RIGHT_REVERSE); }
	else { digital_shadowbits |=
		 (LEFT_MTR | RIGHT_MTR | LEFT_REVERSE | RIGHT_REVERSE); }
      } else { digital_shadowbits &= ~RIGHT_MTR; }
    }
    /* update hardware register */
    DIGITAL_PORT = digital_shadowbits;
    /* hungup failsafe */
    if ((Lticks == 0) | (Rticks == 0)) {
      jutz = ~jutz;
      if (jutz) { break; }
      else { Lticks = Rticks = 768 + randmask(0xFF); }
    }
  }
  /* continue breakfree action a bit */
  Lticks = Rticks = 512;
  while (Lticks & Rticks) { if (Bcount > 10) { break; } }
  /* turn speed controller on and enable pwm interrupts */
  Lspeed = Rspeed = run_speed;
  start_speed_ctl(); pwm_on();
  /* ensure both motors are turned on */
  digital_shadowbits |= (LEFT_MTR | RIGHT_MTR);
  DIGITAL_PORT = digital_shadowbits;
  /* spin away from last detect if possible */
  spin = randmask(0x3ff);
  if (last & 0x4000) { spin = -spin; }
  spinner(spin);
}

/* spin using speed controller */ 
void
spinner(int ticks)
{
  /* set direction of spin */
  if (ticks < 0) {
    if (Lspeed > 0) { Lspeed = -Lspeed; }
    if (Rspeed < 0) { Rspeed = -Rspeed; }
    ticks = -ticks;
  } else {
    if (Lspeed < 0) { Lspeed = -Lspeed; }
    if (Rspeed > 0) { Rspeed = -Rspeed; }
  }
  /* load encoder counter */
  Lticks = ticks;
  /* wait for ticks encoder counts */
  while (Lticks > 0) {
    if (Bcount > 10) { break; }
  }
}

/* respond to photo sensors */
void
photo(char flag)
{
  static int pdiff, lphoto, rphoto;

  /* equalize sensors a bit -- TWEAK! */
  lphoto = PHOTOL;
  rphoto = PHOTOR + (PHOTOR >>1);
  /* calculate the absolute difference between sensors */
  if ((pdiff = lphoto - rphoto) < 0) { pdiff = -pdiff; }
  /* if difference is great enough, respond to light based on flag */
  if (pdiff > ((lphoto + rphoto) /8)) {
    /* slow down one wheel based on difference between sensors */
    if (lphoto > rphoto) {
      /* photovore */
      if (flag) { if (Rspeed > 1) { Rspeed -= 1; } }
      /* photophobe */
      else { if (Lspeed > 1) { Lspeed -= 1; } }
    } else {
      /* photovore */
      if (flag) { if (Lspeed > 1) { Lspeed -= 1; } }
      /* photophobe */
      else { if (Rspeed > 1) { Rspeed -= 1; } }
    }
  /* if difference is not enough, try to increase speed */
  } else {
    if (Lspeed < run_speed) { Lspeed += 1; }
    if (Rspeed < run_speed) { Rspeed += 1; }
  }
}

/* veer away from active IR sensors */
void
ir_detect()
{
  static int idiff;

  /* if backing up */
  if ((Lspeed < 0) && (Rspeed < 0)) {
    idiff = Lspeed - Rspeed;
    if (idiff >= 0) { Lspeed += idiff; Rspeed -= idiff; }
    else { Rspeed += idiff; Lspeed -= idiff; }
  } else { /* going forward */
    /* if both sensors are active, flip a coin */
    if ((Detect & 0x0C) == 0x0C) {
      if (randmask(0x01)) { Rspeed -= 1; Lspeed += 1; }
      else { Lspeed -= 1; Rspeed -= 1; }
    } else {
      if (Detect & 0x08) { Rspeed -= 1; Lspeed += 1; }
      if (Detect & 0x04) { Lspeed -= 1; Rspeed += 1; }
    }
  }
}
