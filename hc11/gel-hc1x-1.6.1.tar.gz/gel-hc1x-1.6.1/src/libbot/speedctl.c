/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* speedctl.c is a PID speed controller which is invoked by poll_sensors.
 * The speed controller converts requested speed (L/Rspeed) to a mtr_tab
 * value.  These values represent pwm duty cycles in M68HC11 E-clocks.
 * See the file mtr_tab.txt for information abou building a mtr_tab.
 */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>
#include <bot.h>
#include "mtr_tab.h"

extern unsigned char SpeedCtl;

/* global variables */
volatile int Lspeed, Rspeed, av_velo, run_speed;

/* local variables */
static int Lerr, Rerr, Lderv, Rderv, Llast, Rlast, Loffset, Roffset;
static int Lindex, Rindex;

/* the Proportional and Derivitive constants (no Integral) */
#define P 4
#define D 2

/* compare the requested speed (L/Rspeed) with the actual speed as
 * measured by the encoders and respond to decrease the error.
 */
void
speed_ctl(void)
{
  /* update average velocity */
  av_velo = (le_sample + re_sample) /2;
  /* frob in run speed setting */
  if ((run_speed = (FROB2 /8)) < 2) { run_speed = 2; }
  /* save last error calculation */
  Rlast = Rerr;  Llast = Lerr;
  /* clip speed */
  if (Lspeed < MINSPEED) { Lspeed = MINSPEED; }
  else { if (Lspeed > MAXSPEED) { Lspeed = MAXSPEED; } }
  if (Rspeed < MINSPEED) { Rspeed = MINSPEED; }
  else { if (Rspeed > MAXSPEED) { Rspeed = MAXSPEED; } }

  /* P/D speed controller */
  /* (posted speed - measured speed) * table scale * fixed point scale */
  Rerr = ((Rspeed - re_sample) >>1) <<7;
  Rderv = (Rerr - Rlast)/D; Roffset += (Rerr + Rderv)/P;
  Rindex = Roffset >>7;
  Lerr = ((Lspeed - le_sample) >>1) <<7;
  Lderv = (Lerr - Llast)/D; Loffset += (Lerr + Lderv)/P;
  Lindex = Loffset >>7;

  /* clip mtr_tab index */
  if (Lindex < -MAXINDEX) { Lindex = -MAXINDEX; }
  if (Lindex > MAXINDEX) { Lindex = MAXINDEX; }
  if (Rindex < -MAXINDEX) { Rindex = -MAXINDEX; }
  if (Rindex > MAXINDEX) { Rindex = MAXINDEX; }

  /* set direction bit on motor driver if necessary */
  if (Rindex >= 0) { digital_shadowbits &= ~RIGHT_REVERSE; }
  else { digital_shadowbits |= RIGHT_REVERSE; }
  if (Lindex >= 0) { digital_shadowbits &= ~LEFT_REVERSE; }
  else { digital_shadowbits |= LEFT_REVERSE; }
  /* refresh motor control port */
  DIGITAL_PORT = digital_shadowbits;

  /* index into mtr_tab to select a pwm duty cycle */
  Lmtr = mtr_tab[Lindex + ZOFFSET]; 
  Rmtr = mtr_tab[Rindex + ZOFFSET]; 
}

/* initialize static variables */
void
start_speed_ctl()
{
  Lerr = Rerr = Lderv = Rderv = Llast = Rlast = Loffset = Roffset = 0;
  Lindex = Rindex = 0;
  SpeedCtl = -1;
}

/* disable speed controller */
inline void
stop_speed_ctl()
{
  SpeedCtl = 0;
}
