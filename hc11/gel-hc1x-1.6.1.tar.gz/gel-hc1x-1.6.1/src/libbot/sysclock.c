/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*
 * sysclock.c maintains a 32 bit system clock driven by TOC4.  The
 * memory-mapped output ports are also refreshed from shadow variables.
 */

#include <sys/interrupts.h>
#include <sys/ports.h>
#include <bot.h>

#define DIGITAL_PORT *(unsigned char volatile *)0x7000
#define EXPANSION_PORT *(unsigned char volatile *)0x4000

/* system clock variable */
long sysclock;

/* 1khz interrupt services the system clock */
void system_service(void)  __attribute__((interrupt));
void
system_service()
{
  /* increment the system clock */
  sysclock += 1;
  /* refresh ouput control ports */
  DIGITAL_PORT = digital_shadowbits;
  EXPANSION_PORT = expbd_shadowbits;
  /* increment timer count to get 1khz interrupt rate -- for 8mhz 68hc11 */
  set_output_compare_4((unsigned short)2000 + get_timer_counter());
  /* reset OC4F */
  _io_ports[M6811_TFLG1] = 0x10;
}

/* system clock initialization */
void 
init_sysclock()
{
  /* zero system clock */
  sysclock = 0;
  /* Set TOC4 interrupt handler */
  set_interrupt_handler(TIMER_OUTPUT4_VECTOR, system_service);
  /* setup TOC4 to drive system clock */
  _io_ports[M6811_TFLG1] = 0x10;
  _io_ports[M6811_TMSK1] |= 0x10;
  /* output pin not controlled by TOC4 */
  _io_ports[M6811_TCTL1] &= 0xF3;
}
