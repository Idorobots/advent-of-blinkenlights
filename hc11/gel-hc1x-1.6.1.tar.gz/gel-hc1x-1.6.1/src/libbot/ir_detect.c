/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*
 * ir_detect.c is a simple xor mode IR detection routine.
 */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>

/* memory mapped digital input port on MIT 6.270 board */
#define DIGITAL_INPUT *(volatile unsigned char *)0x7000
#define IR_XMIT_PERIOD 10000

volatile int ir_detect_lt, ir_detect_rt;

/* The MIT 6.270 board has the TOC2 output pin tied to a
 * transistor used to gate the output of a 40khz counter
 * circuit.  The output of the transistor drives IR leds.
 */
static unsigned char ir_last_lt, ir_last_rt, ir_tmp;
void ir_service(void)  __attribute__((interrupt));
void
ir_service(void)
{
  /* save last value and process left detector */
  ir_tmp = ir_last_lt;
  /* mask for left ir detector */
  ir_last_lt = DIGITAL_INPUT & 0x80;
  /* xor with last value */
  if (ir_tmp ^ ir_last_lt )
    ir_detect_lt += 1; 
  else
    ir_detect_lt = 0;

  /* save last value and process right detector */
  ir_tmp = ir_last_rt;
  /* mask for right ir detector */
  ir_last_rt = DIGITAL_INPUT & 0x40;
  /* xor with last value */
  if (ir_tmp ^ ir_last_rt)
    ir_detect_rt += 1;
  else
    ir_detect_rt = 0;

  /* set period for next interrupt */
  _io_ports[M6811_TOC2] += IR_XMIT_PERIOD;
  /* clearn interrupt flag */
  _io_ports[M6811_TFLG1] = 0x40;
}

/* initialize IR services */
void
init_ir(void)
{
  /* initialize TOC2 interrupt vector */
  set_interrupt_handler(TIMER_OUTPUT2_VECTOR, ir_service);
  /* set TOC2 action to toggle output pin */
  _io_ports[M6811_TCTL1] &= 0x7F;
  _io_ports[M6811_TCTL1] |= 0x40;
  /* reset TOC2 output pin */
  _io_ports[M6811_PORTA] &= 0xBF;
  /* clear TOC2 interrupt flag */
  _io_ports[M6811_TFLG1] = 0x40;
  /* enable TOC2 interrupts */
  _io_ports[M6811_TMSK1] |= 0x40;
}
