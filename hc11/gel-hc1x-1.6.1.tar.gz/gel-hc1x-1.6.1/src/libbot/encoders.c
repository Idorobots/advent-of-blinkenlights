/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*
 * encoders.c reads motor shaft encoders using timer input compares and
 * increments/decrements a variable to accumulate events.  This variable
 * is periodically (TOV interrupt) read and zeroed.  In addition, if
 * the value of the associated tick counter is non-zero, it is decremented.
 * When the tick value reaches zero, aperiodic routines can be sure that
 * the preset number of ticks has occured.  The caster encoder is for
 * an instrumented tail wheel (on a three-wheeled differential-drive bot,
 * it is useful to know where the caster wheel is at any given time).
 */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>

/* memory mapped digital input port on MIT 6.270 board */
#define DIGITAL_PORT *(volatile unsigned char *)0x7000
/* motor controller direction flags */
#define LEFT_REVERSE 0x01
#define RIGHT_REVERSE 0x04
/* memory shadow for output control bits which cannot be read directly */
extern volatile unsigned char digital_shadowbits;
/* globally accessible event counters */
volatile int l_encoder, Lticks, r_encoder, Rticks;
volatile char c_encoder;

/* left encoder interrupt service routine -- TIC3 */
void left_encoder(void)  __attribute__((interrupt));
void
left_encoder(void)
{
  /* which direction is the motor set to turn? */
  if (digital_shadowbits & LEFT_REVERSE) { l_encoder -= 1;}
  else { l_encoder += 1; }
  /* decrement ticks count if non-zero */
  if (Lticks) { Lticks -= 1; }
  /* reset interrupt flag */
  _io_ports[M6811_TFLG1] = 0x01;
}

/* right encoder interrupt service routine --TIC2 */
void right_encoder(void)  __attribute__((interrupt));
void
right_encoder(void)
{
  /* which direction is the motor set to turn? */
  if (digital_shadowbits & RIGHT_REVERSE) { r_encoder -= 1; }
  else { r_encoder += 1; }
  if (Rticks) { Rticks -= 1; }
  /* reset interrupt flag */
  _io_ports[M6811_TFLG1] = 0x02;
}

/* caster wheel encoder interrupt service routine -- TIC1 */
void caster_encoder(void)  __attribute__((interrupt));
void
caster_encoder(void)
{
  /* read quadrature from channel B */
  if (DIGITAL_PORT & 0x08) { c_encoder -= 1; }
  else { c_encoder += 1; }
  /* reset interrupt flag */
  _io_ports[M6811_TFLG1] = 0x04;
}

/* initialize encoders */
void
init_encoders(void)
{
  /* initialize interrupt vectors for encoder services */
  set_interrupt_handler(TIMER_INPUT3_VECTOR, left_encoder);
  set_interrupt_handler(TIMER_INPUT2_VECTOR, right_encoder);
  set_interrupt_handler(TIMER_INPUT1_VECTOR, caster_encoder);
  /* wheel encoders interrupt on any edge; caster on falling edge */
  _io_ports[M6811_TCTL2] = 0x2F;
  /* clear TIC interrupt flags */
  _io_ports[M6811_TFLG1] = 0x07;
  /* enable interrupts from TICs */
  _io_ports[M6811_TMSK1] |= 0x07;
}
