/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* poll_sensors.c uses the timer overflow interrupt to poll sensors. As
 * sensors are checked, the value of the Detect global variable is modified
 * to reflect the activity.  If the SpeedCtl flag is nonzero, the speed
 * controller is run. Miscellaneous functions for controlling leds and
 * switches are included in this file.
 */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>
#include <bot.h>

unsigned char choose_button (void);
unsigned char escape_button (void);

/* check the choose button */
inline unsigned char
choose_button()
{
  return !(DIGITAL_PORT & 2);
}

/* check the escape button */
inline unsigned char
escape_button()
{
  return !(DIGITAL_PORT & 1);
}

/* expander board leds */
inline void
led0_on()
{
  expbd_shadowbits |= 0x01;
}
inline void
led0_off()
{
  expbd_shadowbits &= 0xFE;
}
inline void
led1_on()
{
  expbd_shadowbits |= 0x02;
}
inline void
led1_off()
{
  expbd_shadowbits &= 0xFD;
}

/* global sensor detection flag */
volatile int Detect;

/*
Detect word         AAAA AAAA BBBB BBBB
                    ||||           ||||
front left bumper---+|||           ||||
front right bumper---+||           ||||
rear left bumper------+|           ||||
rear right bumper------+           ||||
left ir detector-------------------+|||
right ir detector-------------------+||
left plir detector-------------------+|
right plir detector-------------------+
*/

/* sample senors ~31/sec and update Detect */
unsigned char SpeedCtl;
volatile unsigned short le_sample, re_sample;
volatile int Bcount;
void poll_sensors(void)  __attribute__((interrupt));
void
poll_sensors()
{
  unsigned static char ptmp;

  /* read digital input port */
  ptmp = DIGITAL_PORT;
  /* left front bumper on/off */
  if (!(ptmp & 0x20)) { Detect |= 0x8000; }
  else { Detect &= 0x7FFF; }
  /* right front bumper on/off */
  if (!(ptmp & 0x10)) { Detect |= 0x4000; }
  else { Detect &= 0xBFFF; }
  /* left rear bumper */
  /* right rear bumper */
  /* left ir threshhold on/off with led indicator */
  if (ir_detect_lt > 3) { Detect |= 0x08; led0_on(); }
  else { Detect &= 0xFFF7; led0_off(); }
  /*right ir threshhold on/off with led indicator */
  if (ir_detect_rt > 3) { Detect |= 0x04; led1_on(); }
  else { Detect &= 0xFFFB; led1_off(); }
  /* sample encoders and zero event counters */
  le_sample = l_encoder; l_encoder = 0;
  re_sample = r_encoder; r_encoder = 0;
  /* accumulate bumper activity */
  if (Detect & 0XF000) { Bcount += 1; }
  else { Bcount = 0; }
  /* call speed controller */
  if (SpeedCtl) { speed_ctl(); }
  /*reset TOV flag */
  _io_ports[M6811_TFLG2] = 0x80;
}

/* initialize sensor polling function using timer overflow interrupt */
void
init_poll_sensors()
{
  /* setup interrupt vector */
  set_interrupt_handler(TIMER_OVERFLOW_VECTOR, poll_sensors);
  /* set prescaler to interrupt every 32.77 ms */
  _io_ports[M6811_TMSK2] &= 0xFC;  
  /* clear flag and enable timer overflow interrupt */
  _io_ports[M6811_TFLG2] = 0x80;
  _io_ports[M6811_TMSK2] |= 0x80;
}
