/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*
 * pwm.c is a pulse width modulation motor controller.  It assumes the 
 * globals Lmtr and Rmtr contain the duty cycle in E clocks.  The RTI
 * interrupt is used to turn on both motors and schedule the OC3 interrupt
 * to turn them off in turn.
 */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/interrupts.h>
#include <bot.h>

#include "mtr_tab.h"

#define PULSE_MIN  0x40
/* memory-mapped motor control functions */
#define LEFT_MTR 0x10
#define RIGHT_MTR 0x40
#define BOTH_MTRS 0x50
/* memory-mapped I/O port */
#define DIGITAL_PORT *(unsigned char volatile *)0x7000

/* The MIT 6.270 board uses some of the lower half of it's 64k address space
 * for memory-mapped I/O devices.  A write to 0x7000 will change the inputs
 * on an L293D motor controller chip.  A read from the same adress will
 * return the value of eight digital inputs.  As a consequence, there is
 * no read access to the motor control chip.  The shadowbits technique
 * declares a variable where all writes to the output port are vectored.
 * The sysclock routine refreshes the contents of this variable to the
 * actual output port every millisecond.
 */
volatile unsigned char digital_shadowbits, expbd_shadowbits;

volatile int Lmtr, Rmtr;
static int other_timeout, motor_mask, rti_tmp;

/* RTI service routine */
/* The strategy here is to use one output compare to service both of the
 * motor pwm channels.  The RTI interrupt routine turns on both motors, 
 * sets TOC3 to interrupt using the shorter of the two duty cycles and
 * stores the longer in other_timeout.  When TOC3 interrupts, it will turn 
 * off the shorter channel and reset itsself to interrupt again for the
 * other channel using the time in other_timeout.
 */
void rti_service(void)  __attribute__((interrupt));
void
rti_service(void)
{
  /* difference between motors becomes timeout */
  rti_tmp = Lmtr - Rmtr;
  /* which duty cycle is shorter? */
  if (rti_tmp < 0) {    /* left motor turns off first */
    /* absolute value */
    rti_tmp = -rti_tmp;
    /* enforce minimum difference in duty cycles */
    if (rti_tmp < PULSE_MIN) { other_timeout = 0; }
    else { other_timeout = rti_tmp; }
    /* mark left motor for oc3 turn off */
    motor_mask = LEFT_MTR;
    /* recycle variable to save space */
    rti_tmp = Lmtr;
  } else {    /* right motor turns off first */
    /* enforce minimum difference in duty cycles */
    if (rti_tmp < PULSE_MIN) { other_timeout = 0; }
    else { other_timeout = rti_tmp; }
    /* mark right motor for oc3 turn off */
    motor_mask = RIGHT_MTR;
    rti_tmp = Rmtr;
  }
  /* ensure pulse is not shorter than service time */
  if (rti_tmp < PULSE_MIN) { rti_tmp = PULSE_MIN; }
  /* turn on motors */
  if (Lmtr) { digital_shadowbits |= LEFT_MTR; }
  else {      digital_shadowbits &= ~LEFT_MTR; }
  if (Rmtr) { digital_shadowbits |= RIGHT_MTR; }
  else {      digital_shadowbits &= ~RIGHT_MTR; }
  /* update motor control hardware register */
  DIGITAL_PORT = digital_shadowbits;
  /* write new oc3 timeout */
  set_output_compare_3((unsigned short)rti_tmp + get_timer_counter());
  /* clear and enable oc3 interrupts */
  _io_ports[M6811_TFLG1] = 0x20;
  _io_ports[M6811_TMSK1] |= 0x20;
  /* reset RTI interrupt flag */
  _io_ports[M6811_TFLG2] = 0x40;
}

/* OC3 service routine */
void oc3_service(void)  __attribute__((interrupt));
void
oc3_service(void)
{
  /* is the other motor already off? */
  if (other_timeout == 0) {
    /* disable oc3 interrupts */
    _io_ports[M6811_TMSK1] &= ~0x20;
    motor_mask = BOTH_MTRS;
  } else {
    /* set alternate channel timeout */
    set_output_compare_3((unsigned short) other_timeout + get_timer_counter());
    other_timeout = 0;
  }
  /* update digital shadow bits */
  digital_shadowbits &= ~motor_mask;
  /* reset OC3 interrupt flag */
  _io_ports[M6811_TFLG1] = 0x20;
}

/* initialize pwm service */
void
init_pwm(void)
{
  /* Assign RTI interrupt handler */
  set_interrupt_handler(RTI_VECTOR, rti_service);
  /* Assign OC3 interrupt handler */
  set_interrupt_handler(TIMER_OUTPUT3_VECTOR, oc3_service);
  /* initialize shadowbits */
  digital_shadowbits = expbd_shadowbits = 0;
  /* initialize RTI period to 4.1 ms */
  _io_ports[M6811_PACTL] &= ~0x03;
  /* clear flag and enable RTI interrupts */
  _io_ports[M6811_TFLG2] = 0x40;
  _io_ports[M6811_TMSK2] |= 0x40;
  /* TOC3 does not control output pin */
  _io_ports[M6811_TCTL1] &= 0xCF;
  /* start with motors off */
  Lmtr = Rmtr = 0;
}

/* turn on pwm motor control */
inline void
pwm_on()
{
  /* turn on RTI interrupts */
  _io_ports[M6811_TMSK2] |= 0x40;
}

/* turn off pwm motor control */
inline void
pwm_off()
{
  /* disable RTI and OC3 interrupts */
  _io_ports[M6811_TMSK2] &= ~0x60;
}
