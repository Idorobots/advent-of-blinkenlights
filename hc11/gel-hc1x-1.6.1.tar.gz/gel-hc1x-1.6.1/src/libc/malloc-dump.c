/* malloc-dump.c -- Dump Map of Malloc Slots
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include "malloc.h"
#include <util.h>
#include <stddef.h>

#include <sys/sio.h>

void
malloc_dump ()
{
  struct slot* p;
  struct slot* f = _malloc_first;

  for (p = _malloc_bottom; p != 0; p = p->next)
    {
      char buf[10];
      char* s;
      
      size_t size;

      if (p->next == 0)
        size = (size_t) ((char*) _malloc_top - (char*) p);
      else
        size = (size_t) ((char*) p->next - (char*) p);

      s = ultoa ((unsigned short) p, &buf[sizeof(buf) - 1], 16, 0);
      serial_print (s);
      serial_print ("\t");

      s = ultoa ((unsigned short) p->next, &buf[sizeof(buf) - 1], 16, 0);
      serial_print (s);
      serial_print ("\t");
      if (p == f)
        {
          s = ultoa ((unsigned short) p->next_free, &buf[sizeof (buf) - 1],
                     16, 0);
          serial_print (s);
          f = f->next_free;
        }
      else
        serial_print ("------");
      
      serial_print ("\t");

      s = ultoa ((unsigned long) (size - 2), &buf[sizeof (buf) - 1], 10, 0);
      serial_print (s);
      serial_print ("\n");
    }
}
