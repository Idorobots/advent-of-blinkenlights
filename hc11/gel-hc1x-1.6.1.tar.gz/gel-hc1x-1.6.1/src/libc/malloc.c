/* malloc.c -- Malloc 
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include "malloc.h"
#include <stddef.h>
#include <unistd.h>

struct slot* _malloc_first;
struct slot* _malloc_bottom;
void* _malloc_top;

void*
malloc (size_t size)
{
  struct slot* p;
  struct slot* prev = 0;

  /* Minimum size is 2 so that we can always store a 'slot' to
     keep track of memory.  */
  if (size < sizeof(struct slot) - sizeof(size_t))
    size = sizeof(struct slot)  - sizeof(size_t);

  size += sizeof(p->next);

  /* Look in free blocks for a slot large enough for the size.
     This is a first fit approach.  If the slot is too big, it is
     split.  */
  for (p = _malloc_first; p != 0; p = p->next)
    {
      /* If we use this slot, see where we would end given the
         required size.  */
      struct slot* q = (struct slot*) ((char*) p + size);

      /* If we are within the current slot, we can use it.  */
      if ((q < p->next && q >= p)
          /* Check for last slot  */
          || (p->next == 0 && q < _malloc_bottom))
        {
          /* If the slot is too large, split it and add the remaining
             part in the free list.  */
          if ((char*) p->next - (char*) q > sizeof(struct slot))
            {
              q->next = p->next;
              p->next = q;
              q->next_free = p->next_free;
              p->next_free = q;
            }

          /* And unlink the slot from the free list.  */
          if (prev)
            prev->next_free = p->next_free;
          else
            _malloc_first = p->next_free;
          return &p->next_free;
        }
      prev = p;
    }

  /* Get more memory from sbrk.  We only ask for the slot since sbrk is
     fast and filling the free list will not help.  At the end this will
     be the same.  */
  p = (struct slot*) sbrk (size);
  if (p == 0)
    return 0;

  if (_malloc_bottom == 0)
    _malloc_bottom = p;

  _malloc_top = (char*) (p) + size;
  p->next = 0;
  return &p->next_free;
}
