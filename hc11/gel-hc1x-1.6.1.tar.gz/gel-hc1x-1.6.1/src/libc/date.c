/* date.c
   Copyright 2000, 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <sys/param.h>
#include <sys/locks.h>
#include <sys/interrupts.h>
#include <sys/ports.h>
#include <sys/time.h>
#include <time.h>

#define SECSPERMIN	60L
#define MINSPERHOUR	60L
#define HOURSPERDAY	24L
#define SECSPERHOUR	(SECSPERMIN * MINSPERHOUR)
#define SECSPERDAY	(SECSPERHOUR * HOURSPERDAY)
#define DAYSPERWEEK	7
#define MONSPERYEAR	12

#define YEAR_BASE	1900
#define EPOCH_YEAR      1970
#define EPOCH_WDAY      4

#define isleap(y) ((((y) % 4) == 0 && ((y) % 100) != 0) || ((y) % 400) == 0)

static const unsigned char mon_lengths[2][MONSPERYEAR] = {
  {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
  {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
} ;

static const unsigned short year_lengths[2] = {
  365,
  366
} ;

/* Number of days to reach the given years (from start of EPOCH).  */
static const unsigned short year_days[] = {
  365,	/* 1970 */
  3287,	/* 1978 */
  6209,	/* 1986 */
  9131,	/* 1994 */
  12053,	/* 2002 */
  14975,	/* 2010 */
  17897,	/* 2018 */
  20819,	/* 2026 */
  23741,	/* 2034 */
  26663,	/* 2042 */
  29585,	/* 2050 */
  32507,	/* 2058 */
  35429,	/* 2066 */
  38351,	/* 2074 */
  41273,	/* 2082 */
  44195,	/* 2090 */
  47117,	/* 2098 */
  65535         /* Overflow */
};

time_t
time (time_t *tp)
{
  struct timeval tv;

  timer_gettime (&tv);
  if (*tp)
    *tp = tv.tv_sec;
  return tv.tv_sec;
}

struct tm *
localtime_r (const time_t *t, struct tm *tp)
{
  unsigned long secs = *t;
  unsigned short days;
  unsigned short y, yleap;
  const unsigned char *ip;
  unsigned short i;

  /* The max number of days is 49710; so it fits in a short.  */
  days = (unsigned short) (secs / (3600L * 24L));
  secs = secs % (3600L * 24L);
  tp->tm_hour = secs / 3600L;
  secs = secs % 3600L;
  tp->tm_min = (short) (secs) / (short) (60);
  tp->tm_sec = (short) (secs) % (short) (60);

  /* compute day of week */
  tp->tm_wday = ((EPOCH_WDAY + days) % DAYSPERWEEK);
  
  /* compute year & day of year */
  y = EPOCH_YEAR;

  for (i = 0; days > year_days[i]; i++)
    continue;
  if (i > 0)
    {
      i--;
      y += (i * 8) + 1;
      days -= year_days[i];
    }
  for (;;)
    {
      yleap = isleap(y);
      if (days < year_lengths[yleap])
        break;
      y++;
      days -= year_lengths[yleap];
    }

  tp->tm_year = y - YEAR_BASE;
  tp->tm_yday = days;

  ip = mon_lengths[yleap];
  for (tp->tm_mon = 0; days >= *ip; ++tp->tm_mon)
    days -= *ip++;
  tp->tm_mday = days + 1;

  /* set daylight saving time flag */
  tp->tm_isdst = -1;

  tp->tm_mon_length = mon_lengths[yleap][tp->tm_mon];
  tp->tm_year_length = year_lengths[yleap];
  return tp;
}
