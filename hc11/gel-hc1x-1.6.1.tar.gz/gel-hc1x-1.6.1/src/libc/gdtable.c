/* date.c
   Copyright 2000, 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <time.h>

#define SECSPERMIN	60L
#define MINSPERHOUR	60L
#define HOURSPERDAY	24L
#define SECSPERHOUR	(SECSPERMIN * MINSPERHOUR)
#define SECSPERDAY	(SECSPERHOUR * HOURSPERDAY)
#define DAYSPERWEEK	7
#define MONSPERYEAR	12

#define YEAR_BASE	1900
#define EPOCH_YEAR      1970
#define EPOCH_WDAY      4

#define isleap(y) ((((y) % 4) == 0 && ((y) % 100) != 0) || ((y) % 400) == 0)

static const unsigned char mon_lengths[2][MONSPERYEAR] = {
  {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
  {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
} ;

static const unsigned short year_lengths[2] = {
  365,
  366
} ;

int main (int argc, char *argv[])
{
  unsigned long days;
  unsigned short y, yleap;
  const unsigned char *ip;
  unsigned short n;
  
  days = 0;
  /* compute year & day of year */
  y = EPOCH_YEAR;
  for (;;)
    {
      unsigned long dt;
      
      yleap = isleap(y);
      dt = year_lengths[yleap] * 24L * 3600L;
      if (days + dt < days)
        break;

      days += dt;
      if (((y - EPOCH_YEAR) & 0x07) == 0)
        {
          printf (" { %lu },\t/* %d */\n", days / (24L * 3600L), y);
        }
      y++;
    }

  return 0;
}
