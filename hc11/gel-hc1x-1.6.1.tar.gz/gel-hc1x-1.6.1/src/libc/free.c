/* free.c -- Free some memory
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdlib.h>
#include "malloc.h"

void
free (void* ptr)
{
  struct slot* free_slot;
  struct slot* p;
  struct slot* prev;

  if (ptr == 0)
    return;

  free_slot = (struct slot*) ((char*) ptr - offsetof (struct slot, next_free));
  prev = 0;
  for (p = _malloc_first; p != 0; p = p->next_free)
    {
      if (free_slot < p)
        break;

      prev = p;
    }
  free_slot->next_free = p;
  if (prev)
    prev->next_free = free_slot;
  else
    _malloc_first = free_slot;

  if (free_slot->next == p && p)
    {
      free_slot->next = p->next;
      free_slot->next_free = p->next_free;
    }
  if (prev->next == free_slot && prev)
    {
      prev->next = free_slot->next;
      prev->next_free = free_slot->next_free;
    }
}
