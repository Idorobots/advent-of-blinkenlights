/* realloc.c -- Realloc/allocate memory
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include "malloc.h"
#include <stdlib.h>
#include <stddef.h>

void*
realloc (void* p, size_t size)
{
  struct slot* s;
  size_t old_size;
  void* q;

  if (p == 0)
    return malloc (size);

  if (size == 0)
    {
      free (p);
      return 0;
    }

  s = (struct slot*) ((char*) p - offsetof (struct slot, next_free));
  if (s->next == 0)
    old_size = (size_t) ((char*) _malloc_top - (char*) p);
  else
    old_size = (size_t) ((char*) s->next - (char*) p);

  q = malloc (size);
  memcpy (q, p, old_size);
  free (p);
  return q;
}

