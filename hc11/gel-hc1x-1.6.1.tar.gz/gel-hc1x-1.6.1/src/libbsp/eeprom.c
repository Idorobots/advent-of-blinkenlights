/* eeprom.c -- EEprom Programming Interface
   Copyright 2000, 2001, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <sys/ports.h>
#include <time.h>
#include <eeprom.h>

#ifdef mc6811
/*! Write a byte in eeprom.

    Write the byte \b value in the eeprom at address \b p.
    The eeprom byte location is erased first if write operation
    is not possible (when at least one bit must be set to 1).

    @param p      Address of the eeprom byte to write
    @param value  Value to write
    @see eeprom_write_short  */
void 
eeprom_write_byte (unsigned char *p, const unsigned char value)
{
  unsigned char diff;

  diff = *p ^ value;
  if (diff)
    {
      if (diff & value)
	{
	  /* Clear eeprom byte.  */
	  diff = *p ^ value;
	  if (diff == 0)
	    return;
	  
	  _io_ports[M6811_PPROG] = M6811_EELAT | M6811_ERASE | M6811_BYTE;
	  *p = value;
	  _io_ports[M6811_PPROG] = M6811_EELAT | M6811_ERASE
	    | M6811_BYTE | M6811_EEPGM;

	  /* Wait 10 ms.  */
	  udelay (10 * 1000);
	  _io_ports[M6811_PPROG] = M6811_EELAT | M6811_ERASE | M6811_BYTE;
	}
      
      /* Write eeprom byte.  */
      _io_ports[M6811_PPROG] = M6811_EELAT;
      *p = value;
      _io_ports[M6811_PPROG] = M6811_EELAT | M6811_EEPGM;

      /* Wait 10 ms.  */
      udelay (10 * 1000);
      _io_ports[M6811_PPROG] = M6811_EELAT;
      _io_ports[M6811_PPROG] = 0;
    }
}

/*! Write a short in eeprom.

    Write the short \b value in the eeprom at address \b p.
    The eeprom byte locations are erased first if write operation
    is not possible (when at least one bit must be set to 1).

    @param p      Address of the eeprom byte to write
    @param value  Value to write
    @see eeprom_write_byte  */
void
eeprom_write_short (unsigned short *p, const unsigned short value)
{
  unsigned char *s = (unsigned char*) p;

  eeprom_write_byte (s, value >> 8);
  s++;
  eeprom_write_byte (s, value);
}
#endif
