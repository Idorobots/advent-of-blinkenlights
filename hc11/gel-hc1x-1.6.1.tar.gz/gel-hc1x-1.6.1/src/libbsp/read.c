/* pseudo system calls for M68HC11 & M68HC12.
 * Copyright (C) 1999, 2000, 2001, 2002, 2003 Stephane Carrez (stcarrez@nerim.fr)	
 *
 * The authors hereby grant permission to use, copy, modify, distribute,
 * and license this software and its documentation for any purpose, provided
 * that existing copyright notices are retained in all copies and that this
 * notice is included verbatim in any distributions. No written agreement,
 * license, or royalty fee is required for any of the authorized uses.
 * Modifications to this software may be copyrighted by their authors
 * and need not follow the licensing terms described here, provided that
 * the new terms are clearly indicated on the first page of each file where
 * they apply.
 */

#include <sys/types.h>
#include <sys/sio.h>
#include <unistd.h>

ssize_t
read(int file, void *p, size_t nbytes)
{
  int i = 0;
  char* buf = (char*) p;
  
  for (i = 0; i < nbytes; i++) {
    *(buf + i) = serial_recv();
    if ((*(buf + i) == '\n') || (*(buf + i) == '\r')) {
      i++;
      break;
    }
  }
  return (i);
}
