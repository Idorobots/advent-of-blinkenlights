/* spi-poll.c -- SPI Controller (polling implementation)
   Copyright 2000, 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <sys/param.h>
#include <sys/ports.h>
#include <sys/spi.h>


#define M6811_DDRD4 (1 << 4)
#define M6811_DDRD3 (1 << 3)

/* Boolean value which indicates whether the SPI is active or not.  */
static unsigned char spi_running;

/** Flush the SPI queue.

    Wait for the SPI queue to be flushed completely.  */
void
spi_flush (void)
{
  while ((_io_ports[M6811_SPSR] & M6811_SPIF) == 0
	 && spi_running)
    continue;

  spi_running = 0;
}

/** Send the character on the SPI device.  */
void
spi_putc (unsigned char c)
{
  spi_flush ();
  _io_ports[M6811_SPDR] = c;
  spi_running = 1;
}

/**
 * Initialize the spi package.
 *
 */
void
spi_initialize (unsigned char mode)
{
  mode |= M6811_SPE;
  _io_ports[M6811_SPCR] = mode;

  /* Enable SCK and MOSI outputs.  */
  _io_ports[M6811_DDRD] |= M6811_DDRD4 | M6811_DDRD3;

  spi_running = 0;
}

