/* util.h -- General Purpose Utility functions
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_UTIL_H
#define _GEL_UTIL_H

#include <sys/param.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup util General Purpose Utility Functions

 */
/*@{*/

#define ULTOA_OCT_ZERO 0x01
#define ULTOA_GROUP    0x02
#define ULTOA_UPPER    0x04

/*! Convert an unsigned long to a string.
    Convert an unsigned long to ASCII for printf purposes, returning
    a pointer to the first character of the string representation.
    Octal numbers can be forced to have a leading zero; hex numbers
    can be printed in upper or lower case.  The \b mode controls
    various mode for the conversion:


    <dl>
    <dt>ULTOA_OCT_ZERO
    <dd>When set, a leading 0 is added for non-zero values
        for the octal conversions.

    <dt>ULTOA_UPPER
    <dd>When set, upper characters are used (hexadecimal conversions)

    <dt>ULTOA_GROUP
    <dd>The decimal conversion is made using groups of digits.
        The function takes two additional parameters:

        char thousep   An additional character specifies the group separator.
        const char* grp  Specifies the groups in terms of digits.
        
        A
    </dl>

    \param val   Value to translate into a string
    \param endp  Pointer to end of buffer
    \param base  Base number for conversion (8, 10 or 16)
    \param mode  Control modes
    \param thousep  Optional character for thousand separator
    \param grp   Group string control
    \return the beginning of the string representation  */
extern char*
ultoa (unsigned long val, char *endp, int base, int mode, ...);
  /*       char thousep, const char *grp); */
  
/*! Check malloc list
    This operation is intended to help debug memory allocation problems
    with \b malloc and \b free.  It verifies the consistency of internal
    data structures used by \b malloc and ensures that nothing is corrupted.

    \return 0 if there is no memory allocation problem  */
extern int malloc_check (void);

/*! Dump memory allocation list
    Dump the memory allocation lists to the standard output.  The free list
    as well as allocated malloc blocks are printed.

*/
extern void malloc_dump (void);
  
/*@}*/

#ifdef __cplusplus
};
#endif
#endif
