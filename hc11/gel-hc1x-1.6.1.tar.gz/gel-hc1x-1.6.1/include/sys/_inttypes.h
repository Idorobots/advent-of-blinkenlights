#ifndef MACHINE_INTTYPES_H
#define MACHINE_INTTYPES_H

#include <stddef.h>

#ifndef _SIZE_T_DECLARED
typedef	size_t __size_t;
#define	_SIZE_T_DECLARED
#endif

#endif
