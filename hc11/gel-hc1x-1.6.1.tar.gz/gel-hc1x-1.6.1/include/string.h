/* string.h stdc header
   Copyright (C) 2000, 2003, 2004 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _STRING_H
#define _STRING_H

#include <stddef.h>

#define ATTR_MEMSET __attribute__((near))
#define ATTR_MEMCPY __attribute__((near))
#define ATTR_MEMCHR __attribute__((near))
#define ATTR_MEMCMP __attribute__((near))

#define ATTR_STRCPY __attribute__((near))
#define ATTR_STRNCPY __attribute__((near))
#define ATTR_STRCAT __attribute__((near))
#define ATTR_STRNCAT __attribute__((near))
#define ATTR_STRCMP __attribute__((near))
#define ATTR_STRNCMP __attribute__((near))
#define ATTR_STRCASECMP __attribute__((near))
#define ATTR_STRNCASECMP __attribute__((near))
#define ATTR_STRLEN __attribute__((near))
#define ATTR_STRTOK __attribute__((near))

#ifdef __cplusplus
extern "C" {
#endif

extern ATTR_MEMSET void* memset (void * p, int val, size_t len);
extern ATTR_MEMCHR void* memchr (const void * p, int val, size_t len);
extern ATTR_MEMCMP int memcmp (const void * p, const void* s, size_t len);
extern ATTR_MEMCPY void* memcpy (void* to, const void* from, size_t len);
extern ATTR_MEMCPY void* memmove (void* to, const void* from, size_t len);

extern ATTR_STRCPY char* strcpy (char* to, const char* from);
extern ATTR_STRNCPY char* strncpy (char* to, const char* from, size_t len);
extern ATTR_STRCAT char* strcat (char* to, const char* from);
extern ATTR_STRNCAT char* strncat (char* to, const char* from, size_t len);
extern ATTR_STRCMP int strcmp (const char* p, const char* q);
extern ATTR_STRNCMP int strncmp (const char* p, const char* q, size_t len);
extern ATTR_STRCASECMP int strcasecmp (const char* p, const char* q);
extern ATTR_STRNCASECMP int strncasecmp (const char* p, const char* q, size_t len);

extern ATTR_STRLEN size_t strlen (const char* p);

extern ATTR_STRTOK char *strtok (char *__restrict __s, __const char *__restrict __delim);

#ifdef __cplusplus
}
#endif

#endif
