/* m68hc12/ports_def.h -- Definition of 68HC12 ports
   Copyright 1999, 2000 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

   - Jul 2003 Modified by Jefferson Smith, Robotronics Corp.
     Ported to work with m68hc12, and some backwards compatible
     definitions.

This file is part of GDB, GAS, and the GNU binutils.

GDB, GAS, and the GNU binutils are free software; you can redistribute
them and/or modify them under the terms of the GNU General Public
License as published by the Free Software Foundation; either version
1, or (at your option) any later version.

GDB, GAS, and the GNU binutils are distributed in the hope that they
will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file; see the file COPYING.  If not, write to the Free
Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#ifndef _M68HC12_PORTS_DEF_H
#define _M68HC12_PORTS_DEF_H

typedef unsigned char byte;

/* Flags for the definition of the 68HC11 & 68HC12 CCR.  */
#define M6811_S_BIT     0x80	/* Stop disable */
#define M6811_X_BIT     0x40	/* X-interrupt mask */
#define M6811_H_BIT     0x20	/* Half carry flag */
#define M6811_I_BIT     0x10	/* I-interrupt mask */
#define M6811_N_BIT     0x08	/* Negative */
#define M6811_Z_BIT     0x04	/* Zero */
#define M6811_V_BIT     0x02	/* Overflow */
#define M6811_C_BIT     0x01	/* Carry */
/* equivalents without the M68HC11 indication, because it is the
   same for M68HC12. */
#define CC_S     (byte)(1<<7)          //Stop disable
#define CC_X     (1<<6)          //X-interrupt mask
#define CC_H     (1<<5)          //Half carry flag
#define CC_I     (1<<4)          //I-interrupt mask
#define CC_N     (1<<3)          //Negative
#define CC_Z     (1<<2)          //Zero
#define CC_V     (1<<1)          //Overflow
#define CC_C     1             //Carry

/* 68HC11 register names which are forward compatible enough to simply 
   change the address offsets.

*/
#define M6811_PORTA	0x00	/* Port A register */
#define M6811_PORTB	0x01	/* Port B register */

#define M6811_TCTN	0x84	/* Timer Counter Register */


/* 68HC12 register names
   addresses to registers for hc12 to be added to _io_ports base 
   address. 
*/
#define M6812_PORTA     0x00       //Port A register
#define M6812_PORTB     0x01       //Port B register
#define M6812_DDRA      0x02       //Data Direction Port A
#define M6812_DDRB      0x03       //Data Direction Port A
#define M6812__RES4     0x04
#define M6812__RES5     0x05
#define M6812__RES6     0x06
#define M6812__RES7     0x07
#define M6812_PORTE     0x08    //Port E register
#define M6812_DDRE      0x09    //DAta Direction Port E

#define M6812_PEAR      0x0A
/* Flags in PEAR */
#define M6812_NDBE      (byte)(1<<7)
#define M6812_CGMTE     (1<<6)
#define M6812_PIPOE     (1<<5)
#define M6812_NECLK     (1<<4)
#define M6812_LSTRE     (1<<3)
#define M6812_RDWE      (1<<2)

#define M6812_MODE      0x0B    //Mode control
/* Flags in MODE register */
#define M6812_SMODN     (byte)(1<<7)
#define M6812_MODB      (1<<6)
#define M6812_MODA      (1<<5)
#define M6812_ESTR      (1<<4)
#define M6812_IVIS      (1<<3)
#define M6812_EBSWAI    (1<<2)
#define M6812_EME       (1<<0)
#define M6812_EXPA_NARROW (M6812_MODA|M6812_ESTR)             //0x30
#define M6812_EXPA_WIDE   (M6812_MODB|M6812_MODA|M6812_ESTR)  //0x70

#define M6812_PUCR      0x0C    //Pullup Resistor Control reg
/* Flags in PUCR register */
#define M6812_PUPE      (1<<4)   //port E inputs (PE1 always, PE6-4 never)
#define M6812_PUPB      (1<<1)   //except in external bus mode
#define M6812_PUPA      (1<<0)

#define M6812_RDRIV     0x0D    //Reduced Driver Register
#define M6812__RESE     0x0E
#define M6812__RESF     0x0F

#define M6812_INITRM	0x10	//Ram mapping
/* Field in INITRM */
#define M6812_POS_RMMAP 3
#define M6812_MSK_RMMAP (0x1F<<M6812_POS_RMMAP)

#define M6812_INITRG	0x11	//Register mapping

#define M6812_INITEE	0x12	//Eeprom mapping
/* Flags/Fields in INITEE */
#define M6812_POS_EEMAP 4
#define M6812_MSK_EEMAP (0xF<<M6812_POS_EEMAP)
#define M6812_EEON      (1<<0)

#define M6812_MISC	0x13
/* Flags/Fields in MISC */
#define M6812_NDRF      (1<<6)                     //narrow buss in reg-follow
#define M6812_POS_RFSTR  4                         //reg-follow space stretch
#define M6812_MSK_RFSTR (0x3<<M6812_POS_RFSTR)
#define M6812_POS_EXSTR  2                         //external space strech
#define M6812_MSK_EXSTR (0x3<<M6812_POS_EXSTR)
#define M6812_MAPROM    (1<<1)                     //map rom location
#define M6812_ROMON     (1<<0)                     //rom enable

#define M6812_RTICTL	0x14
/* Flags in RTICTL */
#define M6812_RTIE   (byte)(1<<7)
#define M6812_RSWAI     (1<<6)
#define M6812_RSBCK     (1<<5)
#define M6812_RTBYP     (1<<3)
#define M6812_MSK_RTR    (0x7)

#define M6812_RTIFLG	0x15
/* Flag in RTIFLG */
#define M6812_RTIF      0x80

#define M6812_COPCTL	0x16    //COP control register
/* Flags in COPCTL */
#define M6812_CME     (byte)(1<<7)  //Clock Monitor Enable
#define M6812_FCME      (1<<6)  //Force Clock Monitor Enable (overrides CME)
#define M6812_FCM       (1<<5)  //special Force Clock Monitor Reset
#define M6812_FCOP      (1<<4)  //special Force COP Reset
#define M6812_DISR      (1<<3)  //special timeout disable
#define M6812_MSK_CR    (0x7)   //mask for COP Reset

#define M6812_COPRST	0x17	//COP reset register
#define M6812_ITST0	0x18
#define M6812_ITST1	0x19
#define M6812_ITST2	0x1A
#define M6812_ITST3	0x1B
#define M6812__RES1C    0x1C
#define M6812__RES1D    0x1D
#define M6812_INTCR	0x1E
#define M6812_HPRIO	0x1F
#define M6812_BRKCT0	0x20
#define M6812_BRKCT1	0x21
#define M6812_BRKAH	0x22
#define M6812_BRKAL	0x23
#define M6812_BRKDH	0x24
#define M6812_BRKDL	0x25
/*           0x26 - 0x3F  Reserved (from HC11?)
*/
#define M6812_PWCLK	0x40
/* Flags in PWCLK */
#define M6812_CON23     (byte)(1<<7)             //concat PWM 2 and 3
#define M6812_CON01     (1<<6)             //concat     0 and 1
 //5-3  clk A prescale n as in: Eclk / 2^n
 //2-0  clk B prescale n

#define M6812_PWPOL	0x41
/* Flags in PWPOL */
#define M6812_PCLK3     (byte)(1<<7)             //1= Clock S1 instead of B
#define M6812_PCLK2     (1<<6)             //1= Clock S1 instead of B
#define M6812_PCLK1     (1<<5)             //1= Clock S0 instead of A
#define M6812_PCLK0     (1<<4)             //1= Clock S0 instead of A
#define M6812_PPOL3     (1<<3)             //1=duty high
#define M6812_PPOL2     (1<<2)
#define M6812_PPOL1     (1<<1)
#define M6812_PPOL0     (1<<0)

#define M6812_PWEN	0x42             //enable PWM outputs
/* Flags in PWEN */
#define M6812_PWEN3     (1<<3)
#define M6812_PWEN2     (1<<2)
#define M6812_PWEN1     (1<<1)
#define M6812_PWEN0     (1<<0)

#define M6812_PWPRES         0x43
#define M6812_PWSCAL0        0x44             // clk S0 prescale n: clkA/(n+1)/2
#define M6812_PWSCNT0        0x45
#define M6812_PWSCAL1        0x46             // clk S1 prescale n: clkB/(n+1)/2
#define M6812_PWSCNT1        0x47
#define M6812_PWCNT0         0x48             //counter for a running PWM
#define M6812_PWCNT1         0x49
#define M6812_PWCNT2         0x4A
#define M6812_PWCNT3         0x4B
#define M6812_PWPER0         0x4C             //period (controls freq)
#define M6812_PWPER1         0x4D
#define M6812_PWPER2         0x4E
#define M6812_PWPER3         0x4F
#define M6812_PWDTY0         0x50             //duty (controls pulse width)
#define M6812_PWDTY1         0x51
#define M6812_PWDTY2         0x52
#define M6812_PWDTY3         0x53

#define M6812_PWCTL          0x54
/* Flags in PWCTL */
#define M6812_PSWAI          (1<<4)           //Halt in wait mode
#define M6812_CENTR          (1<<3)           //Center-aligned output mode
#define M6812_RDPP           (1<<2)           //Reduced drive all outputs
#define M6812_PUPP           (1<<1)           //pullups on all inputs
#define M6812_PSBCK          (1<<0)           //stop in Bgnd debug mode

#define M6812_PWTST          0x55
#define M6812_PORTP          0x56
#define M6812_DDRP           0x57

#define M6812_ATDCTL0        0x60             //Abort AD sequence when write
#define M6812_ATDCTL1        0x61             //special mode use

#define M6812_ATDCTL2        0x62
/* Flags in ATDCTL2 reg (enable AD, etc) */
#define M6812_ADPU     (byte)(1<<7)         // Power up (enable)
#define M6812_AFFC     (1<<6)         // fast reset (just read data)
#define M6812_AWAI     (1<<5)         // Stop in Wait
#define M6812_ASCIE    (1<<1)         // AD sequence complete interrup enable
#define M6812_ASCIF     1            // AD sequence complete interrup flag

#define M6812_ATDCTL3	0x63
/* Modes in ATDCTL3 reg (BDM freeze modes) */
#define M6812_FRZ_NONE   0x00      // run normal while stopped in BDM
#define M6812_FRZ_FINISH 0x02      // finish current conv then freeze
#define M6812_FRZ_IMM    0x03      // freeze while in BDM

#define M6812_ATDCTL4	0x64
/* Flags/modes in ATDCTL4 reg (8/10 bits, conversion speed) */
#define M6812_S10BM       (byte)(1<<7)     //10 bit AD
#define M6812_POS_SMP    5
#define M6812_MSK_SMP    (byte)(0x3<<M6812_POS_SMP)
 // SMP values by final sample cycles. SMP16 is most stable conversion time(?)
#define M6812_SMP2             0
#define M6812_SMP4       (byte)(0x1<<M6812_POS_SMP)
#define M6812_SMP8       (byte)(0x2<<M6812_POS_SMP)
#define M6812_SMP16      (byte)(0x3<<M6812_POS_SMP)
                                   // prescale 00001 (div 4) is default

#define M6812_ATDCTL5	0x65
/* Flags/modes in ATDCTL5 reg (write starts conv. select modes, channels) */
#define M6812_S8CM       (byte)(1<<6)      //read sequence of 4 or 8
#define M6812_SCAN       (byte)(1<<5)      // whether to scan repeatedly
#define M6812_MULT       (byte)(1<<4)      //read 1, or sequence of 4/8

#define M6812_ATDSTAT  0x66
#define M6812_ATDSTAT0 0x66
/* Flags/fields in ATDSTAT0 */
#define M6812_SCF        (byte)(1<<7)      //Sequence Complete Flag
#define M6812_MSK_CC     0x7               //Conversion Counter

#define M6812_ATDSTAT1 0x67                //CCF7-0
#define M6812_ATDTESTH 0x68
#define M6812_ATDTESTL 0x69

#define M6812_PORTAD0  0x6F
#define M6812_ADR00    0x70
#define M6812_ADR00L   0x71
#define M6812_ADR01    0x72
#define M6812_ADR01L   0x73
#define M6812_ADR02    0x74
#define M6812_ADR02L   0x75
#define M6812_ADR03    0x76
#define M6812_ADR03L   0x77
#define M6812_ADR04    0x78
#define M6812_ADR04L   0x79
#define M6812_ADR05    0x7A
#define M6812_ADR05L   0x7B
#define M6812_ADR06    0x7C
#define M6812_ADR06L   0x7D
#define M6812_ADR07    0x7E
#define M6812_ADR07L   0x7F

#define M6812_TIOS	0x80			//Timer IC/OC select
#define M6812_CFORC	0x81			//Timer Compare Force
#define M6812_OC7M	0x82			//Output Compare 7 Mask
#define M6812_OC7D	0x83			//Output Compare 7 Data
#define M6812_TCNT	0x84			//Hardware Timer Count

#define M6812_TSCR	0x86			//Timer system control
/* Flags in TSCR register */
#define M6812_TEN     (byte)(1<<7)         //Timer Enable
#define M6812_TSWAI   (byte)(1<<6)         //Timer Stops While in Wait
#define M6812_TSBCK   (byte)(1<<5)         //Timer Stops in Background Mode
#define M6812_TFFCA   (byte)(1<<4)         //Timer Fast Flag Clear All

#define M6812_TQCR	0x87            //**Reserved**

#define M6812_TCTL1	0x88			//Timer Control 1
#define M6812_TCTL2	0x89			//Timer Control 2
/* Modes for bit pairs in TCTL1-2 */
#define M6812_TOC_NONE    0x0     //No output for this timer
#define M6812_TOC_TOGGLE  0x1     //Toggle output pin on compare
#define M6812_TOC_CLEAR   0x2     //Clear output pin on compare
#define M6812_TOC_SET     0x3     //Set output pin on compare

#define M6812_TCTL3	0x8A
#define M6812_TCTL4	0x8B
/* Modes for bit pairs in TCTL3-4 */
#define M6812_TIC_NONE    0x0     //No edge detected
#define M6812_TIC_RISE    0x1     //detect rising edge
#define M6812_TIC_FALL    0x2     //detect falling edge
#define M6812_TIC_BOTH    0x3     //detect both edges

#define M6812_TMSK1	0x8C      //enable interrupt for each timer 0-7

#define M6812_TMSK2	0x8D
/* Flags in TMSK2 (over flow I, pullups, reduce drv, oc7 timer reset) */
#define M6812_TOI         (byte)(1<<7)     //ena timer overflow interrupt
#define M6812_PUPT        (byte)(1<<5)     //ena pullup resistors on inputs
#define M6812_RDPT        (byte)(1<<4)     //reduced drive outputs
#define M6812_TCRE        (byte)(1<<3)     //reset TCNT on oc7 compare
#define M6812_MSK_PR      0x07             //prescale divider*2

#define M6812_TFLG1	0x8E             //TC flags (timer compare/capture 0-7)
#define M6812_TFLG2	0x8F
/* Flags in M6812_TFLG2 could check if whole byte=0 since all other bytes always 0 */
#define M6812_TOF         (byte)(1<<7)     //timer over flow flag

#define M6812_TC0	0x90
#define M6812_TC1	0x92
#define M6812_TC2	0x94
#define M6812_TC3	0x96
#define M6812_TC4	0x98
#define M6812_TC5	0x9A
#define M6812_TC6	0x9C
#define M6812_TC7	0x9E
#define M6812_PACTL	0xA0
#define M6812_PAFLG	0xA1
#define M6812_PACN3	0xA2
#define M6812_PACN2	0xA3
#define M6812_PACN1	0xA4
#define M6812_PACN0	0xA5
#define M6812_MCCTL	0xA6
#define M6812_MCFLG	0xA7
#define M6812_ICPAR	0xA8
#define M6812_DLYCT	0xA9
#define M6812_ICOVW	0xAA
#define M6812_ICSYS	0xAB
#define M6812__RESAC	0xAC
#define M6812_TIMTST	0xAD
#define M6812_PORTT	0xAE
#define M6812_DDRT	0xAF
#define M6812_PBCTL	0xB0
#define M6812_PBFLG	0xB1
#define M6812_PA3H	0xB2
#define M6812_PA2H	0xB3
#define M6812_PA1H	0xB4
#define M6812_PA0H	0xB5
#define M6812_MCCNT	0xB6
#define M6812_TC0H	0xB8
#define M6812_TC1H	0xBA
#define M6812_TC2H	0xBC
#define M6812_TC3H	0xBE

/******** SCI Port (Asynchronous) *******/

#define M6812_SC0BD	0xC0
#define M6812_SC0BDH    0xC0
#define M6812_SC0BDL    0xC1

#define M6812_SC0CR1	0xC2
/* Flags in the SC0CR1 */
#define M6812_LOOPS	(byte)(1<<7)	//SCI Loop Mode/Single Wire Mode Enable
#define M6812_WOMS      (byte)(1<<6)	//Wired-Or Mode for Serial Pins
#define M6812_RSRC      (byte)(1<<5)	//Receiver source
#define M6812_M		(byte)(1<<4)	//SCI Character length
#define M6812_WAKE	(byte)(1<<3)	//Wake up method select (0=idle, 1=addr mark)
#define M6812_ILT	(byte)(1<<2)	//Idle Line Type (0=short, 1=long)
#define M6812_PE        (byte)(1<<1)    //Parity Enable
#define M6812_PT        (byte)(1<<0)    //Parity Type (0=even, 1=odd)

#define M6812_SC0CR2	0xC3
/* Flags in the SC0CR2 */
#define M6812_TIE	(byte)(1<<7)	//Transmit Interrupt enable
#define M6812_TCIE	(byte)(1<<6)	//Transmit Complete Interrupt Enable
#define M6812_RIE	(byte)(1<<5)	//Receive Interrupt Enable
#define M6812_ILIE	(byte)(1<<4)	//Idle Line Interrupt Enable
#define M6812_TE	(byte)(1<<3)	//Transmit Enable
#define M6812_RE	(byte)(1<<2)	//Receive Enable
#define M6812_RWU	(byte)(1<<1)	//Receiver Wake Up
#define M6812_SBK	(byte)(1<<0)	//Send Break

#define M6812_SC0SR1	0xC4
/* Flags in SC0SR1 */
#define M6812_TDRE	(byte)(1<<7)	//Transmit Data Register Empty
#define M6812_TC	(byte)(1<<6)	//Transmit Complete
#define M6812_RDRF	(byte)(1<<5)	//Receive Data Register Full
#define M6812_IDLE	(byte)(1<<4)	//Idle Line Detect
#define M6812_OR	(byte)(1<<3)	//Overrun Error
#define M6812_NF	(byte)(1<<2)	//Noise Flag
#define M6812_FE	(byte)(1<<1)	//Framing Error
#define M6812_PF	(byte)(1<<0)	//Parity Error flag

#define M6812_SC0SR2	0xC5
/* Flags in SC0SR2 */
#define M6812_RAF	0x01            //Receiver Active Flag

#define M6812_SC0DRH	0xC6
#define M6812_SC0DRL	0xC7            //Character received from hardware
#define M6812_SC1BD	0xC8
#define M6812_SC1BDH	0xC8
#define M6812_SC1BDL	0xC9
#define M6812_SC1CR1	0xCA
#define M6812_SC1CR2	0xCB
#define M6812_SC1SR1    0xCC
#define M6812_SC1SR2    0xCD

#define M6812_SC1DRH	0xCE
/* Flags in SC0DRH */
#define M6812_R8        (byte)(1<<7)    //Receive Bit 8
#define M6812_T8        (byte)(1<<6)    //Transmit bit 8

#define M6812_SC1DRL	0xCF

/********* SPI Port (synchronous) *********/

#define M6812_SP0CR1	0xD0
/* Flags in SP0CR1 */
#define M6812_SPIE      (byte)(1<<7)    //interrupt enable
#define M6812_SPE       (byte)(1<<6)    //SPI enable
#define M6812_SWOM      (byte)(1<<5)    //PortS Wired-OR Mode
#define M6812_MSTR      (byte)(1<<4)    //Master mode select
#define M6812_CPOL      (byte)(1<<3)    //Clock Polarity
#define M6812_CPHA      (byte)(1<<2)    //Clock Phase
#define M6812_SSOE      (byte)(1<<1)    //Slave Select (SS) Output enable
#define M6812_LSBF      (byte)(1<<0)    //LSB first (reverse bits transmitted)

#define M6812_SP0CR2	0xD1
/* Flags in SP0CR2 */
#define M6812_PUPS      (byte)(1<<3)    //Pullups
#define M6812_RDS       (byte)(1<<2)    //Reduce Drive
#define M6812_SPC0      (byte)1       //Serial Pin Control 0 Bit

#define M6812_SP0BR	0xD2          //Baud rate, max 7 (31.3kHz)

#define M6812_SP0SR	0xD3          //SPI Status
/* Flags in SP0SR */
#define M6812_SPIF      (byte)(1<<7)    //interrupt request flag
#define M6812_WCOL      (byte)(1<<6)    //Write collision stat
#define M6812_MODF      (byte)(1<<4)    //Err interrupt stat

#define M6812__RESD4	0xD4

#define M6812_SP0DR	0xD5          //Data register for SPI

#define M6812_PORTS	0xD6
#define M6812_DDRS	0xD7
/* Bit-to-port for PORTS and DDRS */
#define M6812_PORTS_SS   (byte)(1<<7)
#define M6812_PORTS_SCK        (1<<6)
#define M6812_PORTS_MOSI       (1<<5)
#define M6812_PORTS_MISO       (1<<4)
#define M6812_PORTS_TXD1       (1<<3)
#define M6812_PORTS_ADDR1      M6812_PORTS_TXD1
#define M6812_PORTS_RXD1       (1<<2)
#define M6812_PORTS_ADDR0      M6812_PORTS_RXD1
#define M6812_PORTS_TXD0       (1<<1)
#define M6812_PORTS_RXD0       (1<<0)

             /* 0xD8 - 0xDA   Reserved */

#define M6812_PURDS	0xDB
/* Flags in PURDS */
#define M6812_RDPS2     (byte)(1<<6)    //Reduce Drive for PS7-PS4
#define M6812_RDPS1     (byte)(1<<5)    //                 PS3,PS2
#define M6812_RDPS0     (byte)(1<<4)    //                 PS1,PS0
#define M6812_PUPS2     (byte)(1<<2)    //Pullups for PS7-PS4
#define M6812_PUPS1     (byte)(1<<1)    //            PS3,PS2
#define M6812_PUPS0           1       //            PS1,PS0

             /* 0xDC - 0xDF   Reserved */
#define M6812_SLOW	0xE0
             /* 0xE1 - 0xEF   Reserved */

#define M6812_EEMCR	0xF0
/* Flags in EEMCR */
#define M6812_EESWAI    (1<<2)
#define M6812_PROTLCK   (1<<1)
#define M6812_EERC      (1<<0)

#define M6812_EEPROT	0xF1        //protect bits for banks of eeprom
/* Blocks to protect */
#define M6812_EEPROT_000      (1<<4)
#define M6812_EEPROT_100      (1<<3)
#define M6812_EEPROT_200      (1<<2)
#define M6812_EEPROT_280      (1<<1)
#define M6812_EEPROT_2C0      (1<<0)

#define M6812_EETST	0xF2

#define M6812_EEPROG	0xF3
/* Flags in EEPROG */
#define M6812_BULKP     (byte)(1<<7)
#define M6812_BYTE      (1<<4)
#define M6812_ROW       (1<<3)
#define M6812_ERASE     (1<<2)
#define M6812_EELAT     (1<<1)
#define M6812_EEPGM     (1<<0)

#define M6812_FEELCK	0xF4
#define M6812_FEEMCR	0xF5
#define M6812_FEETST	0xF6
#define M6812_FEECTL	0xF7
             /* 0xF8 - 0xFF   BDLC not present*/

/********** msCAN Controller Area Network **********/

#define M6812_CMCR0     0x100       //Module Control Register 0
/* Flags in CMCR0 */
#define M6812_CSWAI     (1<<5)        //Stop in Wait mode
#define M6812_SYNCH     (1<<4)        //Synchronized-to-CAN-bus status
#define M6812_TLNKEN    (1<<3)        //Timer enable flag (to time frame with input capt
#define M6812_SLPAK     (1<<2)        //Sleep Ack flag
#define M6812_SLPRQ     (1<<1)        //Sleep Request for enabling sleep mode
#define M6812_SFTRES    (1<<0)        //Soft-Reset mode. 1=config CAN, 0=active

#define M6812_CMCR1     0x101       //Module Control Register 1
/* Flags in CMCR1 */
#define M6812_LOOPB     (1<<2)        //loopback for standalone testing
#define M6812_WUPM      (1<<1)        //Wakeup Mode Flag (filter wakeup glitches)
#define M6812_CLKSRC    (1<<0)        //Clock Source 0=EXTALi, 1=2*ECLK

#define M6812_CBTR0     0x102       //Bus Timing Register
/* Fields in CBTR0 */
#define M6812_POS_SJW       6           //Synch Jump Width
#define M6812_MSK_SJW   (0x3<<M6812_SJW)
#define M6812_MSK_BRP   (0x3F)      //Baudrate prescaler (val 0-63 = div 1-64)

#define M6812_CBTR1     0x103       //Bus Timing Reg 1
/* Flags/Fields in CBTR1 */
#define M6812_SAMP      (byte)(1<<7) //Samples per bit (1=3samps)
#define M6812_POS_TSEG2  4           //bit offset to TSEG2 bits
#define M6812_MSK_TSEG2  (0x7<<M6812_POS_TSEG2)
#define M6812_MSK_TSEG1  (0xF)

#define M6812_CRFLG     0x104       //Receiver Flag Register
/* Flags in CRFLG */
#define M6812_WUPIF     (byte)(1<<7)      //Wakeup
#define M6812_RWRNIF    (1<<6)      //Receiver warnning
#define M6812_TWRNIF    (1<<5)      //Transmitter warnning
#define M6812_RERRIF    (1<<4)      //Receiver Error Passive
#define M6812_TERRIF    (1<<3)      //Transmitter Error Passive
#define M6812_BOFFIF    (1<<2)      //Bus-Off
#define M6812_OVRIF     (1<<1)      //Overrun
#define M6812_RXF       (1<<0)      //Receive Buffer Full
#define M6812_RX_ERRMSK (M6812_RWRNIF|M6812_RERRIF|M6812_OVRIF)    //(0x52)
#define M6812_TX_ERRMSK (M6812_TWRNIF|M6812_TERRIF|M6812_BOFFIF)   //(0x2C)

#define M6812_CRIER     0x105       //Receiver Interrupt Enable Register
/* Flags in CRIER */
#define M6812_WUPIE     (byte)(1<<7)      //Wakeup
#define M6812_RWRNIE    (1<<6)      //Receiver warnning
#define M6812_TWRNIE    (1<<5)      //Transmitter warnning
#define M6812_RERRIE    (1<<4)      //Receiver Error Passive
#define M6812_TERRIE    (1<<3)      //Transmitter Error Passive
#define M6812_BOFFIE    (1<<2)      //Bus-Off
#define M6812_OVRIE     (1<<1)      //Overrun
#define M6812_RXFIE     (1<<0)      //Receive Buffer Full

#define M6812_CTFLG     0x106       //Transmitter Flg Reg
/* Flags in CTFLG */
#define M6812_ABTAK2    (1<<6)      //set if abort successful
#define M6812_ABTAK1    (1<<5)
#define M6812_ABTAK0    (1<<4)
#define M6812_TXE2      (1<<2)      //ready to send next. Write 1 to clear and send next
#define M6812_TXE1      (1<<1)
#define M6812_TXE0      (1<<0)

#define M6812_CTCR      0x107       //Transmitter control Reg
/* Flags in CTCR */
#define M6812_ABTRQ2    (1<<6)      //Request abort if hasn't started sending
#define M6812_ABTRQ1    (1<<5)
#define M6812_ABTRQ0    (1<<4)
#define M6812_TXEIE2    (1<<2)      //Transmitter empty IRQ enable
#define M6812_TXEIE1    (1<<1)
#define M6812_TXEIE0    (1<<0)

#define M6812_CIDAC     0x108       //Identifier acceptance control reg
/* Fields in CIDAC */
#define M6812_POS_IDAM 4           //bit position for IDent Acceptance filter bits
#define M6812_MSK_IDAM  (0x3<<M6812_POS_IDAM)
#define M6812_MSK_IDHIT (0x7)       //bits for IDA Hit. Shows which filter(s) hit

#define M6812_CRXERR    0x10E       //Receive err count
#define M6812_CTXERR    0x10F       //Transmit err count

#define M6812_CIDAR0    0x110       //ID Acceptance Register (32 bits by 2 banks)
#define M6812_CIDAR2    0x112
#define M6812_CIDMR0    0x114       //Mask IDA
#define M6812_CIDMR2    0x116
#define M6812_CIDAR4    0x118
#define M6812_CIDAR6    0x11A
#define M6812_CIDMR4    0x11C
#define M6812_CIDMR6    0x11E

#define M6812_PCTLCAN   0x13D       //pin control
/* Flags in PCTLCAN */
#define M6812_PUECAN    (1<<1)      //Pullup ena
#define M6812_RDPCAN    (1<<0)      //Reduced Drive ena

#define M6812_PORTCAN   0x13E       //data i/o, 1=TxCAN 0=RxCAN
#define M6812_DDRCAN    0x13F       //data direction for each CAN io

/* CAN buffers */
#define M6812_RXFG      0x140       //Receive buffer     (CAN message buffers)
#define M6812_TX0       0x150       //Transmit buffer 0
#define M6812_TX1       0x160       //Transmit buffer 1
#define M6812_TX2       0x170       //Transmit buffer 2
/* Offsets of CAN message buffers */
#define M6812_CAN_IDR0   0x0        //Destination/type of message
#define M6812_CAN_IDR2   0x2
#define M6812_CAN_DATA   0x4        //up to 8 data bytes (0x4-0xB)
#define M6812_CAN_LEN    0xC        //number of data bytes
#define M6812_CAN_PRIO   0xD        //not applicable for Rx buffer
/* Fields/Flags in (word) IDR0-1 */
#define M6812_CAN_POS_ID  5
#define M6812_CAN_MSK_ID  ((word)0xFFE0)  //all bits for standard ID
#define M6812_CAN_RTR     ((word)0x0010)  //std RTR (always 1 in extended)
#define M6812_CAN_IDE     ((word)0x0008)  //1=extended ID
/* Flag in (word) IDR2-3 */
#define M6812_CAN_XRTR    ((word)0x0001)  //extened RTR

/**************************************************************/

/* Default SCI port is SC0. (SC1 is not even implimented on our chip) */
#define M6812_SCBD     M6812_SC0BD
#define M6812_SCCR1    M6812_SC0CR1
#define M6812_SCCR2    M6812_SC0CR2
#define M6812_SCSR1    M6812_SC0SR1
#define M6812_SCSR2    M6812_SC0SR2
#define M6812_SCDRH    M6812_SC0DRH
#define M6812_SCDRL    M6812_SC0DRL
#define M6812_SCDR     M6812_SC0DRL

/* default input register for AD */
#define M6812_PORTAD   M6812_PORTAD0

/* Ports with common name and function between hc11/hc12 */
#if 0
#define M6811_PORTA        M6812_PORTA   //Port A register
#define M6811_PORTB        M6812_PORTB   //Port B register
#endif
#define M6811_DDRA         M6812_DDRA    //Data Direction Port A
#define M6811_DDRB         M6812_DDRB    //Data Direction Port A

/* Bit-to-port for PORTS and DDRS, common name between hc11/hc12 */
#define PORTS_SS      M6812_PORTS_SS
#define PORTS_SCK     M6812_PORTS_SCK
#define PORTS_MOSI    M6812_PORTS_MOSI
#define PORTS_MISO    M6812_PORTS_MISO
#define PORTS_TXD1    M6812_PORTS_TXD1
#define PORTS_RXD1    M6812_PORTS_RXD1
#define PORTS_ADDR1   M6812_PORTS_TXD1
#define PORTS_ADDR0   M6812_PORTS_RXD1
#define PORTS_TXD0    M6812_PORTS_TXD0
#define PORTS_RXD0    M6812_PORTS_RXD0


/* The I/O registers are represented by a volatile array.
   Address if fixed at link time.  */
extern volatile unsigned char _io_ports[];

#define M6811_SPSR M6812_SP0SR
#define M6811_SPDR M6812_SP0DR
#define M6811_SPCR M6812_SP0CR1
#define M6811_SPIF M6812_SPIF
#define M6811_SPE  M6812_SPE
#define M6811_DDRD M6812_DDRS

#endif /* _M68HC11_PORTS_DEF_H */

