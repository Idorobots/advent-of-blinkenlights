/* eeprom.h -- EEprom Programming Interface
   Copyright 2000, 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _EEPROM_H
#define _EEPROM_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup eeprom EEprom Operations

    This module provides operations to write to the 68HC11 internal
    eeprom.

 */
/*@{*/
  
/*! Write a byte in eeprom.

    Write the byte \b value in the eeprom at address \b p.
    The eeprom byte location is erased first if write operation
    is not possible (when at least one bit must be set to 1).

    @param p      Address of the eeprom byte to write
    @param value  Value to write
    @see eeprom_write_short  */
extern void eeprom_write_byte (unsigned char *p, const unsigned char value);

/*! Write a short in eeprom.

    Write the short \b value in the eeprom at address \b p.
    The eeprom byte locations are erased first if write operation
    is not possible (when at least one bit must be set to 1).

    @param p      Address of the eeprom byte to write
    @param value  Value to write
    @see eeprom_write_byte  */
extern void eeprom_write_short (unsigned short *p, const unsigned short value);

/*! Low address of internal EEPROM bank.

    The \b eeprom_low variable represents the first byte of the internal
    EEPROM.  Its address is fixed at link time.  

*/
extern unsigned char eeprom_low;
  
extern unsigned char eeprom_high;

#ifdef __cplusplus
};
#endif

/*@}*/

#endif
