/* dcf77.h -- DCF77 Time module
   Copyright 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_DCF77_H
#define _GEL_DCF77_H

#include <time.h>
#include <gel/event.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup dcf77 DCF77 Atomic Clock Module

    The DCF77 module gives the time of the day as reported by an external
    DCF77 receptor connected to the board.  The DCF77 emitter uses an
    atomic clock to provide high precision time (no drift).

    The time is sent by the emitter one bit per second, and 60 bits per
    frame.  The complete sequence indicates the time, day, month and year.
    See http://www.eecis.udel.edu/~mills/ntp/dcf77.htm.

    The software module is split into two parts:

    <ul>
       <li>an upper part provides the API.  It is completely generic
           and does not depend on the board.  It detects the synchronization,
	   receives the DCF77 bits and creates a time structure.  It raises
	   two events: one for synchronization and one for time update.

       <li>a bottom part which is board specific and which is responsible
           for getting one bit from the DCF77 external receptor.
	   This is implemented by the \b dcf77_input_probe function that
	   is called by the upper part when it needs to.

    </ul>

    The synchronization event is raised when synchronization is detected
    or when it is lost.

    The time update event is raised when the first bit is received.

 */
/*@{*/


/*! Initialize the DCF77 module.

    The DCF77 module must be initialized to register a timer handler
    to poll and analyze the DCF77 input.

*/
extern void dcf77_initialize (void);

/*! Get the DCF77 UTC time.

    Return a pointer to a \b tm structure which contains the
    current time (UTC).  The structure should not be modified.

*/
extern const struct tm *dcf77_gettime (void);

/*! Probe the DCF77 input.

    This function must be implemented by the board.  It probes the DCF77 input
    and returns either 0 or 1.  It needs not return compute and return the
    value of the current DCF77 frame bit.  That is, the upper layer calls
    this operation several times per second and determines itself the frame
    bit based.  The frame bit will be 0 when the probe function returns
    a 1 for less than 100ms and it will be 1 when the duration is arround
    200ms.

*/
extern unsigned dcf77_input_probe (void);

/*! Event to report changes in synchronisation state.  */
extern event_type dcf77_sync;

/*! Event to notify new date available.  */
extern event_type dcf77_update_time;
  

/*@}*/

#ifdef __cplusplus
};
#endif
#endif
