/* timer.h
   Copyright 2000, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_TIMER_H
#define _GEL_TIMER_H

#include <sys/param.h>

/*! @defgroup timer Time and timer operations.

 */
/*@{*/

#ifndef GEL_PAGE0_ATTRIBUTE
# define GEL_PAGE0_ATTRIBUTE
#endif

#define TIMER_TCNT_CLOCK_UNIT (2)

#ifndef TIMER_TCNT_DIV
# define TIMER_TCNT_DIV (16)
#endif

#if 0
#define TIMER_TCNT_CLOCK_PERIOD  \
(((TIMER_TCNT_DIV * 1000000L) * TIMER_TCNT_CLOCK_UNIT) / M6811_CPU_E_CLOCK)
#endif

#define TIMER_TCNT_PERIOD \
((TIMER_TCNT_CLOCK_PERIOD * 65536) / TIMER_TCNT_CLOCK_UNIT)

#define TIMER_TCNT_CLOCK_PERIOD 1

struct timeval
{
  long tv_sec;
  long tv_usec;
};

#define ULONG_MAX (0xffffffffUL)
struct timer;

/*! Timer overflow handler.  */
typedef void (* timer_overflow_handler) (void);

typedef void (* timer_handler) (struct timer *t);

#define TIMER_MASK   0x00
#define TIMER_UNMASK 0x01
#define TIMER_SLOW   0x02
#define TIMER_OVERFLOW_INTERRUPT 0x04
#define TIMER_HEAD   0x80

/*! Timer data structure definition.

    This structure represents the timer object which holds the
    necessary information to represent the timer.  It is allocated
    by the caller and must not be used/re-used until the timer is
    removed or fires.
 */
struct timer 
{
  struct timer   *next;
  struct timer   *prev;
  unsigned short flags;
  long           timeout;
  timer_handler  handler;
  void           *data;
};

#define TIMER_INIT_STATIC(FUNC,FLAGS) { 0, 0, FLAGS, 0, FUNC, 0 }

/*! Initialize the timer module.

    This function initializes the timer module and setup
    everything to handle timer overflow and real time interrupts.
    It must be called only once before using any other timer
    operation.

    When using the single or extending bootstrap mode, the following
    vectors must be installed in the vector table:

    RTI_VECTOR			timer_interrupt
    TIMER_OVERFLOW_VECTOR	timer_overflow_interrupt

    @see timer_create, timer_remove  */
extern void timer_initialize (void);

/*! Create and register a timer.

    Initializes the timer object \b t and register the timer
    handler \b handler to be called after the time specified by \b timeout.
    The timeout is rounded up to a multiple of the timer resolution.
    The \b flags controls various aspects of the timer management.

    The timer module has two timer lists with different resolutions.
    A first list is connected to the real time interrupt; it is called
    the fast timers.  The second list is connected to the timer overflow
    interrupt; it is called the slow timers.
    
    The timer object is inserted in one of the two timer list.
    The choice of the list is made by the \b TIMER_SLOW bit
    of the \b flags parameter.  This flag also controls the unit in which
    the timeout is expressed.
    The two lists have different resolutions:

    <dl>
    <dt>slow timers
    <dd>
        When TIMER_SLOW is set, the timer is inserted in the slow list.
	The slow timers have a resolution of 1 second.  The \b timeout
	value is expressed in seconds.

    <dt>fast timers
    <dd>
        When TIMER_SLOW is cleared, the timer is inserted in the fast list.
	The resolution is that of the real time interrupt.  The \b timeout
	value is expressed in milliseconds.  It is rounded up to a
	multiple of real time interrupt resolution.
    </dl>

    @param t       the timer object
    @param timeout the timeout in seconds or milliseconds
    @param handler the handler to invoke when the timer fires
    @param flags   the flags to control the timer object
    @see timer_insert, timer_remove  */
extern void timer_create (struct timer *t,
			  unsigned long timeout,
			  timer_handler handler,
			  unsigned char flags);

/*! Register a timer.

    This operation is similar to \b timer_create but it only registers
    the timer by inserting the object in the good list.  The timer object
    pointed to by \b t must have its member initialized with the same
    values as \b timer_create.

    As for \b timer_create, the timer object is inserted in the slow
    or fast timers list depending on the \b flags member.

    @param t      the timer object
    @see timer_create, timer_remove  */
extern void timer_insert (struct timer *t);

/*! Remove a timer.

    Removes the timer object \b t from the timer list.

    When the last fast timer is removed, the real time interrupts are
    disabled.  They are enabled again when the first fast timer is inserted.

    @param t     the timer object
    @see timer_create, timer_insert  */
extern void timer_remove (struct timer *t);

/*! Return the status of a timer.

    Returns 1 if the timer object \b t is active and will be fired.
    Returns 0 if it is not inserted in one of the two timer lists.

    @param t     the timer object
    @see timer_create, timer_insert, timer_remove  */
extern int timer_is_active (struct timer *t);

/*! Get the current time.

    Returns in the \b tv parameter the current time.  The current
    time is expressed in seconds and microseconds.

    The current time is computed by taking a snapshot of a
    timer overflow counter and the free running counter.  A boot
    time is added to the second portion to obtain the current time.
    Accurracy of the result depends on the resolution of the free
    running counter.  The value returned is also a snapshot of the
    time within \b timer_gettime.

    This function is intended to be close to the Unix \b gettimeofday
    operation.

    @param tv pointer to the timeval structure for the result
    @see timer_settime, timer_adjtime  */
extern void timer_gettime (struct timeval *tv);

/*! Set the current time.

    Set the current time to \b tv.

    This function is intended to be close to the Unix \b settimeofday
    operation.

    @param tv  pointer to the timeval structure holding the new time
    @see timer_gettime, timer_adjtime  */
extern void timer_settime (struct timeval *tv);

/*! Adjust the time smoothly.

    This function has a similar functionality as the standard \b adjtime
    function (see RFC 1589).  It adjust the current time by advancing
    or retarding it by the amount specified in \b adj_usec.

    @param adj_usec   the adjustment in microseconds
    @return the adjustment that remains with repect to previous call  */
extern long timer_adjtime (long adj_usec);

/*! Subtract a timeval.

    Subtract from \b to the time in \b val.  The result time can
    become negative.

    @param to  result and value from which to subtract
    @param val value to subtract
    @see timevaladd  */
extern void timevalsub (struct timeval *to, struct timeval *val);

/*! Add a timeval.

    Add in \b to the time in \b val.

    @param to  result and value to add
    @param val value to add
    @see timevalsub  */
extern void timevaladd (struct timeval *to, struct timeval *val);

extern unsigned long timer_current_overflow (void);
extern unsigned long usec_to_tcnt (unsigned long);
extern unsigned long usec_to_overflow (unsigned long);
extern unsigned long tcnt_to_usec (unsigned short);
extern unsigned long tovf_to_usec (unsigned long);
extern unsigned long tovf_to_sec (unsigned long);

/*! Timer overflow interrupt handler

 */
extern void __attribute__((interrupt)) timer_overflow_interrupt (void);

/*! Real time interrupt handler.

    This is the real time interrupt handler that must be installed
    in RTI_VECTOR to process real time interrupts and process the
    fast timers.

*/
extern void __attribute__((interrupt)) timer_interrupt (void);

/*! Install the timer overflow handler.  */
static void set_timer_overflow_handler (timer_overflow_handler handler);

static inline void
set_timer_overflow_handler (timer_overflow_handler handler)
{
  extern timer_overflow_handler _overflow_handler;

  _overflow_handler = handler;
}

extern inline unsigned long
timer_current_overflow (void)
{
  extern unsigned long _timer_current_overflow;

  return _timer_current_overflow;
}

/** Translate microseconds into a timer counter value.
 */
extern inline unsigned long
usec_to_tcnt (unsigned long us)
{
  us = us / TIMER_TCNT_CLOCK_PERIOD;
  return us * TIMER_TCNT_CLOCK_UNIT;
}

extern inline unsigned long
usec_to_overflow (unsigned long us)
{
  return us / TIMER_TCNT_PERIOD;
}

extern inline unsigned long
tcnt_to_usec (unsigned short tcnt)
{
  unsigned long usec;

  usec = ((unsigned long) (tcnt) * TIMER_TCNT_CLOCK_PERIOD);
  usec = usec / TIMER_TCNT_CLOCK_UNIT;
  return usec;
}

extern inline unsigned long
tovf_to_usec (unsigned long overflow)
{
  unsigned long usec;

  usec = overflow * TIMER_TCNT_PERIOD;
  usec = usec % 1000000UL;
  return usec;
}

extern inline unsigned long
tovf_to_sec (unsigned long overflow)
{
  unsigned long sec;

  sec = overflow * TIMER_TCNT_PERIOD;
  return sec;
}


extern inline int
timer_is_active (struct timer *t)
{
  return t->next != 0;
}

/*@}*/

#endif
