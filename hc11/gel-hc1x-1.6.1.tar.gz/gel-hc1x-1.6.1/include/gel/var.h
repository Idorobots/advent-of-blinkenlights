/* var.h -- Variable Definition
   Copyright 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_VAR_H
#define _GEL_VAR_H

#include <stddef.h>

union var_value
{
  unsigned char u8;
  unsigned short u16;
  unsigned long u32;
};

enum var_type
{
  V_UINT8,
  V_UINT16,
  V_UINT32
};

enum var_format
{
  F_INTEGER,
  F_ONOFF
};

struct var_def
{
  const char      *title;
  enum var_type   type : 8;
  enum var_format format : 8;
  unsigned long   min_value;
  unsigned long   max_value;
  unsigned long   def_value;
  union
  {
    unsigned char *uint8;
    unsigned short *uint16;
    unsigned long *uint32;
  } u;
};

/*! Return the integer value of the variable.

    @param var  Pointer to the variable definition
    @return     Value of the variable (expressed as a long)  */
extern unsigned long var_value (const struct var_def *var);

/*! Format the variable value in the buffer.

    Create a printable representation of the variable.
    The variable is formated according to its format type.

    @param buf  Buffer large enough to hold the result
    @param var  Pointer to the variable definition
    @see var_value  */
extern void var_format (char *buf, const struct var_def *var,
                        unsigned long value);

/*! Set the variable.

    Set the integer variable to a given value.
    The value is truncated to fit in the [min..max] range defined
    by the variable definition.  If the variable lies in EEPROM,
    the EEPROM is written, thus saving the value permanently.

    @param var   Pointer to the variable definition
    @param value Value to assign to the variable
    @see var_format, var_value  */
extern void var_set_integer (const struct var_def *var, unsigned long value);

/*! Register a variable definition.

    @param var  Pointer to the variable definition
    @see var_value, var_format  */
extern void var_register (const struct var_def *var);

extern unsigned var_count;
extern const struct var_def *var_list[];

#endif
