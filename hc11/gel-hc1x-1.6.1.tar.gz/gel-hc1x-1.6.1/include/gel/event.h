/* event.h - Event management
   Copyright 2000, 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_EVENT_H
#define _GEL_EVENT_H

/*! @defgroup event Event management

    This module is a small event manager.  It contains a queue of events
    and allows other modules to subscribe to a particular event type.
    

    Subscribing to an event means connecting a callout object to the event
    type.  The callout contains a function which is called by the event
    manager when an event of the corresponding type is received.
    The callout object should be a static object.  It should be registered
    only once with the \b event_register method.

    Posting an event is an asynchronous operation which does not block.
    The event is marked with a time stamp and inserted in the event queue.
    The event is posted using the \b event_post function.

    The event manager does not use threads to report events to its
    subscribers.  It is necessary to call explicitly the event manager
    so that it dispatches the pending events.
 */
/*@{*/
struct event;
struct event_callout;
struct event_def;
typedef struct event_def *event_type;
typedef struct event event;
typedef struct event_callout event_callout;

extern unsigned long event_idle_counter;

/*! Event description.

    The \b event type represents events as stored in the event queue.
    Each event is typed.  The type is used to identify the subscribers.
    With each event, a short value (16-bits) can be saved when the
    event is posted.  This value is event specific.  There is no semantics
    and no treatment on it.  */
struct event
{
  /*! Type of the event.  */
  event_type     type;

  /*! Small time stamp.  */
  unsigned short time;

  /*! Small event data.  */
  unsigned short data;
};

typedef void (* event_handler_t) (event_callout *, event *);

struct event_callout
{
  struct event_callout *next;
  struct event_def     *type;
  event_handler_t       callback;
  void *data;
};

struct event_def
{
  struct event_callout *callouts;
};

/*! Initialize the event package.
    
    The event buffer queue is passed in 'queue' and it can contain
    up to 'size' events.  Initialization should be done only once
    and before using any other event method.

    @param queue the event buffer queue
    @param size  the size in element of that buffer
    @see event_post
*/
void
event_initialize (event *queue, unsigned short size);

/*! Post an event.

    An event of the specified type is queued at the end of the event queue.
    The event queue contains a fixed number of elements. It does not grow.
    If the event queue was full, the oldest event is forgotten.
    The event is marked with the free running timer counter. This operation
    is designed to be efficient and can be called from an interrupt
    handler.  When the event is queued, the data parameter is saved with it.
    This value is not interpreted and can be used to pass some additional
    information related to the event itself.

    Events are dispatched synchronously by `event_dispatch' which
    activates the handlers that were registered.

    @param type the type of the event
    @param data the data value associated with the event
    @see event_initialize, event_register, event_dispatch
*/
void
event_post (event_type type, unsigned short data);

/*! Register an event handler.
    
    Register an handler to receive events of a given type.

    @param type the type of the event to subscribe
    @param callout
    @param handler operation to be called when the event is received
    @param client_data specifies the argument of the handler
*/
void
event_add_callout (event_type type, event_callout *callout);

/*! Remove an event callout.
 */
void
event_remove_callout (event_callout *callout);

/*! Register an event handler.
    
    Register an handler to receive events of a given type.

    @param type the type of the event to subscribe
    @param callout
    @param handler operation to be called when the event is received
    @param client_data specifies the argument of the handler
*/
extern void event_register (event_type type, event_callout *callout,
                            event_handler_t handler, void *client_data);

extern inline void
event_register (event_type type, event_callout *callout,
                event_handler_t handler, void *client_data)
{
  callout->callback = handler;
  callout->data = client_data;
  event_add_callout (type, callout);
}

extern void event_unregister (event_callout *);

extern inline void
event_unregister (event_callout *callout)
{
  event_remove_callout (callout);
}

extern unsigned char event_false;

extern void
event_loop (unsigned long tick, unsigned char *bool);

extern void
event_wait (unsigned long nticks, event_type type);

/*@}*/

#endif
