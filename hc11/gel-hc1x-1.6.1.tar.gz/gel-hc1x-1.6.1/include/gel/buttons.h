/* buttons.h -- Button Module for EBCS
   Copyright 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of EBCS.

EBCS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

EBCS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with EBCS; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _EBCS_BUTTONS_H
#define _EBCS_BUTTONS_H

#include <sys/param.h>
#include <gel/event.h>
#include <gel/timer.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup buttons EBCS Button Module

 */
/*@{*/

/*! Button enumeration.  */
enum button
{
  BUTTON_1 = 0,
  BUTTON_2 = 1,
  BUTTON_3 = 2,
  BUTTON_4 = 3
};
typedef unsigned short button_t;

#ifndef GEL_MAX_BUTTONS
#  define GEL_MAX_BUTTONS 4
#endif

#if GEL_MAX_BUTTONS <= 8
typedef unsigned char button_mask_t;
#elif GEL_MAX_BUTTONS <= 16
typedef unsigned short button_mask_t;
#else
typedef unsigned long button_mask_t;
#endif

enum key_mode
{
  KEY_PRESS,
  KEY_RELEASE
};

typedef struct
{
  unsigned long button_press_count;
} button_stat_t;

/*! Initialize the button module.

    Configure the button module.  This function must be called
    once before any other.  After initialization, the button
    polling is disabled.

    @see button_enable, button_disable, button_get_pressed  */
extern void button_initialize (void);

/*! Return a mask for pressed buttons.

    @return the mask identifying pressed buttons
    @see button_enable, button_disable  */
extern button_mask_t button_get_pressed (void);

/*! Enable the polling of buttons.

    Enable the polling of buttons.  The button are scanned periodically
    and their state can be queried using \b button_get_pressed or
    by waiting for button events.

    The accumulator interrupts (PA7) are enabled and the button
    timer is activated.

    While buttons are polled, the application must not print on
    the LCD panel.  It is necessary to disable the polling.

    @see button_disable, button_get_pressed  */
extern void button_enable (void);

/*! Disable the polling of buttons.

    Disable the polling of buttons.  This operation must be called
    before sending LCD commands.  Otherwise, these commands can
    disturb the button polling.

    The accumulator interrupts (PA7) are disabled and the button
    timers are deactivated.

    @see button_enable  */
extern void button_disable (void);

/*! Return true if the buttons are enabled.

    @return 1 if the buttons are enabled.
    @see button_enable, button_disable  */
extern int button_is_enabled (void);

/*! Button change event.

    The button change event is triggerred each time the state of
    the buttons change.  It is activated when a button is pressed
    or when a button is released.  */
extern struct event_def button_change_event;

/*@}*/

#ifdef __cplusplus
};
#endif

#endif
