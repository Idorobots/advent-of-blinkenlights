/* panel.h -- Panel display and management interface
   Copyright 2001, 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_PANEL_H
#define _GEL_PANEL_H

#include <sys/param.h>
#include <lcd.h>
#include <gel/event.h>
#include <gel/timer.h>
#include <gel/buttons.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup panel Panel Management and Display Interface

    The panel module controls the LCD display and the keyboard.
    It reacts to keyboard events and manages all LCD display update.

    A panel entity displays its data on the LCD.  It does so
    using the \b panel_putXXX operations.  It provides a keyboard input
    callback to react to keyboard events.

    The panel module allows to push or pop panels.  

 */
/*@{*/

struct panel_line
{
  lcd_col_t     col_start;
  lcd_col_t     col_end;
  unsigned char content[LCD_MAX_COLS];
};

typedef unsigned short key_t;

struct panel;

/*! Panel enter callback.

    Callback function invoked when the panel object is activated and
    has the LCD focus.  This is called by \b panel_push and \b panel_pop
    on the panel which is activated.

    @param p  Pointer to the panel object.
*/
typedef void (* panel_enter_t) (struct panel *p);

/*! Panel leave callback.

    Callback function invoked when the panel object is deactivated and
    looses the LCD focus.  This is called by \b panel_push and \b panel_pop
    on the panel which is deactivated.  When a new panel is installed,
    the current active panel is first deactivated.

    @param p  Pointer to the panel object.
*/
typedef void (* panel_exit_t) (struct panel *p);

/*! Panel refresh callback.

    Refresh the panel.  This function is called by the panel main loop
    to automatically update the panel content.  The function must update
    the panel using \b panel_putstring to show a newer or an up to date
    content.  It must return the delay in milliseconds to wait before
    the next refresh.

    @param p  Pointer to the panel object.
    @result   The delay in milliseconds to wait before the next refresh
*/
typedef unsigned long (* panel_refresh_t) (struct panel *p);

/*! Panel input handler.

 
    Callback to handle the buttons for the panel.

    @param p      Pointer to the panel object.
    @param mode   Whether the key is pressed or released
    @param button Button which is pressed or released
*/
typedef void (* panel_input_t) (struct panel *p, enum key_mode mode,
                                button_t button);

struct panel
{
  panel_enter_t     to_enter;
  panel_exit_t      to_exit;
  panel_refresh_t   to_refresh;
  panel_input_t     to_input;
  unsigned long     refresh_delay;
  unsigned long     inactivity_delay;
  unsigned char     visible;
  unsigned char     cursor_visible;
  lcd_col_t         cursor_col;
  lcd_line_t        cursor_line;

  struct panel *next;
  struct panel_line lines[LCD_MAX_LINES];
};

/*! Justification mode

 */
enum panel_justify
{
  JUSTIFY_LEFT,
  JUSTIFY_RIGHT,
  JUSTIFY_CENTER
};


/*! Write the character on the panel.

    Write the character \b ch at position \b col, \b line on the panel.
    The character is not written on the LCD device but in an internal
    panel memory.  The \b panel_refresh operation synchronizes the
    panel memory and the LCD display.

    @param p    Pointer to the panel object
    @param col  Column where to write
    @param line Line where to write
    @param ch   Character to write
    @see panel_putstring, panel_refresh  */
extern void panel_putchar (struct panel *p, lcd_line_t line,
			   lcd_col_t col, unsigned char ch);

/*! Write the string on the panel.

    Write the string \b str at position \b col, \b line on the panel.
    The string is not written on the LCD device but in an internal
    panel memory.  The \b panel_refresh operation synchronizes the
    panel memory and the LCD display.

    @param p    Pointer to the panel object
    @param col  Column where to write
    @param line Line where to write
    @param str  String to write
    @see panel_putchar, panel_refresh  */
extern void panel_putstring (struct panel *p, lcd_line_t line,
			     lcd_col_t col, const char *str);

/*! Write a justified string on the panel.

    Justify the string \b item according to the justification mode \b mode
    and the item length \b field_len.  The justified string is then
    written on the panel \b p at position \b col, \b line.

    @param p    Pointer to the panel object
    @param col  Column where to write
    @param line Line where to write
    @param mode Justification mode to use
    @param field_len Length of the final item
    @param str  String to write
    @see panel_putchar, panel_refresh  */    
extern void panel_putitem (struct panel *p, lcd_line_t line, lcd_col_t col,
			   enum panel_justify mode, int field_len,
			   const char *item);

/*! Clear the rest of the line.

    Clear the rest of the line \b line starting at \b col by
    writing spaces in it.

    @param p    Pointer to the panel object
    @param line Line to clear
    @param col  Column to start
    @see panel_putchar, panel_refresh  */
extern void panel_clear_line (struct panel *p, lcd_line_t line, lcd_col_t col);

/*! Return the character displayed on the panel.

    @param p   Null or pointer to the panel object
    @param col Column number
    @param line Line number
    @return The character at the given position
    @see panel_putchar  */
extern unsigned char panel_getchar_at (struct panel *p,
                                       lcd_line_t line, lcd_col_t col);

/*! Refresh the panel.

    Refresh the LCD display to match the content with the active panel.
    This function optimizes by only updating the LCD part which has
    changed. This is the only function which calls the LCD print operations.

    @see panel_putchar, panel_putstring, panel_redraw  */
extern void panel_refresh (void);

/*! Touch the panel.

    Forget any optimization about the LCD panel display.

    @see panel_refresh  */
extern void panel_touch (void);

/*! Returns true if the panel must be refreshed.

    Returns true if the LCD display is not synchronized with the
    active panel and a call to \b panel_refresh is necessary.

    @return true if the panel must be refreshed.
    @see panel_refresh, panel_touch  */
extern int panel_need_refresh (void);

/*! Panel is visible.

    Return whether the panel is visible.

    @param p   Pointer to the panel object
    @return  true if the panel is visible
    @see panel_push  */
extern int panel_is_visible (struct panel *p);

/*! Push the panel.

    Push the panel \b p making it the active panel.  The previous
    active panel is kept for later re-activation with panel_pop.

    @param p   Pointer to the panel object
    @see   panel_pop  */
extern void panel_push (struct panel *p);

/*! Pop the active panel moving to the previous one.

    Pop the active panel and redraw the previous one.
    The to_exit handler of the active panel is called before deactivating
    it.  The to_enter handler of the previous panel is called
    to activate it.

    @see panel_push, panel_refresh  */
extern void panel_pop (void);

/*! Create the panel object.

    @param p    Pointer to the panel object.  */
extern void panel_create (struct panel *p);

/*! Initialize the panel module.

    @see panel_create  */
extern void panel_initialize (void);

extern void panel_setcursor (struct panel *p, lcd_line_t line, lcd_col_t col);

extern void panel_show_cursor (struct panel *p, int mode);

extern void panel_loop (void) __attribute__ ((noreturn));

/*@}*/

#ifdef __cplusplus
};
#endif
#endif
