/* display-hw.h -- Graphics Display Manager
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_DISPLAY_HW_H
#define _GEL_DISPLAY_HW_H

#include <sys/param.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup gdm_hw  Hardware Low Level Operation for Graphic Display Manager

    The hardware low level operations must be provided by the BSP to
    access the LCD hardware.  They are very basic operations that in general
    just write one LCD hardware register.  They should be inline if possible.

    When porting the <b>Graphic Display Manager</b> to a new board, you
    must provide the following API:

    <dl>
    <dt>_gdm_hw_set_side
    <dd>is used to select the KS0108 driver. This operation is called by
    <b>GDM</b> before setting X, Y or writing a data to the LCD DDRAM.
    The library optimizes calls to avoid changing the KS0108 driver if the
    correct driver was previously selected.

    <dt>_gdm_hw_set_y
    <dd>is used to set the Y register of the KS0108 driver.  This is called
    before writing a data to the LCD DDRAM.  It is assumed that the Y register
    is automatically incremented after each read/write operation in DDRAM.

    <dt>_gdm_hw_set_x
    <dd>is used to set the X register of the KS0108 driver.  This is called
    before writing the Y register and the data to the LCD RAM.  The library
    optimizes calls to to avoid changing the X register when it has the
    correct value already.

    <dt>_gdm_hw_set_data
    <dd>is used to write a byte in the LCD DDRAM at the current X, Y
    register.

    <dt>_gdm_hw_set_mode
    <dd>is used to enable/disble the display, hide/show the backlight LED.
    </dl>

 */
/*@{*/

/*! Set the active side of the LCD controller.

    This function is board specific.  The 128x64 display has two drivers.
    The left driver is selected when @b side is 0.  The right driver is
    selected when @side is 1.

    @param dp   Display Manager
    @param side Left or right side of the LCD display  */
extern void _gdm_hw_set_side (gdm_display* dp, unsigned short side);

/*! Set the LCD graphics hardware Y register.

    This function is board specific.  It must set the Y register of the
    KS0108 driver to the value @b y.  The Y register is assumed to be
    incremented after each data write.  The value passed by GDM is
    guarranteed to be in the range 0 .. GDM_HEIGHT that is 0 .. 63.

    @param dp   Display Manager
    @param y    Y register value (0..63)  */
extern void _gdm_hw_set_y (gdm_display* dp, unsigned short y);

/*! Set the LCD graphics hardware X register.

    This function is board specific.  It must set the X register of the
    KS0108 driver to the value @b x.  The value passed by GDM is guarranteed
    to be in the range 0 .. GDM_WIDTH / 2 * 8 that is 0 .. 7.

    @param dp   Display Manager
    @param x    X register value (0..7)  */
extern void _gdm_hw_set_x (gdm_display* dp, unsigned short x);

/*! Send data to the LCD graphics DDRAM.

    This function is board specific.  It must write the data value to
    the LCD graphics DDRAM.  The data is written at the current X, Y
    position set by @b _gdm_hw_set_x and @b _gdm_hw_set_y.  The Y register
    is assumed to be incremented after each data write.

    @param dp   Display Manager
    @param data Data byte to write  */
extern void _gdm_hw_set_data (gdm_display* dp, unsigned char data);

/*! Setup the start line of the display data.

    This function is board specific.  It must set the start line of the
    KS0108 driver to the value specified in @b line.

    @param dp   Display Manager
    @param line Start line to display on top of LCD side (0..63)  */
extern void _gdm_hw_set_line (gdm_display* dp, unsigned short line);

/*! Setup the display mode and backlight.

    This function is board specific.  The @b mode parameter controls some
    modes provided by the graphics display:

    GDM_DISPLAY_ON   When this flag is set, the graphics LCD display is on.
    GDM_BACKLIGHT_ON When this flag is set the backlight LED must be switched
                     on.

    @param dp   Display Manager
    @param mode Control mode  */
extern void _gdm_hw_set_mode (gdm_display* dp, unsigned short mode);

/* The _gdm_hw_xxx operations must be implemented in arch/gdm.h.  */
#include <arch/gdm.h>

/*@}*/

#ifdef __cplusplus
};
#endif
#endif
