/* display.h -- Graphic Display Manager
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_DISPLAY_H
#define _GEL_DISPLAY_H

#include <sys/param.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup gdm Graphic Display Manager

    The Graphic Display Manager is a library used to provide graphics
    operations and control a 128x64 liquid crystal display
    module.  It provides a graphical API to draw on the display and
    access to its bitmap.  All the public API is prefixed by \b gdm_ and
    all the internal API is prefixed by \b _gdm_.  The graphic display
    manager API is decomposed in several sets:

    <dl>
    <dt>\ref gdm_mgt</dt>
    <dd>
        This API must be used to control the display and the behavior
        of the graphic display module.
    </dd>

    <dt>\ref gdm_hw</dt>
    <dd>
        This API is provided by the board support package and gives
        raw access to the LCD hardware controller.  The display manager
        uses this API to refresh the screen and implement the high level
        drawing operations.  Read this section if you intend to port
        the library to your board.
    </dd>

    <dt>\ref gdm_draw</dt>
    <dd>
        This API is the most interesting as it allows to draw on the
        screen.  It provides operations to:
        <ul>
          <li> draw points, lines, segments, rectangles, polygons, circles,
          <li> fill rectangles,
          <li> paint characters from a font,
          <li> save and restore regions of the screen.
        </ul>
    </dd>

    <dt>\ref gdm_raw</dt>
    <dd>
        This API is internal to the graphic display manager.  It provides
        efficient low level drawing operations.  Its use is unsafe.
    </dd>
    </dl>

    The drawing operations are made in the display manager bitmap.
    This bitmap is in memory.  Once the drawing is finished, the bitmap
    must be synchronized with the LCD screen.  The display manager will
    do this by sending the data to the LCD controller.  Only the regions
    that have changed are really synchronized thus reducing the interactions
    with the LCD controller.  The synchronization process is made by
    the \b gdm_refresh which should be called after the drawing
    operations are finished.  The \b gdm_touch operation can be
    used to force a synchronization with the LCD controller.

    To use this library, you should:

    <ul>
    <li>Include <b>gdm/display.h</b> in your source files, like:
    <pre>
    #include &lt;gdm/display.h&gt;
    </pre>

    <li>Link your program with <b>libgdm</b>, for example by using:
    <pre>
    -lgdm
    </pre>
    during the link.
    </ul>

    Several examples are provided to help use and understand this library:
    <ul>
    <li>\ref gdm_hwtest
    <li>\ref gdm_lines
    <li>\ref gdm_fractals
    </ul>

 */
/*@{*/

/* Forward declarations.  */
struct gdm_display;

/*! Height of display in pixels.  */
#define GDM_HEIGHT (64)

/*! Width of display in pixels.  */
#define GDM_WIDTH  (128)

#define GDM_SWIDTH (GDM_WIDTH/2)
#define GDM_LCNT   (GDM_HEIGHT/8)
#define GDM_LSIZE  (GDM_WIDTH)
#define GDM_TSIZE  (GDM_LSIZE/8)

typedef unsigned char gdm_mask;

/*! Graphic Context Mode

    The gc mode defines the operation to use when drawing on the bitmap.  */
enum gdm_gc_mode
{
  /** Use a logical OR.  */
  GDM_PLOT_OR,

  GDM_PLOT_SET = GDM_PLOT_OR,

  /** Use a logical AND.  */
  GDM_PLOT_AND,

  GDM_PLOT_CLEAR = GDM_PLOT_AND,

  /** Use a logical XOR.  */
  GDM_PLOT_XOR
};

/*! Display Line Representation

    The display line represents a complete row of the LCD display.
    The LCD display is decomposed in 8 rows of 128 bytes each.
    Each row is indexed by a register (named X in KS0108 driver).
    The row spans on two KS0108 drivers: the left and right drivers.
    Graphically the row forms a rectangle of width 128 and height 8.

    The \c gdm_line contains the row bitmap, the row number and
    a small bitmask used by the refresh method.

    @see gdm_display, gdm_get_raw_line */
typedef struct gdm_line
{
  unsigned char data[GDM_LSIZE];
  gdm_mask      touched;
  unsigned short y;
} gdm_line;

/*! Clipping handler for a point.

    @param dp Display Manager
    @param x  X Coordinate
    @param y  Y Coordinate
    @return 0 if the point must not be drawn, != 0 if it can.  */
typedef int (* gdm_clip_point_handler) (struct gdm_display* dp,
                                        short x, short y);

/*! Display Manager Representation

    The display manager is represented by the \b gdm_display data structure.
    It defines the current graphical context for the drawing operation
    and contains the graphic bitmap.

    The display manager is intended to be allocated statically.
    It must be initialized once using \b gdm_initialize before any
    other operation.  For example:

    <pre>
      static gdm_display display;  / * Static or global!!! * /
      ...
       gdm_initialize (&display);
    </pre>

    After a sequence of drawing operation, the LCD display must be refreshed
    explicitly by calling \b gdm_refresh.  For example:

    <pre>
      ... / * Do some complex drawing * /
      gdm_refresh (&display);
    </pre>

    @see gdm_line, gdm_initialize, gdm_refresh  */
typedef struct gdm_display
{
  /*! Lines  */
  struct gdm_line* lines[GDM_LCNT];

  unsigned short hw0_cur_y;
  unsigned short hw1_cur_y;
  enum gdm_gc_mode plot_mode;
  gdm_mask mask;
  gdm_mask or_mask;
  gdm_mask xor_mask;
  gdm_mask and_mask;
  gdm_clip_point_handler clip_point;

  
  struct gdm_line image[GDM_LCNT];
} gdm_display;

/*! Get pointer to a row line representation.

    Given an Y coordinate in the range 0 .. GDM_HEIGHT, return the
    \b gdm_line that represent the rows containing the line.

    @param dp   Display Manager
    @param y    Y coordinate
    @return the gdm_line pointer or null if Y is not in the range
    @see gdm_initialize  */
extern gdm_line* gdm_get_raw_line (gdm_display* dp, short y);

extern inline gdm_line* gdm_get_raw_line (gdm_display* dp, short y)
{
  if (y < 0 || y >= GDM_HEIGHT)
    return 0;
  else
    return dp->lines[y >> 3];
}

/*@}*/

/*! @defgroup gdm_mgt Management and Control API

    The graphic display management API is used to control the behavior
    of the graphic display and of the drawing operations.

    The \b gdm_initialize is used to initialize the display manager
    data structure.  It must be called first to setup correctly the
    \b gdm_display data structure and initialize the hardware.

    The \b gdm_set_gc is used to control the graphical
    context used when drawing on the bitmap.

    The \b gdm_refresh and \b gdm_touch are used to synchronize the display
    manager bitmap with the LCD screen.    
*/
/*@{*/

/*! Turn on the display.  */
#define GDM_DISPLAY_ON    0x01

/*! Turn off the display.  */
#define GDM_DISPLAY_OFF   0x00

/*! Turn on the backlight LED.  */
#define GDM_BACKLIGHT_ON  0x02

/*! Turn off the backlight LED.  */
#define GDM_BACKLIGHT_OFF 0x00

/*! Initialize the graphic display manager.

    The graphic display manager must be initialized to setup the initial
    image and internal data structures used to represent the display.
    The graphical context is set to the \b GDM_PLOT_OR mode.  The LCD
    hardware is turned on.

    @param dp   Display manager data
    @see gdm_refresh, gdm_set_gc, gdm_set_mode, gdm_touch  */
extern void gdm_initialize (gdm_display* dp);

/*! Control various modes of graphic display manager and LCD hardware.

    This operation allows to control the operating mode of the manager
    and of the hardware.  The \b mode is composed of flags:

    <dl>
    <dt>GDM_DISPLAY_ON
    <dd>can be passed to turn ON the display

    <dt>GDM_DISPLAY_OFF
    <dd>can be used to switch OFF the display

    <dt>GDM_BACKLIGHT_ON
    <dd>can be used to enable the backlight LED.
    </dl>

    @param dp   Display Manager
    @param mode Control flags  */
extern void gdm_set_mode  (gdm_display* dp, int mode);

/*! Set the mode of graphic operations.

    The mode controls the logical operation used to perform the drawing
    operations.

    @param dp  Display Manager
    @param mode Logical operation to use  */
extern void gdm_set_gc  (gdm_display* dp, enum gdm_gc_mode mode);

/*! Refresh the graphic display.

    Update the graphic display by synchronizing the data image that we
    keep track in @b dp and sending the appropriate commands to the LCD
    controller.  The data image is scanned row by row and only the
    row parts that have changed are synchronized.  This ensures a minimal
    interaction to the LCD controller and thus speed up the drawing and
    refresh process.

    @param dp  Display Manager.
    @see gdm_touch  */
extern int gdm_refresh (gdm_display* dp);

/*! Touch the graphic display to force a synchronization of the region.

    The graphic region specified by @b x, @b y, @b width, @b height is
    touched to force a synchronization refresh with the LCD display.
    The region is clipped to the size of the display.  Touching a region
    has an effect on the behavior of \b gdm_refresh.  When refreshing
    occurs, only the touched regions are really updated on the LCD
    display.  The drawing operations take care of touching the minimal
    region that affect the drawing, hence optimizing any refresh.

    @param dp  Display Manager
    @param x   X corner
    @param y   Y corner
    @param width  Width of region
    @param height Height of region
    @see gdm_refresh  */
extern void gdm_touch (gdm_display* dp, short x, short y,
                       unsigned short width, unsigned short height);

/*@}*/

/*! @defgroup gdm_draw Drawing API

    The drawing API allows to draw lines, circles, paint characters
    on the screen.  The drawing operations are made in the display manager
    bitmap which is in memory.  Once the drawing is finished, the bitmap
    must be synchronized with the LCD screen (see gdm_refresh in
    \ref gdm_refresh).

    Each drawing operation is made using a graphical context.  The graphical
    context defines the logical operation which is used when drawing the
    item (see gdm_set_gc in \ref gdm_set_gc).  The following operations
    are supported:

    <dl>
    <dt>GDM_PLOT_OR
    <dd>
        In the \b OR mode, a logical or is used to write the item in the
        bitmap.  This mode can be used to force the item to appear on the
        screen.

    <dt>GDM_PLOT_XOR
    <dd>
        In the \b XOR mode, a logical xor is used thus providing an
        inversion of the dots corresponding to the item.  This mode is
        in general used to provide reverse video effects and can be used
        to show a cursor.

    <dt>GDM_PLOT_AND
    <dd>
        In the \b AND mode, a logical and is used.  It can be used to
        clear the screen.
    </dl>

    All the drawing operation implement a clipping mechanism to restrict
    the drawing to the LCD screen and optionally a region that you specify.
    The coordinates can be outside of the LCD screen and outside of the
    clipping region.  Drawing will take place only within the clipping region.
    For example, it is safe to do:
    <pre>
      static gdm_display display;
      ...
      /&nbsp;* Clear screen. *&nbsp;/
      gdm_set_gc (&display, GDM_PLOT_AND);
      gdm_fill_rectangle (&display, -100, -200, 1024, 2048);

      /&nbsp;* Draw a line crossing the screen. *&nbsp;/
      gdm_set_gc (&display, GDM_PLOT_OR);
      gdm_draw_line (&display, -100, -200, 1024, 2048);
    </pre>
*/
/*@{*/

/*! Representation of a point.  */
typedef struct gdm_point
{
  short x;
  short y;
} gdm_point;

/*! Draw a point on the graphic display.

    The point at @b x, @b y is plotted using the current color and
    graphic operation.  The point is clipped to the current display
    clipping region.  The point is plotted in the bitmap only and a display
    refresh is necessary to make the change visible.

    @param dp  Display manager
    @param x   X coordinate
    @param y   Y coordinate
    @see gdm_draw_points, gdm_refresh  */
extern void gdm_draw_point (gdm_display* dp, short x, short y);

/*! Draw a list of points on the graphic display.

    The points specified in the table @b pts are plotted using the
    current color and graphic operation.  The points are clipped to
    the current display clipping region.  The point is plotted in the
    bitmap only and a display refresh is necessary to make the change visible.

    @param dp  Display manager
    @param pts Table of points to display
    @param npoints Number of points to print
    @see gdm_draw_point, gdm_refresh  */
extern void gdm_draw_points (gdm_display* dp, gdm_point* pts,
                             unsigned short npoints);

/*! Draw a line between two points.

    Draw a line between @b x1, @b y1 and @b x2, @b y2.  The line is clipped
    to the display window and using the current clipping region.  The points
    of the line are drawn using the current graphical context (or, and, xor).

    @param dp   Display Manager
    @param x1   X coordinate of first point
    @param y1   Y coordinate of first point
    @param x2   X coordinate of second point
    @param y2   Y coordinate of second point
    @see gdm_draw_lines, gdm_refresh  */
extern void gdm_draw_line (gdm_display* dp, short x1, short y1,
                           short x2, short y2);

/*! Draw a continuous line.  */
#define GDM_LINE    0

/*! Draw a continuous closed line (polygon).  */
#define GDM_POLYGON 1

/*! Draw several segments.  */
#define GDM_SEGMENT 2

/*! Draw a continuous line, some segments or a polygon.

    Draw a continuous line, a set of segments or a polygon based on
    the list of points specified in @b pts.  The @b mode parameter
    controls the drawing mode:

    GDM_LINE     A continuous line is drawn between each point of the list.
    GDM_POLYGON  The continous line is closed to form a polygon
    GDM_SEGMENT  The list of points represents couples of points to
                 define one or several segments.  @b npoints / 2 segments
                 are drawn.

    @param dp   Display Manager
    @param pts  Table of points to display
    @param npoints Number of points in the table
    @param mode    Mode to display the line
    @see gdm_draw_line, gdm_refresh  */
extern void gdm_draw_lines (gdm_display* dp, gdm_point* pts,
                            unsigned short npoints, short mode);

extern void gdm_draw_rectangle (gdm_display* dp, short x, short y,
                                unsigned short width, unsigned short height);


extern void gdm_draw_circle (gdm_display* dp, short x0, short y0, short r);

/*! Fill a rectangle with current gc mode.

    The rectangle defined by @b x, @b y, @b width, @b height is filled
    with the current graphical context.  The rectangle is clipped to the
    display and to the optional clipping region.

    @param dp  Display Manager
    @param x   X coordinate
    @param y   Y coordinate
    @param width Width of rectangle
    @param height Height of rectangle
    @see gdm_refresh  */
extern void gdm_fill_rectangle (gdm_display* dp, short x, short y,
                                unsigned short width, unsigned short height);
/*@}*/

#ifdef __cplusplus
};
#endif
#endif
