/* display-raw.h -- Graphics Display Manager
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_DISPLAY_RAW_H
#define _GEL_DISPLAY_RAW_H

#include <sys/param.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*! @defgroup gdm_raw Low level operation of graphic display manager


 */
/*@{*/

extern const gdm_mask _gdm_bitmask[];

extern const gdm_mask _gdm_start_mask[];

extern const gdm_mask _gdm_end_mask[];

extern const gdm_mask _gdm_ibitmask[];


extern void _gdm_plot (struct gdm_display* dp, unsigned short x,
                       unsigned short y);

extern void _gdm_fill_rectangle (struct gdm_display* dp, unsigned short x,
                                 unsigned short y, unsigned short width,
                                 unsigned short height);

extern void _gdm_touch_line (gdm_line* l, unsigned short x);

extern inline void _gdm_touch_line (gdm_line* l, unsigned short x)
{
  l->touched |= _gdm_bitmask[x >> 4];
}

extern void _gdm_do_refresh (struct gdm_display* dp, struct gdm_line* l,
                             unsigned short x_first, unsigned short x_last);

extern int _gdm_refresh_line (gdm_display* dp, gdm_line* l, gdm_line* screen);


extern gdm_line* _gdm_get_raw_line (gdm_display* dp, unsigned short y);

extern inline gdm_line* _gdm_get_raw_line (gdm_display* dp, unsigned short y)
{
  return dp->lines[y >> 3];
}

/*! Internal Raw Plot Operation.

    Performs the GDM_PLOT_OR, GDM_PLOT_AND, GDM_PLOT_XOR with the given mask.
    The data must be in memory and a pointer to it is passed to @b data.
    The @b mask contains the value to apply with the operation to the data.

    @param dp   Display Manager
    @param mask Mask to apply with the operation
    @param data Data to update.  */
extern void _gdm_raw_plot (gdm_display* dp, unsigned char* data,
                           unsigned char mask);

extern void inline _gdm_raw_plot (gdm_display* dp, unsigned char* data,
                                  unsigned char mask)
{
  /* The asm instruction performs:

     data[0] = ((data[0] | mask) & or_mode)
             + ((data[0] ^ mask) & xor_mode)
             + ((data[0] & ~mask) & and_mode)

     It allows to support all the graphical context modes without
     any test.  The asm gets the display manager pointer and access
     to the 'mask' and 'xxx_mode' within it.  The offsets of these
     data members are passed as a constant to the asm (see @b offsetof).  */
  dp->mask = mask;
  __asm__ __volatile__ ("ldab   0,%0        ; Get data[0]\n"
                        "\torab %a2,%1      ; Or operation\n"
                        "\tandb %a3,%1      ; restrict to or_mode\n"
                        "\tldaa 0,%0\n"
                        "\teora %a2,%1      ; Xor operation\n"
                        "\tanda %a4,%1      ; restrict to xor_mode\n"
                        "\taba              ; Merge xor and or results\n"
                        "\tldab %a2,%1\n"
                        "\tcomb\n"
                        "\tandb 0,%0        ; And operation\n"
                        "\tandb %a5,%1\n"
                        "\taba              ; Merge with others\n"
                        "\tstaa 0,%0        ; Save in data[0]"
                        : : "A"(data), "A"(dp),
                        "i"(offsetof(gdm_display, mask)),
                        "i"(offsetof(gdm_display, or_mask)),
                        "i"(offsetof(gdm_display, xor_mask)),
                        "i"(offsetof(gdm_display, and_mask))
                        : "d");
}


#ifdef __cplusplus
};
#endif
#endif
