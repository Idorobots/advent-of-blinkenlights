/* gdm.h -- Graphics Dot Matrix Display
   Copyright 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _M68HC11_ARCH_CME11_GDM_H
#define _M68HC11_ARCH_CME11_GDM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/ports.h>

/*! @defgroup gdm_cme11_hw  CME11 LCD Controller

    The GDM12864 display is connected to the CME11 LCD port and the
    CS1 and CS2 connections are tied to port A4 and port A5 respectively.
    For CME11, the LCD port is mapped in memory at 0xB5F0 for the command
    and 0xB5F1 for the data.  These addresses are defined in \b memory.x
    of CME11.  They are accessed here through the global variables
    \b _gdm_lcd_cmd and \b _gdm_lcd_data.

*/
extern volatile unsigned char _gdm_lcd_cmd;
extern volatile unsigned char _gdm_lcd_data;

#define M6811_PA4 (1 << 4)
#define M6811_PA5 (1 << 5)

/*! Set the active side of the LCD controller.

    This function is board specific.  The 128x64 display has two drivers.
    The left driver is selected when @side is 0.  The right driver is
    selected when @side is 1.

    @param dp   Display Manager
    @param side Left or right side of the LCD display  */
extern inline void _gdm_hw_set_side (gdm_display* dp, unsigned short side)
{
  _io_ports[M6811_PORTA] &= ~(M6811_PA5 | M6811_PA4);
  if (side)
    _io_ports[M6811_PORTA] |= M6811_PA4;
  else
    _io_ports[M6811_PORTA] |= M6811_PA5;
}

/*! Set the LCD graphics hardware Y register.

    This function is board specific.  It must set the Y register of the
    KS0108 driver to the value @b y.  The Y register is assumed to be
    incremented after each data write.  The value passed is guarranteed to
    be in the range 0 .. GDM_HEIGHT that is 0 .. 63.

    @param dp   Display Manager
    @param y    Y register value (0..63)  */
extern inline void _gdm_hw_set_y (gdm_display* dp, unsigned short y)
{
  /* Set the LCD Y register.  'y' is guarranteed to be <= 63.  */
  _gdm_lcd_cmd = 0x40 | y;
}

/*! Set the LCD graphics hardware X register.

    This function is board specific.  It must set the X register of the
    KS0108 driver to the value @b x.  The value passed is guarranteed to
    be in the range 0 .. GDM_WIDTH / 2 * 8 that is 0 .. 7.

    @param dp   Display Manager
    @param x    X register value (0..7)  */
extern inline void _gdm_hw_set_x (gdm_display* dp, unsigned short x)
{
  /* Set the LCD X register.  'x' is guarranteed to be <= 7.  */
  _gdm_lcd_cmd = 0xB8 | x;
}

/*! Send data to the LCD graphics DDRAM.

    This function is board specific.  It must write the data value to
    the LCD graphics DDRAM.  The data is written at the current X, Y
    position set by @b _gdm_hw_set_x and @b _gdm_hw_set_y.  The Y register
    is assumed to be incremented after each data write.

    @param dp   Display Manager
    @param data Data byte to write  */
extern inline void _gdm_hw_set_data (gdm_display* dp, unsigned char data)
{
  _gdm_lcd_data = data;
}

/*! Setup the start line of the display data.

    This function is board specific.  It must set the start line of the
    KS0108 driver to the value specified in @b line.

    @param dp   Display Manager
    @param line Start line to display on top of LCD side (0..63)  */
extern inline void _gdm_hw_set_line (gdm_display* dp, unsigned short line)
{
  /* Set the LCD start page.  'line' is guarranteed to be <= 63.  */
  _gdm_lcd_cmd = 0xC0 | line;
}

/*! Setup the display mode and backlight.

    This function is board specific.  The @b mode parameter controls some
    modes provided by the graphics display:

    GDM_DISPLAY_ON   When this flag is set, the graphics LCD display is on.
    GDM_BACKLIGHT_ON When this flag is set the backlight LED must be switched
                     on.

    @param dp   Display Manager
    @param mode Control mode  */
extern inline void _gdm_hw_set_mode (gdm_display* dp, unsigned short mode)
{
  if (mode & GDM_DISPLAY_ON)
    _gdm_lcd_cmd = 0x3F;
  else
    _gdm_lcd_cmd = 0x3E;
}

/*@}*/

#ifdef __cplusplus
};
#endif
#endif
