/* exit.h - MIT 6270 board definitions
   Copyright (C) 2002 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@nerim.fr)	

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _M68HC11_ARCH_6270_EXIT_H
#define _M68HC11_ARCH_6270_EXIT_H

extern void _exit (short status) __attribute__((noreturn));

/* For the simulator, the wai stops everything and exits with the
   error code stored in register d.

   For a real 68HC11, enable interrupts and wait forever.  */
extern inline void
_exit (short status)
{
  /* Use 'd' constraint to force the status to be in the D
     register before execution of the asm.  */
  while (1)
    {
      __asm__ __volatile__ ("cli\n"
                            "wai" : : "d"(status));
    }
}

#endif
