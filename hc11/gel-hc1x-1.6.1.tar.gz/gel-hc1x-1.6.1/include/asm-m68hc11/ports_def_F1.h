/* m68hc11/ports_def.h -- Definition of 68HC11 ports
   Copyright 1999, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)
   Adaptions to the 68HC11F1 target by Ingo Beckmann (ib@nnTec.de)

This file is part of GDB, GAS, and the GNU binutils.

GDB, GAS, and the GNU binutils are free software; you can redistribute
them and/or modify them under the terms of the GNU General Public
License as published by the Free Software Foundation; either version
1, or (at your option) any later version.

GDB, GAS, and the GNU binutils are distributed in the hope that they
will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file; see the file COPYING.  If not, write to the Free
Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#ifndef _M68HC11_PORTS_DEF_F1_H
#define _M68HC11_PORTS_DEF_F1_H

/* 68HC11 register address offsets (range 0..0x5F or 0..95).
   The absolute address of the I/O register depends on the setting
   of the M6811_INIT register.  At init time, the I/O registers are
   mapped at 0x1000.  Address of registers is then:

   0x1000 + M6811_xxx
*/
#define M6811_PORTA     0x00	/* Port A register */
#define M6811_DDRA	0x01	/* Data direction register for port A */
#define M6811_PORTG	0x02	/* Port G register */
#define M6811_DDRG	0x03	/* Data direction register for port G */
#define M6811_PORTB	0x04	/* Port B register */
#define M6811_PORTF	0x05	/* Port F register */
#define M6811_PORTC	0x06	/* Port C register */
#define M6811_DDRC	0x07	/* Data direction register for port C */
#define M6811_PORTD	0x08	/* Port D register */
#define M6811_DDRD	0x09	/* Data direction register for port D */
#define M6811_PORTE	0x0A	/* Port E input register */
#define M6811_CFORC	0x0B	/* Compare Force Register */
#define M6811_OC1M	0x0C	/* OC1 Action Mask register */
#define M6811_OC1D	0x0D	/* OC1 Action Data register */
#define M6811_TCNT	0x0E	/* Timer Counter Register */
#define M6811_TCNT_H	0x0E	/* "	 "	 " High part */
#define M6811_TCNT_L	0x0F	/* "	 "	 " Low part */
#define M6811_TIC1	0x10	/* Input capture 1 register */
#define M6811_TIC1_H	0x10	/* "	 "	 " High part */
#define M6811_TIC1_L	0x11	/* "	 "	 " Low part */
#define M6811_TIC2	0x12	/* Input capture 2 register */
#define M6811_TIC2_H	0x12	/* "	 "	 " High part */
#define M6811_TIC2_L	0x13	/* "	 "	 " Low part */
#define M6811_TIC3	0x14	/* Input capture 3 register */
#define M6811_TIC3_H	0x14	/* "	 "	 " High part */
#define M6811_TIC3_L	0x15	/* "	 "	 " Low part */
#define M6811_TOC1	0x16	/* Output Compare 1 register */
#define M6811_TOC1_H	0x16	/* "	 "	 " High part */
#define M6811_TOC1_L	0x17	/* "	 "	 " Low part */
#define M6811_TOC2	0x18	/* Output Compare 2 register */
#define M6811_TOC2_H	0x18	/* "	 "	 " High part */
#define M6811_TOC2_L	0x19	/* "	 "	 " Low part */
#define M6811_TOC3	0x1A	/* Output Compare 3 register */
#define M6811_TOC3_H	0x1A	/* "	 "	 " High part */
#define M6811_TOC3_L	0x1B	/* "	 "	 " Low part */
#define M6811_TOC4	0x1C	/* Output Compare 4 register */
#define M6811_TOC4_H	0x1C	/* "	 "	 " High part */
#define M6811_TOC4_L	0x1D	/* "	 "	 " Low part */
#define M6811_TOC5	0x1E	/* Output Compare 5 register */
#define M6811_TOC5_H	0x1E	/* "	 "	 " High part */
#define M6811_TOC5_L	0x1F	/* "	 "	 " Low part */
#define M6811_TCTL1	0x20	/* Timer Control register 1 */
#define M6811_TCTL2	0x21	/* Timer Control register 2 */
#define M6811_TMSK1	0x22	/* Timer Interrupt Mask Register 1 */
#define M6811_TFLG1	0x23	/* Timer Interrupt Flag Register 1 */
#define M6811_TMSK2	0x24	/* Timer Interrupt Mask Register 2 */
#define M6811_TFLG2	0x25	/* Timer Interrupt Flag Register 2 */
#define M6811_PACTL	0x26	/* Pulse Accumulator Control Register */
#define M6811_PACNT	0x27	/* Pulse Accumulator Count Register */
#define M6811_SPCR	0x28	/* SPI Control register */
#define M6811_SPSR	0x29	/* SPI Status register */
#define M6811_SPDR	0x2A	/* SPI Data register */
#define M6811_BAUD	0x2B	/* SCI Baud register */
#define M6811_SCCR1	0x2C	/* SCI Control register 1 */
#define M6811_SCCR2	0x2D	/* SCI Control register 2 */
#define M6811_SCSR	0x2E	/* SCI Status register */
#define M6811_SCDR	0x2F	/* SCI Data (Read => RDR, Write => TDR) */
#define M6811_ADCTL	0x30	/* A/D Control register */
#define M6811_ADR1	0x31	/* A/D, Analog Result register 1 */
#define M6811_ADR2	0x32	/* A/D, Analog Result register 2 */
#define M6811_ADR3	0x33	/* A/D, Analog Result register 3 */
#define M6811_ADR4	0x34	/* A/D, Analog Result register 4 */
#define M6811_BPROT	0x35    /* Block Protect for Config and EPROM */
#define M6811__RES36	0x36
#define M6811__RES37	0x37
#define M6811_OPT2	0x38    /* System Configuration Options 2 */
#define M6811_OPTION	0x39	/* System Configuration Options */
#define M6811_COPRST	0x3A	/* Arm/Reset COP Timer Circuitry */
#define M6811_PPROG	0x3B	/* EEPROM Programming Control Register */
#define M6811_HPRIO	0x3C	/* Highest priority I-Bit int and misc */
#define M6811_INIT	0x3D	/* Ram and I/O mapping register */
#define M6811_TEST1	0x3E	/* Factory test control register */
#define M6811_CONFIG	0x3F    /* COP, ROM and EEPROM enables */
#define M6811__RES40	0x40
#define M6811__RES41	0x41
#define M6811__RES42	0x42
#define M6811__RES43	0x43
#define M6811__RES44	0x44
#define M6811__RES45	0x45
#define M6811__RES46	0x46
#define M6811__RES47	0x47
#define M6811__RES48	0x48
#define M6811__RES49	0x49
#define M6811__RES4A	0x4A
#define M6811__RES4B	0x4B
#define M6811__RES4C	0x4C
#define M6811__RES4D	0x4D
#define M6811__RES4E	0x4E
#define M6811__RES4F	0x4F
#define M6811__RES50	0x50
#define M6811__RES51	0x51
#define M6811__RES52	0x52
#define M6811__RES53	0x53
#define M6811__RES54	0x54
#define M6811__RES55	0x55
#define M6811__RES56	0x56
#define M6811__RES57	0x57
#define M6811__RES58	0x58
#define M6811__RES59	0x59
#define M6811__RES5A	0x5A
#define M6811__RES5B	0x5B
#define M6811_CSSTRH    0x5C    /* Chip-Select Clock Stretch */
#define M6811_CSCTL     0x5D    /* Chip-Select Control */
#define M6811_CSGADR    0x5E    /* General-Purpose Chip-Select Address Register */
#define M6811_CSGSIZ    0x5F    /* Gerenal-Purpose Chip-Select Size Register */

/* Flags of the CONFIG register (in EEPROM).  */
#define M6811_EE3       0x80    /* EEPROM Map Position Bits */
#define M6811_EE2       0x40    /* EEPROM Map Position Bits */
#define M6811_EE1       0x20    /* EEPROM Map Position Bits */
#define M6811_EE0       0x10    /* EEPROM Map Position Bits */
#define M6811_NOCOP     0x04    /* COP system disable */
#define M6811_EEON      0x01    /* Enable on-chip eeprom */

/* Flags of the PPROG register.  */
#define M6811_ODD       0x80    /* Program Odd Rows (TEST) */
#define M6811_EVEN      0x40    /* Program Even Rows (TEST) */ 
#define M6811_BYTE	0x10	/* Byte mode */
#define M6811_ROW       0x08	/* Row mode */
#define M6811_ERASE	0x04	/* Erase mode select (1 = erase, 0 = read) */
#define M6811_EELAT     0x02	/* EEPROM Latch Control */
#define M6811_EEPGM     0x01	/* EEPROM Programming Voltage Enable */

/* Flags of the BPROT register.  */
#define M6811_PTCON	0x10	/* Protect for CONFIG */
#define M6811_BPRT3     0x08	/* Block Protect Bits for EEPROM $xEE0-$xFFF 288 Bytes */
#define M6811_BPRT2	0x04    /* $xE60-$xEDF 128 Bytes */
#define M6811_BPRT1     0x02    /* $xE20-$xE5F 64 Bytes */
#define M6811_BPRT0     0x01    /* $xE00-$xD9F 32 Bytes */

/* Flags of the SCCR1 register.  */
#define M6811_R8	0x80	/* Receive Data bit 8 */
#define M6811_T8	0x40	/* Transmit data bit 8 */
#define M6811__SCCR1_5  0x20	/* Unused */
#define M6811_M		0x10	/* SCI Character length */
#define M6811_WAKE	0x08	/* Wake up method select (0=idle, 1=addr mark) */

/* Flags of the SCCR2 register.  */
#define M6811_TIE	0x80	/* Transmit Interrupt enable */
#define M6811_TCIE	0x40	/* Transmit Complete Interrupt Enable */
#define M6811_RIE	0x20	/* Receive Interrupt Enable */
#define M6811_ILIE	0x10	/* Idle Line Interrupt Enable */
#define M6811_TE	0x08	/* Transmit Enable */
#define M6811_RE	0x04	/* Receive Enable */
#define M6811_RWU	0x02	/* Receiver Wake Up */
#define M6811_SBK	0x01	/* Send Break */

/* Flags of the SCSR register.  */
#define M6811_TDRE	0x80	/* Transmit Data Register Empty */
#define M6811_TC	0x40	/* Transmit Complete */
#define M6811_RDRF	0x20	/* Receive Data Register Full */
#define M6811_IDLE	0x10	/* Idle Line Detect */
#define M6811_OR	0x08	/* Overrun Error */
#define M6811_NF	0x04	/* Noise Flag */
#define M6811_FE	0x02	/* Framing Error */
#define M6811__SCSR_0	0x01	/* Unused */

/* Flags of the BAUD register.  */
#define M6811_TCLR	0x80	/* Clear Baud Rate (TEST mode) */
#define M6811__BAUD_6	0x40	/* Not used */
#define M6811_SCP1	0x20	/* SCI Baud rate prescaler select */
#define M6811_SCP0	0x10
#define M6811_RCKB	0x08	/* Baud Rate Clock Check (TEST mode) */
#define M6811_SCR2	0x04	/* SCI Baud rate select */
#define M6811_SCR1	0x02
#define M6811_SCR0	0x01

#define M6811_BAUD_DIV_1	(0)
#define M6811_BAUD_DIV_3	(M6811_SCP0)
#define M6811_BAUD_DIV_4	(M6811_SCP1)
#define M6811_BAUD_DIV_13	(M6811_SCP1|M6811_SCP0)

/* Flags of the SPCR register.  */
#define M6811_SPIE	0x80	/* Serial Peripheral Interrupt Enable */
#define M6811_SPE	0x40	/* Serial Peripheral System Enable */
#define M6811_DWOM	0x20	/* Port D Wire-OR mode option */
#define M6811_MSTR	0x10	/* Master Mode Select */
#define M6811_CPOL	0x08	/* Clock Polarity */
#define M6811_CPHA	0x04	/* Clock Phase */
#define M6811_SPR1	0x02	/* SPI Clock Rate Select */
#define M6811_SPR0	0x01

/* Flags of the SPSR register.  */
#define M6811_SPIF	0x80	/* SPI Transfer Complete flag */
#define M6811_WCOL	0x40	/* Write Collision */
#define M6811_MODF	0x10	/* Mode Fault */

/* Flags of the ADCTL register.  */
#define M6811_CCF	0x80	/* Conversions Complete Flag */
#define M6811_SCAN	0x20	/* Continuous Scan Control */
#define M6811_MULT	0x10	/* Multiple Channel/Single Channel Control */
#define M6811_CD	0x08	/* Channel Select D */
#define M6811_CC	0x04	/*                C */
#define M6811_CB	0x02	/*                B */
#define M6811_CA	0x01	/*                A */

/* Flags of the CFORC register.  */
#define M6811_FOC1	0x80	/* Force Output Compare 1 */
#define M6811_FOC2	0x40	/*			2 */
#define M6811_FOC3	0x20	/*			3 */
#define M6811_FOC4	0x10	/*			4 */
#define M6811_FOC5	0x08	/*			5 */

/* Flags of the OC1M register.  */
#define M6811_OC1M7	0x80	/* Output Compare 7 */
#define M6811_OC1M6	0x40	/*                6 */
#define M6811_OC1M5	0x20	/*                5 */
#define M6811_OC1M4	0x10	/*                4 */
#define M6811_OC1M3	0x08	/*                3 */

/* Flags of the OC1D register.  */
#define M6811_OC1D7	0x80
#define M6811_OC1D6	0x40
#define M6811_OC1D5	0x20
#define M6811_OC1D4	0x10
#define M6811_OC1D3	0x08

/* Flags of the TCTL1 register.  */
#define M6811_OM2	0x80	/* Output Mode 2 */
#define M6811_OL2	0x40	/* Output Level 2 */
#define M6811_OM3	0x20
#define M6811_OL3	0x10
#define M6811_OM4	0x08
#define M6811_OL4	0x04
#define M6811_OM5	0x02
#define M6811_OL5	0x01

/* Flags of the TCTL2 register.  */
#define M6811_EDG4B	0x80	/* Input Edge Capture Control 4 */
#define M6811_EDG4A	0x40
#define M6811_EDG1B	0x20	/* Input 1 */
#define M6811_EDG1A	0x10
#define M6811_EDG2B	0x08	/* Input 2 */
#define M6811_EDG2A	0x04
#define M6811_EDG3B	0x02	/* Input 3 */
#define M6811_EDG3A	0x01

/* Flags of the TMSK1 register.  */
#define M6811_OC1I	0x80	/* Output Compare 1 Interrupt */
#define M6811_OC2I	0x40	/*		  2	      */
#define M6811_OC3I	0x20	/*		  3	      */
#define M6811_OC4I	0x10	/*		  4	      */
#define M6811_OC5I	0x08	/*		  5	      */
#define M6811_IC1I	0x04	/* Input Capture  1 Interrupt */
#define M6811_IC2I	0x02	/*		  2	      */
#define M6811_IC3I	0x01	/*		  3	      */

/* Flags of the TFLG1 register.  */
#define M6811_OC1F	0x80	/* Output Compare 1 Flag */
#define M6811_OC2F	0x40	/*		  2	 */
#define M6811_OC3F	0x20	/*		  3	 */
#define M6811_OC4F	0x10	/*		  4	 */
#define M6811_OC5F	0x08	/*		  5	 */
#define M6811_IC1F	0x04	/* Input Capture  1 Flag */
#define M6811_IC2F	0x02	/*		  2	 */
#define M6811_IC3F	0x01	/*		  3	 */

/* Flags of Timer Interrupt Mask Register 2 (TMSK2).  */
#define M6811_TOI       0x80    /* Timer Overflow Interrupt Enable */
#define M6811_RTII      0x40    /* RTI Interrupt Enable */
#define M6811_PAOVI     0x20    /* Pulse Accumulator Overflow Interrupt En. */
#define M6811_PAII      0x10    /* Pulse Accumulator Interrupt Enable */
#define M6811_PR1       0x02    /* Timer prescaler */
#define M6811_PR0       0x01    /* Timer prescaler */
#define M6811_TPR_1     0x00    /* " " prescale div 1 */
#define M6811_TPR_4     0x01    /* " " prescale div 4 */
#define M6811_TPR_8     0x02    /* " " prescale div 8 */
#define M6811_TPR_16    0x03    /* " " prescale div 16 */

/* Flags of Timer Interrupt Flag Register 2 (M6811_TFLG2).  */
#define M6811_TOF       0x80    /* Timer overflow bit */
#define M6811_RTIF      0x40    /* Read time interrupt flag */
#define M6811_PAOVF     0x20    /* Pulse accumulator overflow Interrupt flag */
#define M6811_PAIF      0x10    /* Pulse accumulator Input Edge " " " */

/* Flags of Pulse Accumulator Control Register (PACTL).  */
#define M6811_PAEN      0x40    /* Pulse accumulator system enable */
#define M6811_PAMOD     0x20    /* Pulse accumulator mode */
#define M6811_PEDGE     0x10    /* Pulse accumulator edge control */
#define M6811_I4O5      0x04    /* Configure TI4/O5 */
#define M6811_RTR1      0x02    /* RTI Interrupt rates select */
#define M6811_RTR0      0x01    /* " " " " */

/* Flags of the Options register.  */
#define M6811_ADPU      0x80    /* A/D Powerup */
#define M6811_CSEL      0x40    /* A/D/EE Charge pump clock source select */
#define M6811_IRQE      0x20    /* IRQ Edge/Level sensitive */
#define M6811_DLY       0x10    /* Stop exit turn on delay */
#define M6811_CME       0x08    /* Clock Monitor enable */
#define M6811_FCME      0x04    /* Force Clock Monitor enable */
#define M6811_CR1       0x02    /* COP timer rate select */
#define M6811_CR0       0x01    /* COP timer rate select */

/* Flags of the OPT2 register */
#define M6811_GWOM      0x80    /* Port G Wired-Or Mode */
#define M6811_CWOM      0x40    /* Port C Wired-Or Mode */
#define M6811_CLK4X     0x20    /* 4x Clock Output Enable  */

/* Flags of the HPRIO register.  */
#define M6811_RBOOT	0x80	/* Read Bootstrap ROM */
#define M6811_SMOD	0x40	/* Special Mode */
#define M6811_MDA	0x20	/* Mode Select A */
#define M6811_IRV	0x10	/* Internal Read Visibility */
#define M6811_PSEL3	0x08	/* Priority Select */
#define M6811_PSEL2	0x04
#define M6811_PSEL1	0x02
#define M6811_PSEL0	0x01

/* Flags for the CSSTRH register */
#define M6811_IO1SA	0x80	/* CSIO 1 Clock Delay */
#define M6811_IO1SB	0x40
#define M6811_IO2SA	0x20	/* CSIO 2 Clock Delay */
#define M6811_IO2SB	0x10
#define M6811_GSTHA	0x08	/* General-Purpose Chip-Select Clock Delay */
#define M6811_GSTHB	0x04    
#define M6811_PSTHA	0x02    /* Program Chip-Select Clock Delay */
#define M6811_PSTHB	0x01

/* Flags for the CSCTL register */
#define M6811_IO1EN	0x80	/* I/O Chip-Select 1 Bit Enable */
#define M6811_IO1PL	0x40	/* I/O Chip-Select 1 Bit Polarity */
#define M6811_IO2EN	0x20	/* I/O Chip-Select 2 Bit Enable */
#define M6811_IO2PL	0x10	/* I/O Chip-Select 2 Bit Polarity */
#define M6811_GCSPR	0x08	/* General Purpose Chip-Select Priority */
#define M6811_PCSEN	0x04    /* Program Chip-Select Enable */
#define M6811_PSIZA	0x02    /* Program Chip-Select Size */
#define M6811_PSIZB	0x01

/* Flags for the CSGADR register */
#define M6811_GA15	0x80	/* GA[15:10] - General_purpose Chip-Select Starting Address Bits */
#define M6811_GA14	0x40
#define M6811_GA13	0x20
#define M6811_GA12	0x10
#define M6811_GA11	0x08
#define M6811_GA10	0x04

/* Flags for the CSGSIZ register */
#define M6811_IO1AV	0x80	/* I/O Chip-Select 1 Address Valid */
#define M6811_IO2AV	0x40	/* I/O Chip-Select 2 Address Valid */
#define M6811_GNPOL	0x10	/* General-Purpose Chip-Select Polarity */
#define M6811_GAVLD	0x08	/* General-Purpose Chip-Select Addres Valid */
#define M6811_GSIZA	0x04    /* General-Purpose Chip-Select Size */
#define M6811_GSIZB	0x02
#define M6811_GSIZC	0x01


#define M6811_IO_SIZE  (0x60)

/* Deprecated defines (must use M6811_TCNT)  */
#define M6811_TCTN	0x0E	/* Timer Counter Register */
#define M6811_TCTN_H	0x0E	/* "	 "	 " High part */
#define M6811_TCTN_L	0x0F	/* "	 "	 " Low part */

#endif /* _M68HC11_PORTS_DEF_F1_H */
