/* persist.h -- Persistent Object Management
   Copyright 2001 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_PERSIST_H
#define _GEL_PERSIST_H

#include <sys/param.h>
#include <stddef.h>
#include <string.h>

#define PERSIST_INVALID_ID (persist_id_t) (0xffff)
#define PERSIST_FREE_SLOT  (persist_id_t) (0x7fff)

typedef unsigned short persist_id_t;

/*! Persistent store class.

  The <b>persistent_store</b> class is the root of persistent objects.
  The persistent objects are saved in a transparent manner in eeprom.
  When the program starts, objects are initialized with the persistent
  store.

  The <b>persistent_store</b> class is not intended to be used as is.
  Use <b>persistent_object</b> or <b>persistent</b> classes instead.

  @see persistent_object, persistent
 */
class persistent_store
{
protected:

  //! Persistent area description.
  //
  // The persistent area starts with a persistent store id and the size
  // of that store.  The store id is used to retrieve the store when
  // we start.  The size is used to be able to walk the persistent areas,
  // manage their allocation/deallocation.  */
  typedef struct
  {
    persist_id_t id;
    unsigned char size;
    unsigned char data[0];
  } persistent_area_t;

  //! Find a persistent store given its id.
  //
  // Returns a pointer to the persistent area or NULL if not found.
  static persistent_area_t *find_store (persist_id_t id);

  //! Allocate a persistent area for an store.
  //
  // Returns a pointer to the persistent area allocated for the new store.
  static persistent_area_t *allocate_store (persist_id_t id, size_t len);

  // Start in Eprom of the persistent memory.
  static persistent_area_t start_area asm ("0xb000");

  // End of the persistent memory.
  static persistent_area_t end_area asm ("0xb200");

  // The persistent area used by that store (saved copy).
  persistent_area_t *area;

  //! Save the object.
  //
  // If the runtime copy of the object is modified, update its
  // copy in persistent memory.
  void
  save (const unsigned char *object);

  //! Create or retrieve a persistent store.
  //
  // Retrieve the persistent store identified by `id', initialize
  // the runtime copy `object' with it.  If the persistent storage
  // does not exist for that store, allocate one.
  //
  // Returns 1 when the persistent store was created, 0 otherwise.
  int
  create (persist_id_t id, void *object, size_t len);

  inline
  persistent_store ()
    {}

private:
  // Copy constructor is forbidden.
  inline
  persistent_store (const persistent_store&)
    {
      ;
    }

  // Copy of persistent store objects is forbidden.
  inline persistent_store&
  operator = (const persistent_store&)
    {
      return *this;
    }

protected:
  //! Declare a persistent object with external runtime storage.
  inline
  persistent_store (persist_id_t id, void *object, size_t len)
    {
      create (id, object, len);
    }

public:
  //! Revoke the persistent store.
  //
  // The persistent store is freed and is no longer used to save
  // the object.
  void
  revoke ();
};


/*! Persistent object class.

  
 */
class persistent_object : private persistent_store
{
protected:

  // First persistent object in the list.
  static persistent_object *first;

  // Next persistent object in the list.
  persistent_object *next;

  // Pointer to the object in memory (runtime copy).
  unsigned char *object;

  inline
  persistent_object ()
    {}

private:
  // Copy constructor is forbidden.
  inline
  persistent_object (const persistent_object&)
    {
      ;
    }

  // Copy of persistent object is forbidden.
  inline persistent_object&
  operator = (const persistent_object&)
    {
      return *this;
    }
public:

  //! Declare a persistent object with external runtime storage.
  inline
  persistent_object (persist_id_t id, void *object, size_t len)
    : persistent_store (id, object, len)
    {
      next = first;
      first = this;
    }

  //! Save all persistent object.
  //
  // Persistent objects with external storage are not managed completely
  // by `persistent_object' class.  We are not aware of when the object
  // is modified.  For these objects, it is necessary to call `save_all'
  // to synchronize the runtime value with the persistent storage.
  // Only the bytes that have changed are updated.
  static void
  save_all ();
};



//! Persistent type.
//
// This class is suitable for a transparent persistent object.
// When the object is modified, the persistent storage is also updated.
// This is implemented by overriding the `=' operator and the `(type)'
// type conversion.
//
template <class type>
class persistent : private persistent_store
{
  type obj;

  //! Sync the object with its persistent store.
  inline void
  sync ()
    {
      save ((const unsigned char*) &obj);
    }
public:
  //! Create a persistent object.
  inline
  persistent (persist_id_t id)
    : persistent_store (id, &obj, sizeof (obj))
    {
    }

  //! Create a persistent object.
  //
  // If it's the first time the object is created, initialize it
  // with <b>init</b>.
  inline
  persistent (persist_id_t id, const type& init)
    : persistent_store ()
    {
      if (create (id, &obj, sizeof (type)))
	{
	  obj = init;
	  sync ();
	}
    }

  //! Create a persistent object.
  //
  // If it's the first time the object is created, initialize it
  // with <b>init</b>.
  inline
  persistent (persist_id_t id, type& init)
    : persistent_store ()
    {
      if (create (id, &obj, sizeof (type)))
	{
	  memcpy (&obj, &init, sizeof (type));
	  sync ();
	}
    }

  //! Delete the runtime instance of the object.
  //
  // The object can still be retrieve from persistent storage.
  inline
  ~persistent ()
    {
      ;
    }

  //! Assignment operator.
  //
  // Modify the object and update its persistent storage.
  inline persistent<type>&
  operator = (const type& value)
    {
      memcpy (&obj, value, sizeof (value));
      sync ();
      return *this;
    }

  //! Assignment operator.
  //
  // Modify the object and update its persistent storage.
  inline persistent<type>&
  operator = (type& value)
    {
      memcpy (&obj, &value, sizeof (value));
      sync ();
      return *this;
    }

  //! Return the value of the object.
  inline
  operator const type& ()
    {
      return obj;
    }

  inline persistent<type>&
  operator ++ (int)
    {
      obj++;
      sync ();
      return *this;
    }

  inline persistent<type>&
  operator -- (int)
    {
      obj--;
      sync ();
      return *this;
    }
};

  
#endif
