/* 
   Copyright (C) 2001 Free Software Foundation, Inc.
   Written by Duane Gustavus (duane@denton.com)

This file is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

In addition to the permissions in the GNU General Public License, the
Free Software Foundation gives you unlimited permission to link the
compiled version of this file with other programs, and to distribute
those programs without any restriction coming from the use of this
file.  (The General Public License restrictions do apply in other
respects; for example, they cover modification of the file, and
distribution when not linked into another program.)

This file is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef LIBBOT_H
#define LIBBOT_H

#define DIGITAL_PORT *(unsigned char volatile *)0x7000
#define MAXSPEED 30
#define MINSPEED -30
#define LEFT_MTR 0x10
#define RIGHT_MTR 0x40
#define LEFT_REVERSE 0x01
#define RIGHT_REVERSE 0x04

/* State word  AAAA AAAA BBBB BBBB
               ||||    |   || ||||
DSW1-----------+|||    |   || ||||
DSW2------------+||    |   || ||||
DSW3-------------+|    |   || ||||
DSW4--------------+    |   || ||||
SERVO------------------+   || ||||
IR ------------------------+| ||||
BUMPER ---------------------+ ||||
ACTIVE mode-------------------+|||
PLIR --------------------------+||
PHOTO --------------------------+|
STATUS report--------------------+
*/
#define DSW1 0x8000
#define DSW2 0x4000
#define DSW3 0x2000
#define DSW4 0x1000

#define SERVO 0x100
#define IR 0x20
#define BUMPER 0x10
#define ACTIVE 0x08
#define PLIR 0x04
#define PHOTO 0x02
#define STATUS 0x01

/* analog port mappings */
#define DIP1 analog[16]
#define DIP2 analog[17]
#define DIP3 analog[18]
#define DIP4 analog[19]
#define FROB1 analog[20]
#define FROB2 analog[15]
/* photo sensors */
#define PHOTOL analog[0]
#define PHOTOR analog[1]

extern void init_buffered_io();
extern unsigned char sci_putc(char);
extern unsigned char sci_getc();
extern int serial_print();
extern unsigned char chk_serial_inbuf();
extern void init_sysclock(void);
extern long sysclock;
extern void init_analog (void);
extern unsigned char read_analog (unsigned char);
extern volatile unsigned char analog[];
extern void init_encoders();
extern volatile int l_encoder, Lticks, r_encoder, Rticks;
extern volatile char c_encoder;
extern void init_ir();
extern volatile int ir_detect_lt, ir_detect_rt;
extern void init_poll_sensors();
extern volatile int Detect, Bcount;
extern void start_speed_ctl(), stop_speed_ctl();
extern void init_pwm(void);
extern volatile int Lspeed, Rspeed, Lmtr, Rmtr, av_velo, run_speed;
extern volatile unsigned char digital_shadowbits, expbd_shadowbits;
extern unsigned char choose_button(), escape_button();
extern volatile unsigned short le_sample, re_sample;
extern void pwm_on(void), pwm_off(void);
extern void speed_ctl();
extern void led0_on(), led1_on(), led0_off(), led1_off();

#endif
