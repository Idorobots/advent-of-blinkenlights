/* lcd.c -- LCD Control Panel Operations
   Copyright 2000 Free Software Foundation, Inc.
   Written by Stephane Carrez (stcarrez@worldnet.fr)

This file is part of GEL.

GEL is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GEL is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GEL; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#ifndef _GEL_LCD_H
#define _GEL_LCD_H

#include <sys/param.h>

#ifndef LCD_MAX_COLS
#  define LCD_MAX_COLS  16
#endif

#ifndef LCD_MAX_LINES
#  define LCD_MAX_LINES 2
#endif


/*! Type identifying a column on the LCD panel.  */
typedef unsigned char lcd_col_t;

/*! Type identifying a line on the LCD panel.  */
typedef unsigned char lcd_line_t;

/*! Reset the LCD panel.

 */
extern void lcd_reset (void);

/*! Move the LCD panel cursor to its home.

 */
extern void lcd_home (void);

/*! Clear the LCD panel.

 */
extern void lcd_clear (void);

extern void lcd_blink (int mode);

extern void lcd_cursor (int mode);

extern void lcd_display (int mode);

extern void lcd_shift (int direction);

/*! Print the string on the LCD panel.

  Print the string \i p at the current cursor location on the LCD panel.
  The cursor is automatically moved to the end of the string.

  @see lcd_goto  */
extern void lcd_print (const char *msg);

extern void lcd_putchar (unsigned char c);

/*! Move the cursor to the specified location.

  Move the cursor to the \i col and \i line on the LCD panel.

  @see lcd_print  */
extern void lcd_goto (lcd_col_t col, lcd_line_t line);

/*! Print the string at a given location on the LCD panel.

  Move the cursor to \i col and \i line and print the string \i msg.

  @see lcd_goto, lcd_print  */
extern void lcd_print_at (lcd_col_t col, lcd_line_t line, const char *msg);

#endif
